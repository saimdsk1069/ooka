# Ooka Serverless Services i.e. AWS Lambda Services

## Pre-reqs

### Python 3

See: http://docs.python-guide.org/en/latest/starting/install3/osx/ or your OS's relevant instructions.

### Docker

Download and install Docker. No need to login or set anything up, beyond launching the Docker service.

https://docs.docker.com/docker-for-mac/install/#download-docker-for-mac

### Node

    $ brew install node

Or whatever your OS requires. Chances are good you already have this.

### Serverless

https://serverless.com/framework/docs/platform/

    $ npm install -g serverless

## Starting a new Serverless project vs reusing an existing one

We should choose to bundle similar Lambda functions together when they have like dependencies (eg Pandas+Numpy) that
other functions would not benefit from, and should include in their package.

Unfortunately, much repetition exists between projects - there is no good way to share provider configuration. So
a balance between isolation (and thus leanness of individual functions) and shared configuration must be made.

#### To create a new Serverless Service/Project

    $ serverless create --template aws-python3 --path my-service

#### Change into the newly created directory

    $ cd my-service

#### Create the virtual env

    $ virtualenv venv --python=python3
    $ source venv/bin/activate
    (venv) $ pip freeze > requirements.txt


## Deploying services

### Re-export requirements (if virtualenv has changed)

    (venv) $ pip freeze > requirements.txt

### Specifying an "environment" stage

Specifying --stage allows you to specify which Provider record in serverless.yml should be used. Provider records
describe where to deploy services to and what else to provision.

The Lambda function endpoint name becomes: <app-name>-<stage>-<function-name>. We must configure this within each
consumer application so they consume the "stage" of the Lambda corresponding with its environment (staging vs prod, etc).

#### Deploy to staging

    $ serverless deploy --stage staging

#### Or, eventually, deploying to production

    $ serverless deploy --stage production

## Test code locally

Modify if __name__ == "__main__" to your liking, passing in event prerequisites for your code.

    (venv) $ python handler.py

## Unit testing

@TODO

## Continuous integration

@TODO
