TEST_CONFIG = {
    'DB_HOST': 'localhost',
    'DB_USERNAME': 'root',
    'DB_PASSWORD': 'root',
    'DB_NAME': 'ookaportal_20170512',
    'MIXPANEL_PROJECT_TOKEN': '387677fb242de25fd71c6a72f2b3bc5d'

}
