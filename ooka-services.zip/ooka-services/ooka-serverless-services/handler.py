import os
import sys
import logging
import mixpanel
import pymysql
from urllib.request import url2pathname

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Keeping database connection in global scope so it persists between Lambda executions
try:
    conn = pymysql.connect(
        os.environ['DB_HOST'], user=os.environ['DB_USERNAME'], passwd=os.environ['DB_PASSWORD'],
        db=os.environ['DB_NAME'], connect_timeout=5
    )
except:
    logger.error("ERROR: Unexpected error: Could not connect to the database.")
    sys.exit()

print("SUCCESS: Connection to RDS mysql instance succeeded")

mp = mixpanel.Mixpanel(os.environ['MIXPANEL_PROJECT_TOKEN'])


def hello_world(event, context):
    print("This works.")
    return event


def mp_track(event, context):
    account_id = event['account_id']
    event_name = event['event_name']
    properties = event['properties']
    meta = event['meta']

    query = "SELECT campaign_source, campaign_medium, campaign_term, campaign_content, campaign_name, infusionsoft_leadsource, infusionsoft_leadsourcecategory FROM Accounts WHERE id={account_id}".format(account_id=account_id)
    with conn.cursor(pymysql.cursors.DictCursor) as cur:
        cur.execute(query)
        account = cur.fetchone()

    if not account:
        # logger.warning("mp_track: Account Does Not Exist")
        return False

    for c in ['source', 'medium', 'term', 'content', 'name']:
        properties['campaign %s' % c] = url2pathname(account['campaign_%s' % c])

    properties['leadsource'] = account['infusionsoft_leadsource']
    properties['leadsource category'] = account['infusionsoft_leadsourcecategory']

    try:
        mp.track(distinct_id=account_id, event_name=event_name, properties=properties, meta=meta)
    except BaseException as be:
        logger.error("ERROR: Unexpected error: Could not track to Mixpanel.")
        return False
    return (account_id, event_name, properties, meta)


if __name__ == "__main__":
    mp_track('', {'account_id': 12345})
