import os
import mock
import config


@mock.patch.dict(os.environ, config.TEST_CONFIG)
class TestMPTrack(object):
    account_id = None
    event_name = 'test event_name'
    properties = {'testprop': 'testpropval'}
    meta = {'testmeta1': 'testval 1'}

    def test_valid_account(self):
        from handler import mp_track
        event = {'account_id': 8599, 'event_name': self.event_name, 'properties': self.properties, 'meta': self.meta}
        account_id, event_name, properties, meta = mp_track(event=event, context={})
        assert account_id == 8599
        assert event_name == self.event_name
        assert properties == self.properties
        assert meta == self.meta

    def test_missing_account(self):
        from handler import mp_track
        event = {'account_id': 0, 'event_name': self.event_name, 'properties': self.properties, 'meta': self.meta}
        sent = mp_track(event=event, context={})
        assert not sent
