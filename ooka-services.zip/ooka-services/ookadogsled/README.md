# Ooka Dogsled

This is Django app that serves as a backend for the Ooka Island web dashboard (https://bitbucket.org/scholastic/ooka-dashboard).


## Installation

1. Before installing you should have Python 3 and a way of creating python virtual environments (https://pypi.python.org/pypi/virtualenv).
2. Clone this repository.


```
git clone git@bitbucket.org:scholastic/ooka-services.git
```

3. Create and activate a virtual environment.

```
# go to checked out project
cd ooka-services/ookadogsled
# create the environment at ./venv
virtualenv -p python3 venv
# activate the environment
source ./venv/bin/activate
```

4. Now install the project's requirements.

Centos preperation for Celery+SQS:

```
yum install libcurl-devel
export PYCURL_SSL_LIBRARY=nss
(venv) $ pip install pycurl --no-cache-dir
(venv) $ pip install -r requirements.txt
```

MacOS install Dynamodb

```
brew cask install caskroom/cask/dynamodb-local
dynamodb-local
```

5. Now do the migrations to initialize all database models.

```
(venv) $ python manage.py migrate
```

Load initial data

```
(venv) $ python manage.py loaddata gameplay/fixtures/ooka_data_from_legacy.json
```

6. You should be now be able to run the Django test server.

```
(venv) $ python manage.py runserver
```

7. Access in your browser at `localhost:8000`

## Running celery

```
(venv) $ celery -A ooka_services worker -l DEBUG
```

Running celery as a daemon:

```
(venv) $ celery multi start ooka_dev -A ooka_services -l DEBUG
```

Running Elastic Search on MacOS

```
brew install elasticsearch
brew services start elasticsearch

brew services restart elasticsearch
```

Running Kafka on MacOS:

```
brew install kafka
brew services start zookeeper
brew services start kafka
```

## Running Unit Tests

1. All unit tests can be run using

```
(venv) $ python manage.py test
```

2. Unit tests for a specific app can be run with

```
(venv) $ python manage.py test <app_name>
```

## Deployment

For right now this app is just sitting on a server being hosted by Apache.
1. To deploy to `dev`.

```
(venv) $ fab dev
```

## Exporting game content

The JSON files in gameplay/fixtures/unity_content/ contain content from the database that Unity needs. To update these files,
download Sequel Pro (https://www.sequelpro.com) and use the Bundles -> Data Table -> Copy -> Copy as JSON tool.


## Openshift deployments

The below applies only to ookadogsled application deployments.

- dev: https://ookadogsled.dev.micro.scholastic.com
- qa: https://ookadogsled.qa.micro.scholastic.com
- uat: https://ookadogsled.uat.micro.scholastic.com
- perf: https://ookadogsled.perf.micro.scholastic.com
- stage: https://ookadogsled.stage.micro.scholastic.com
- prod: https://ookadogsled.prod.micro.scholastic.com

### General strategy

Our ookadogsled Python app is hosted within Openshift.

1. All code currently builds from the dev branch (could change going forward)
2. Configuration (things previously managed in local_settings.py files) is now managed by Consul
3. A dance between Openshift portal and Jenkins is used to produce builds
4. Builds are stored in Artifactory under named versions
5. Jenkins deploys to specific Openshift environments

### Configuration management

Consul is used to manage the environment variables that are injected
into the Openshift container. These are used in settings.py to specify
things like database connection settings.

Non-prod: http://consul.service.np-us-east.consul:8500/ui/#/np-us-east/kv/ooka/

Prod: http://consul.service.aws-us-east.consul:8500/ui/#/aws-us-east/kv/ooka/

Ryan has credentials to modify the KV pairs.

### Openshift

Openshift portal non-prod: https://openshift-master.osnp3.scholastic.tech/console/
Openshift portal prod:

1. Authenticate with network credentials on the scholastic_CA_AD Activedirectory for Canadian network accounts, scholastic_AD for others.
2. Open Ooka-CICD
3. Builds -> Pipelines
4. On ookadogsled pipeline, press Start Pipeline
5. The pipeline will produce a build for dev, and then require input for the build to be stored in Artifactory.
6. Login with Openshift
7. Enter an image version. Recommended: YYYYMMDD eg 20180404. The build will be stored in Artifactory under that version number.
8. A link called "Input requested" will appear. Click it, and select which environment this build should be deployed to.
9. Press Proceed. Press Proceed again if prompted.
10. Jenkins will prompt for which version you wish to deploy to certain environments. Specify the build from Step 7 above or view the list here: https://openshift-extras.apps.osnp1.scholastic.tech/docker-images/ under ooka/ookadogsled
11. Jenkins will report "Finished: SUCCESS"

Important note: don't touch the ookadogsled-build pipeline!


#### Shell access for pods

Web-based terminal is available for shell access to Openshift pods.

Browse to the ooka-dev (or whichever) app -> Application -> Deployments -> ookadogsled -> (build #) -> <pod> -> Terminal

Execute Python commands using envconsul:

```
envconsul -consul-addr $SCH_CONSUL -consul-token $SCH_TOKEN -prefix $SCH_KEY/$SCH_ENV -once python3 manage.py
```

You may want to run "bash" as well to get tab completion.


### What about Angular?

Angular will get its own pipeline to compile using Webpack, and store the assets in S3. The assets will be distributed by Cloudfront.

See: https://jira.sts.scholastic.com/browse/OI-1057


## Local environment variables

Local environment variables are now injected into the Python app.

Create a .env file in the root of the Django project (not the repo root) from the example file "example-env".

A Pycharm Plugin can be used to load environment variables from a file. See: https://github.com/Ashald/EnvFile

https://github.com/kennethreitz/autoenv can be used to automatically load those into your shell.

## Running docker locally

1. First you will need to install Docker only your machine: https://docs.docker.com/install/

2. Download the S2I tool from here and install as instructed: https://github.com/openshift/source-to-image#installation

3. Download the builder image:

```
wget https://s3.amazonaws.com/schl-fola-builder-images/schl-centos7-python36.tar
```

4.  Next load these images into Docker: docker load -i schl-centos7-python3.tar

5.  Run ```docker images``` to make sure the images were loaded.

6. Configure PIP to search the private repo for packages

Place the following PIP config in ~/.pip/pip.conf

```
[global]
extra-index-url = https://pypi-user:1664b17c-8764-4129-b562-58bdec31672a@scholastic.artifactoryonline.com/scholastic/api/pypi/pypi/simple
```

7. To create a build using a local directory (use the -c flag to test uncommitted changes)


```

cd .. (get to the project root directory)
s2i build . schl-centos7-python36:latest ookadogsled -e SCH_TOKEN=6952feb5-d455-481b-7067-2733750f14ab -e SCH_CONSUL=consul.service.np-us-east.consul:8500 -e SCH_ENV=dev -e SCH_KEY=ooka
```

8. Running the Docker Image

Using Consul for environment variables:

```
docker run --rm -p 8080:8080 -e SCH_ENV=dev -e SCH_TOKEN=[token] -e SCH_CONSUL=[consul] -e SCH_KEY=[prefix] ookadogsled
```
Eg:

```
docker run --rm -p 8080:8080 -e SCH_ENV=dev -e SCH_TOKEN=6952feb5-d455-481b-7067-2733750f14ab -e SCH_CONSUL=consul.service.np-us-east.consul:8500 -e SCH_ENV=dev -e SCH_KEY=ooka -e UWSGI_MODULE=ookadogsled.wsgi:application ookadogsled
```

Using your own environment variables:
@TODO
docker run --rm -p 8080:8080 -e SCH_ENV=dev -e SCH_TOKEN=6952feb5-d455-481b-7067-2733750f14ab -e SCH_CONSUL=consul.service.np-us-east.consul:8500 -e SCH_KEY=ooka/ookadogsled [app_image_name]


# Code review procedure

1. Check out feature branch for the PR
2. Run tests with coverage:
```
./manage.py jenkins --enable-coverage -k --coverage-format html
```
3. Observe no failures.
4. Inspect coverage report
```
open reports/coverage/index.html
```
