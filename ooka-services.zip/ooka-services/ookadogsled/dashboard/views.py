from django.shortcuts import render, HttpResponse
from gameplay.models import GameUser,GameState
import requests

# Create your views here.

def index(request):
    return HttpResponse('Hello World!')

def test(request):
    return HttpResponse('My second view!')

def profile(request):
    return render(request, 'app/index.html')

def user_detail(request):
    user_d = GameUser.objects.all()
    return render(request,'user_detail.html',context=user_d)

