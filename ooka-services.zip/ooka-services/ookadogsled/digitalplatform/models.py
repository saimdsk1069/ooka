import json
import logging
from digitalplatform.requests import get as dp_get


logger = logging.getLogger(__name__)


class BaseDPModel:
    fields = {}

    def __init__(self, **kwargs):
        for k in kwargs.items():
            setattr(self, k[0], k[1])

    def __getattribute__(self, name):
        if name in ['sections', 'students', 'teachers']:
            if super(BaseDPModel, self).__getattribute__(name) is None:
                records_dict = {}
                # Load records from cache or get from API
                records = getattr(self, 'get_%s' % name)()
                setattr(self, name, records)
                for record in records:
                    records_dict[record.id] = record
                setattr(self, '%s_by_id' % name, records_dict)
                return records

        if name[-6:] == '_by_id' and super(BaseDPModel, self).__getattribute__(name) is None:
            # Triggers setting the results to the property
            self.__getattribute__(name[:-6])
            return getattr(self, name)

        return super(BaseDPModel, self).__getattribute__(name)

    def unpack(self, record):
        for field in self.fields.items():
            if field[0] in record:
                cast_val = field[1](record[field[0]])
                setattr(self, field[0], cast_val)

    def student_grades_map(self):
        """
        Utility to take lists of students and return them indexed by grade
        :return: dict of grade keys and their counts of student objects
        """
        grades = {}
        for student in self.students:
            print("Stu", student, student.grade)
            if student.grade in grades:
                grades[student.grade].append(student)
            else:
                grades[student.grade] = [student]
        return grades

    def student_grades_map_counts(self):
        """
        Utility to take lists of students and return them indexed by grade
        :return: dict of grade keys and their counts of student objects
        """
        grades = {}
        for student in self.students:
            grades[student.grade] = grades[student.grade] + 1 if student.grade in grades else 1
        return grades

    class DoesNotExist(Exception):
        pass


class OrganizationManager:

    @staticmethod
    def get(org_id):
        dp_response = dp_get("roster/organizations/%d" % org_id)
        if dp_response.status_code == 200:
            org = Organization()
            dp_body = json.loads(dp_response.content)
            org.unpack(dp_body)
            return org

        logger.error("OrganizationManager.get failed",
                     extra={"status_code": dp_response.status_code, "org_id": org_id}
                     )
        raise BaseDPModel.DoesNotExist("Organization matching query does not exist.")

    @staticmethod
    def filter_by_staff_and_parent(staff_id, parent_id):
        dp_response = dp_get("composite/staff/%d/organizations?parent=%d" % (staff_id, parent_id))
        if dp_response.status_code == 200:
            dp_body = json.loads(dp_response.content)
            results = []
            for org_result in dp_body:
                # create a tuple of the teacher id and display name
                org = Organization()
                org.unpack(org_result)
                results.append(org)
            return results
        logger.error("OrganizationManager.filter_by_staff_and_parent failed",
                     extra={"status_code": dp_response.status_code, "staff_id": staff_id, "parent_id": parent_id}
                     )
        return []


class Organization(BaseDPModel):
    fields = {"id": int, "name": str, "orgType": str, "parent": int, "countryCode": str, "currentSchoolYear": int,
              "schoolStart": dict}
    id = None
    name = ''
    orgType = ''
    parent = None
    countryCode = ''
    currentSchoolYear = None
    schoolStart = dict()

    objects = OrganizationManager()

    child_organizations = None
    child_organizations_by_id = None
    teachers = None
    teachers_by_id = None
    sections = None
    sections_by_id = None
    students = None
    students_by_id = None

    def __str__(self):
        return "%s #%d - %s" % (self.orgType.capitalize(), self.id, self.name)

    def get_child_organizations(self, staff_id):
        return Organization.objects.filter_by_staff_and_parent(staff_id, self.id)

    def get_sections_by_staff_id(self, staff_id):
        if self.orgType == 'district':
            schools =  self.get_child_organizations(staff_id=staff_id)
            sections = []
            for school in schools:
                sections += school.sections
            return sections
        else:
            raise NotImplementedError

    def get_sections(self):
        if self.orgType == 'school':
            return Section.objects.filter_by_school(self.id)
        else:
            raise NotImplementedError

    def get_teacher(self, staff_id):
        if self.orgType is 'school':
            try:
                teacher_stub = self.teachers_by_id[staff_id]
            except KeyError:
                raise Teacher.DoesNotExist('Teacher matching query does not exist.')
            return Teacher.objects.get(staff_id=teacher_stub.id)
        raise NotImplementedError("Non-school organizations do not currently support this query. Iterate by school first.")

    def get_teachers(self):
        return Teacher.objects.filter_by_organization(org_id=self.id)

    def get_students(self):
        students = []
        for section in self.sections:
            students.extend(section.students)  # Student.objects.filter_by_section(section_id=section.id))
        return students


class SectionManager:

    def get(self, section_id):
        dp_response = dp_get("roster/sections/%d" % section_id)
        if dp_response.status_code == 200:
            section = Section()
            dp_body = json.loads(dp_response.content)
            section.unpack(dp_body)
            return section

        logger.error("OrganizationManager.get failed",
                     extra={"status_code": dp_response.status_code, "section_id": section_id}
                     )
        raise Section.DoesNotExist("Section matching query does not exist.")

    def filter_by_school(self, org_id):
        assert type(org_id) is int
        dp_response = dp_get('slz/schools/%d' % org_id)
        if dp_response.status_code == 200:
            dp_body = json.loads(dp_response.content)
            results = []
            for section_record in dp_body.get('classes', []):
                # create a tuple of the section id and display name
                section = Section()
                section.unpack(section_record)
                results.append(section)
            return results
        logger.error("SectionManager.filter_by_school failed",
                     extra={"status_code": dp_response.status_code, "org_id": org_id}
                     )
        return []

    def filter_by_staff(self, staff_id):
        """
        Given a staff id, return a list of Section objects
        :param staff_id: A staff id to return sections for
        :return: list of Section objects
        """
        assert type(staff_id) is int
        dp_response = dp_get('roster/sections?staffId=%d' % staff_id)

        if dp_response.status_code == 200:
            dp_body = json.loads(dp_response.content)
            results = []
            for section_record in dp_body:
                section = Section()
                section.unpack(section_record)
                results.append(section)
            return results
        logger.error("SectionManager.filter_by_staff failed",
                     extra={"status_code": dp_response.status_code, "staff_id": staff_id}
                     )
        return []

    def filter_by_student(self, student_id):
        """
        Given a student_id, give back a list of sections for that Student.
        :param student_id:
        :return: list of Section objects
        """
        assert type(student_id) is int
        dp_response = dp_get('roster/students/%d/sections' % student_id)

        if dp_response.status_code == 200:
            dp_body = json.loads(dp_response.content)
            results = []
            for section_record in dp_body:
                section = Section()
                section.unpack(section_record)
                results.append(section)
            return results
        logger.error("SectionManager.filter_by_student failed",
                     extra={"status_code": dp_response.status_code, "staff_id": student_id}
                     )
        return []


class Section(BaseDPModel):
    fields = {"id": int, "nickname": str, "displayName": str, "name": str, "lowGrade": str, "highGrade": str,
              "identifier": int, "organizationId": int, "schoolYear": int, "active": bool, "staff": dict}
    id = None
    identifier = None
    nickname = ''
    displayName = ''
    name = ''
    lowGrade = ''
    highGrade = ''
    organizationId = None
    schoolYear = None
    active = True
    staff = {}
    full_record = False

    objects = SectionManager()

    students = None
    students_by_id = None

    def __str__(self):
        return "Section #%d - %s" % (self.id, self.name)

    def unpack(self, record):
        super(Section, self).unpack(record)
        if self.name == '':
            self.name = self.displayName
        if not self.id:
            self.id = self.identifier

    def get_students(self):
        return Student.objects.filter_by_section(self.id)


class TeacherManager:

    @staticmethod
    def get(staff_id):
        dp_response = dp_get("roster/staff/%d" % staff_id)
        if dp_response.status_code == 200:
            dp_body = json.loads(dp_response.content)
            teacher = Teacher()
            teacher.unpack(dp_body)
            return teacher

        logger.error("TeacherManager.get failed",
                     extra={"status_code": dp_response.status_code, "staff_id": staff_id}
                     )
        raise Teacher.DoesNotExist("Teacher matching query does not exist.")

    @staticmethod
    def filter_by_organization(org_id):
        dp_response = dp_get('organizations/%d/staff-associations/' % org_id)
        results = []
        if dp_response.status_code == 200 and dp_response.content != b'':
            dp_body = json.loads(dp_response.content)
            for staff_record in dp_body:
                staff = Teacher()
                staff.unpack(staff_record)
                results.append(staff)
            return results
        logger.error("TeacherManager.filter_by_organization failed",
                     extra={"status_code": dp_response.status_code, "org_id": org_id}
                     )
        return []


class Teacher(BaseDPModel):
    fields = {"id": int, "firstName": str, "lastName": str, "email": str, "active": bool, "identifiers": dict}
    id = None
    firstName = ''
    lastName = ''
    email = ''
    active = True
    identifiers = {}

    objects = TeacherManager()

    sections = None
    sections_by_id = None

    students = None
    students_by_id = None

    def __str__(self):
        return "Teacher #%d - %s %s" % (self.id, self.firstName, self.lastName)

    def unpack(self, record):
        super(Teacher, self).unpack(record)
        if not self.id:
            self.id = self.identifiers.get('staffId')

    @property
    def name(self):
        return '%s %s' % (self.firstName, self.lastName)

    def get_sections(self):
        return Section.objects.filter_by_staff(staff_id=self.id)

    def get_students(self):
        students = []
        for section in self.sections:
            students.extend(Student.objects.filter_by_section(section_id=section.id))
        return students


class StudentManager:

    @staticmethod
    def get(student_id):
        dp_response = dp_get("roster/students/%d" % student_id)

        if dp_response.status_code == 200:
            dp_body = json.loads(dp_response.content)
            student = Student()
            student.unpack(dp_body)
            return student

        logger.error("StudentManager.get failed",
                     extra={"status_code": dp_response.status_code, "student_id": student_id}
                     )
        raise Student.DoesNotExist("Students matching query does not exist.")

    @staticmethod
    def filter_by_section(section_id):
        """
        Given a section id, return a list of Student objects in that section
        :param section_id:  A section id to return students for
        :return:  list of objects corresponding to students
        """
        dp_response = dp_get('roster/sections/%d/students' % section_id)
        if dp_response.status_code == 200:
            dp_body = json.loads(dp_response.content)
            results = []
            for student_record in dp_body:
                student = Student()
                student.unpack(student_record)
                results.append(student)
            return results
        logger.error("StudentManager.filter_by_section failed",
                     extra={"status_code": dp_response.status_code, "section_id": section_id}
                     )
        return []


class Student(BaseDPModel):
    fields = {"id": int, "firstName": str, "lastName": str, "grade": str, "active": bool, "identifier": int,
              "identifiers": dict, "credentials": dict}
    id = None
    firstName = ''
    lastName = ''
    grade = ''
    active = True
    credentials = {}
    identifier = None
    identifiers = {}

    sections = None
    sections_by_id = None

    objects = StudentManager()

    def __str__(self):
        return "Student #%d - %s %s" % (self.id, self.firstName, self.lastName)

    def student_grades_map(self):
        raise NotImplementedError("What are you doing.")

    def unpack(self, record):
        super(Student, self).unpack(record)
        if not self.id:
            self.id = self.identifier
        self.grade = record["grade"]

    @property
    def name(self):
        return '%s %s' % (self.firstName, self.lastName)

    def get_sections(self):
        return Section.objects.filter_by_student(self.id)

    def is_in_organization(self, organization_id):
        """
        Tests whether this user is within a given Organization ID by looping through the student's sections
        :param school_id:
        :return:
        """
        for section in self.sections:
            if section.organizationId == organization_id:
                return True
        return False
