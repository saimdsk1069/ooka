import logging
import requests
from django.conf import settings


logger = logging.getLogger(__name__)


def dp_request(method, resource, **kwargs):
    r"""Sends a GET request.
    The lightest wrapper around requests.api.request
    :param method: method for the new :class:`Request` object.
    :param resource: Service URI w/o leading slash
    :param \*\*kwargs: Optional arguments that ``request`` takes.
    :return: :class:`Response <Response>` object
    :rtype: requests.Response
    """

    url = '%s/%s' % (settings.DP_API_URL, resource)
    auth = "Bearer %s" % settings.DP_API_ACCESS_TOKEN
    if 'headers' in kwargs:
        kwargs['headers']['Authorization'] = auth
    else:
        kwargs['headers'] = {'Authorization': auth}
    request_func = getattr(requests, method)
    r = request_func(url=url, **kwargs)

    if r.status_code == 403:
        logger.error("SDM/DP API has rejected our access token: %s" % r.content.decode())

    return r


def get(resource, params=None, **kwargs):
    r"""Sends a GET request.
    :param resource: Service URI w/o leading slash
    :param params: (optional) Dictionary or bytes to be sent in the query string for the :class:`Request`.
    :param \*\*kwargs: Optional arguments that ``request`` takes.
    :return: :class:`Response <Response>` object
    :rtype: requests.Response
    """
    return dp_request(method='get', resource=resource, params=params, **kwargs)


def post(resource, data=None, json=None, **kwargs):
    r"""Sends a POST request.
    :param resource: Service URI w/o leading slash
    :param data: (optional) Dictionary (will be form-encoded), bytes, or file-like object to send in the body of the :class:`Request`.
    :param json: (optional) json data to send in the body of the :class:`Request`.
    :param \*\*kwargs: Optional arguments that ``request`` takes.
    :return: :class:`Response <Response>` object
    :rtype: requests.Response
    """
    return dp_request(method='post', resource=resource, data=data, json=json, **kwargs)
