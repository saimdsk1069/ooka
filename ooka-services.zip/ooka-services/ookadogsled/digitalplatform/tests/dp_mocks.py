dp_teacher_55_mock = """
{
"id": "3349305",
"identifiers": {
  "iamUserId": "98186632",
  "staffId": "3349305"
},
"firstName": "Ooka",
"lastName": "Dev",
"email": "dnadgar@scholastic.com",
"lastModifiedDate": "2017-10-27T13:28:22.000-0400",
"active": true,
"promptToAcceptLicense": false
}
"""

dp_teacher_mock = """
[
  {
    "id": "3329791",
    "firstName": "Digital",
    "lastName": "Appservices-team"
  },
  {
    "id": "3329907",
    "firstName": "ve",
    "lastName": "ne"
  },
  {
    "id": "3329941",
    "firstName": "JJ",
    "lastName": "Roy"
  },
  {
    "id": "3330962",
    "firstName": "stevestaff",
    "lastName": "cody"
  },
  {
    "id": "10",
    "firstName": "Avery P",
    "lastName": "Gross"
  },
  {
    "id": "3331274",
    "firstName": "Phillip",
    "lastName": "Ball"
  },
  {
    "id": "3349305",
    "firstName": "Test",
    "lastName": "Teacher"
  }
]
"""
dp_sections_mock = """
[
  {
    "id": "168741",
    "organizationId": "3317034",
    "staff": {
      "primaryTeacherId": "3349305"
    },
    "nickname": "Ooka Dev Grade 1",
    "lowGrade": "1",
    "highGrade": "1",
    "active": true,
    "schoolYear": "2017",
    "easyLogin": {
      "enabled": true
    },
    "identifiers": {
    },
    "displayName": "Ooka Dev Grade 1"
  },
  {
    "id": "235660",
    "organizationId": "3317034",
    "staff": {
      "primaryTeacherId": "3349305"
    },
    "nickname": "Hello1",
    "lowGrade": "k",
    "highGrade": "k",
    "active": true,
    "schoolYear": "2017",
    "easyLogin": {
      "enabled": true
    },
    "identifiers": {
    },
    "displayName": "Hello1"
  }
]
"""
dp_students_mock = """
[
  {
    "id": "3349306",
    "firstName": "Brent",
    "lastName": "Mitton",
    "active": true,
    "grade": "1",
    "credentials": {
      "easyLoginSecret": "1",
      "easyLoginAvatarId": "1",
      "securityRealm": "-1",
      "studentId": "3349306",
      "username": "BrentM4",
      "realm": "roster"
    },
    "identifiers": {
      "studentId": "3349306"
    },
    "primaryOrgId": "3317034"
    
  },
  {
    "id": "3349307",
    "firstName": "DJ",
    "lastName": "Nadgar",
    "active": true,
    "grade": "1",
    "credentials": {
      "easyLoginSecret": "6",
      "easyLoginAvatarId": "2",
      "securityRealm": "-1",
      "studentId": "3349307",
      "username": "DjN1",
      "realm": "roster"
    },
    "identifiers": {
      "studentId": "3349307"
    },
    "primaryOrgId": "3317034"
  },
  {
    "id": "3349308",
    "firstName": "Ryan",
    "lastName": "Palmer",
    "active": true,
    "grade": "1",
    "credentials": {
      "easyLoginSecret": "8",
      "easyLoginAvatarId": "3",
      "securityRealm": "-1",
      "studentId": "3349308",
      "username": "RyanP5",
      "realm": "roster"
    },
    "identifiers": {
      "studentId": "3349308"
    },
    "primaryOrgId": "3317034"
  }
]
"""

dp_district_org_mock = """
{
  "id": "3317035",
  "name": "ANTIOCH UNIFIED SCHOOL DIST",
  "orgType": "district",
  "identifiers": {
    "ucn": "600000774",
    "source": "SPS",
    "spsOrgId": "30585"
  },
  "lastModifiedDate": "2017-02-23T09:03:59.000-0500",
  "address": {
    "city": "ANTIOCH",
    "state": "CA",
    "zipCode": "94509",
    "address1": "510 G ST",
    "address2": "",
    "address3": "",
    "address4": "",
    "address5": ""
  },
  "countryCode": "USA",
  "currentSchoolYear": "2017",
  "overrideSchoolYearStart": false,
  "schoolStart": {
    "monthOfYear": 8,
    "dayOfMonth": 1
  },
  "betaTester": false,
  "siteAuthStatus": false,
  "useSchoolRostering": false
}
"""
dp_school_org_mock = """{
  "id": "3317034",
  "name": "ANTIOCH MIDDLE SCHOOL",
  "parent": "3317035",
  "orgType": "school",
  "identifiers": {
    "ucn": "600035016",
    "source": "SPS",
    "idamSiteId": "39130473258657955",
    "spsOrgId": "287383"
  },
  "lastModifiedDate": "2017-07-24T14:14:38.000-0400",
  "address": {
    "city": "ANTIOCH",
    "state": "CA",
    "zipCode": "94509",
    "address1": "1500 D ST"
  },
  "countryCode": "USA",
  "currentSchoolYear": "2017",
  "overrideSchoolYearStart": true,
  "schoolStart": {
    "monthOfYear": 8,
    "dayOfMonth": 1
  },
  "betaTester": false,
  "siteAuthStatus": true,
  "useSchoolRostering": false
}"""
dp_district_school_list_mock = """[
  {
    "id": "3317034",
    "name": "ANTIOCH MIDDLE SCHOOL",
    "parent": "3317035",
    "orgType": "school",
    "identifiers": {
      "ucn": "600035016",
      "source": "SPS",
      "idamSiteId": "39130473258657955",
      "spsOrgId": "287383"
    },
    "lastModifiedDate": "2017-07-24T14:14:38.000-0400",
    "address": {
      "city": "ANTIOCH",
      "state": "CA",
      "zipCode": "94509",
      "address1": "1500 D ST"
    },
    "countryCode": "USA",
    "currentSchoolYear": "2017",
    "overrideSchoolYearStart": true,
    "schoolStart": {
      "monthOfYear": 8,
      "dayOfMonth": 1
    },
    "betaTester": false,
    "siteAuthStatus": true,
    "useSchoolRostering": false
  },
  {
    "id": "3317036",
    "name": "OTHER SCHOOL",
    "parent": "3317035",
    "orgType": "school",
    "identifiers": {
      "ucn": "600035016",
      "source": "SPS",
      "idamSiteId": "39130473258657955",
      "spsOrgId": "287383"
    },
    "lastModifiedDate": "2017-07-24T14:14:38.000-0400",
    "address": {
      "city": "ANTIOCH",
      "state": "CA",
      "zipCode": "94509",
      "address1": "1500 D ST"
    },
    "countryCode": "USA",
    "currentSchoolYear": "2017",
    "overrideSchoolYearStart": true,
    "schoolStart": {
      "monthOfYear": 8,
      "dayOfMonth": 1
    },
    "betaTester": false,
    "siteAuthStatus": true,
    "useSchoolRostering": false
  }
]"""
dp_school_section_list_mock = """{
  "name": "ANTIOCH MIDDLE SCHOOL",
  "identifier": "3317034",
  "schoolGroups": [
  ],
  "classes": [
    {
      "name": "Tuarez's Class",
      "identifier": "155528"
    },
    {
      "name": "Test Class",
      "identifier": "155611"
    },
    {
      "name": "New Class",
      "identifier": "155612"
    },
    {
      "name": "New Class 2",
      "identifier": "155613"
    },
    {
      "name": "free's class",
      "identifier": "155614"
    },
    {
      "name": "New Class",
      "identifier": "155615"
    },
    {
      "name": "New Class",
      "identifier": "155617"
    },
    {
      "name": "New Class",
      "identifier": "155618"
    },
    {
      "name": "Test Class",
      "identifier": "155619"
    },
    {
      "name": "Licensing",
      "identifier": "155859"
    },
    {
      "name": "ActiveClassCurrentYear",
      "identifier": "156232"
    },
    {
      "name": "ActiveClassFutureYear",
      "identifier": "156233"
    },
    {
      "name": "NoStudentsClassPastYear",
      "identifier": "156234"
    },
    {
      "name": "AllActiveStudentsClass",
      "identifier": "156235"
    },
    {
      "name": "AllInactiveStudentsClassPastYear",
      "identifier": "156409"
    },
    {
      "name": "DoNotDeleteMe",
      "identifier": "156497"
    },
    {
      "name": "Class1",
      "identifier": "157044"
    },
    {
      "name": "Steves Second Class",
      "identifier": "157046"
    },
    {
      "name": "Class 3",
      "identifier": "157327"
    },
    {
      "name": "DoNotTouchMe",
      "identifier": "157412"
    },
    {
      "name": "First Grade Antioch - Cris",
      "identifier": "157414"
    },
    {
      "name": "Second Grade Antioch - JChen",
      "identifier": "157416"
    },
    {
      "name": "InactiveActiveStudentsClass",
      "identifier": "157903"
    },
    {
      "name": "Amanda's Class",
      "identifier": "158922"
    },
    {
      "name": "ClassOf50ToTestEasyLogin",
      "identifier": "159464"
    },
    {
      "name": "ClassOf51ToTestEasyLogin",
      "identifier": "159872"
    },
    {
      "name": "ClassOf55ToTestEasyLogin",
      "identifier": "159873"
    },
    {
      "name": "ClassOf53ToTestEasyLogin",
      "identifier": "159876"
    },
    {
      "name": "Class - Antioch Middle School",
      "identifier": "160117"
    },
    {
      "name": "AllInactiveStudentsClassPastYe",
      "identifier": "160174"
    },
    {
      "name": "old class",
      "identifier": "160195"
    },
    {
      "name": "Science Class",
      "identifier": "160200"
    },
    {
      "name": "dave",
      "identifier": "160845"
    },
    {
      "name": "my class",
      "identifier": "160953"
    },
    {
      "name": "Chanda's Class",
      "identifier": "163298"
    },
    {
      "name": "My CLass",
      "identifier": "163561"
    },
    {
      "name": "Chaith Class",
      "identifier": "163562"
    },
    {
      "name": "TeacherNewClass",
      "identifier": "163563"
    },
    {
      "name": "TeacherNewNewClass",
      "identifier": "163564"
    },
    {
      "name": "Dev Class",
      "identifier": "163565"
    }
  ],
  "timestamp": "2018-04-10 14:39:37.828",
  "timezone": {
    "id": "Zulu",
    "name": "Coordinated Universal Time"
  },
  "locale": {
    "regionIdentifier": 1,
    "countryName": "United States",
    "countryCode": "USA",
    "regionName": "United States"
  },
  "gradeSystem": {
    "name": "United States",
    "code": "USA"
  },
  "testAccount": true,
  "schoolCalendars": [
    {
      "startDate": "2017-08-01",
      "endDate": "2018-07-31",
      "description": "2017-2018 School Year",
      "markingPeriods": [
      ]
    }
  ]
}"""

dp_teacher_section_list_mock = """[
{
  "id": "155528",
  "organizationId": "3317034",
  "staff": {
    "primaryTeacherId": "3349305"
  },
  "nickname": "Ooka Dev Grade 1",
  "lowGrade": "1",
  "highGrade": "1",
  "active": true,
  "schoolYear": "2017",
  "easyLogin": {
    "enabled": true
  },
  "identifiers": {},
  "displayName": "Ooka Dev Grade 1"
},
{
  "id": "155611",
  "organizationId": "3317034",
  "staff": {
    "primaryTeacherId": "3349305"
  },
  "nickname": "Hello1",
  "lowGrade": "k",
  "highGrade": "k",
  "active": true,
  "schoolYear": "2017",
  "easyLogin": {
    "enabled": true
  },
  "identifiers": {},
  "displayName": "Hello1"
}
]
"""

dp_section_info_mock = """{
  "id": "168741",
  "organizationId": "3317034",
  "staff": {
    "primaryTeacherId": "3349305"
  },
  "nickname": "Ooka Dev Grade 1",
  "lowGrade": "1",
  "highGrade": "1",
  "active": true,
  "schoolYear": "2017",
  "easyLogin": {
    "enabled": true
  },
  "identifiers": {
  },
  "displayName": "Ooka Dev Grade 1"
}"""
dp_section_student_list = """
[
  {
    "id": "3349306",
    "firstName": "Brent",
    "lastName": "Mitton",
    "active": true,
    "grade": "1",
    "credentials": {
      "easyLoginSecret": "1",
      "easyLoginAvatarId": "1",
      "securityRealm": "-1",
      "studentId": "3349306",
      "username": "BrentM4",
      "realm": "roster"
    },
    "identifiers": {
      "studentId": "3349306"
    },
    "primaryOrgId": "3317034"
  },
  {
    "id": "3349307",
    "firstName": "DJ",
    "lastName": "Nadgar",
    "active": true,
    "grade": "1",
    "credentials": {
      "easyLoginSecret": "6",
      "easyLoginAvatarId": "2",
      "securityRealm": "-1",
      "studentId": "3349307",
      "username": "DjN1",
      "realm": "roster"
    },
    "identifiers": {
      "studentId": "3349307"
    },
    "primaryOrgId": "3317034"
  },
  {
    "id": "3349308",
    "firstName": "Ryan",
    "lastName": "Palmer",
    "active": true,
    "grade": "1",
    "credentials": {
      "easyLoginSecret": "8",
      "easyLoginAvatarId": "3",
      "securityRealm": "-1",
      "studentId": "3349308",
      "username": "RyanP5",
      "realm": "roster"
    },
    "identifiers": {
      "studentId": "3349308"
    },
    "primaryOrgId": "3317034"
  }
]
"""
dp_student_info_mock = """{
  "id": "3726125",
  "firstName": "Brent",
  "lastName": "Mitton",
  "active": true,
  "grade": "k",
  "credentials": {
    "easyLoginSecret": "11",
    "easyLoginAvatarId": "1",
    "securityRealm": "-1",
    "studentId": "3726125",
    "username": "MiniS3",
    "realm": "roster"
  },
  "identifiers": {
    "studentId": "3726125"
  }
}
"""

dp_student_sections_mock = """
[
  {
    "id": "247382",
    "organizationId": "3317034",
    "staff": {
      "primaryTeacherId": "3724303",
      "teacherIds": [
        "3724303"
      ]
    },
    "nickname": "Simon's Class",
    "lowGrade": "k",
    "highGrade": "k",
    "active": true,
    "schoolYear": "2017",
    "easyLogin": {
      "enabled": true,
      "showInEasyLoginSchool": true
    },
    "identifiers": {},
    "displayName": "Simon's Class"
  }
]
"""