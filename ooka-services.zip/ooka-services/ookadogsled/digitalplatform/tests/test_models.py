from django.test import mock, TestCase
from digitalplatform.models import Organization, Section, Student, Teacher
from .dp_mocks import *


class MockResponse:

    def __init__(self, status=200, content=""):
        self.status_code = status
        self.content = content


class ModelsTestCase(TestCase):

    def test_organization_missing_attribute(self):
        org = Organization()
        with self.assertRaisesMessage(AttributeError, "'Organization' object has no attribute 'missing_method'"):
            print(org.missing_method)

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(200, dp_school_section_list_mock)))
    def test_organization_sections_by_id(self):
        school = Organization(id=123, orgType='school')
        self.assertEqual(school.id, 123)
        section = school.sections[0]
        self.assertEqual(school.sections_by_id[section.id], section)

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(200, dp_school_section_list_mock)))
    def test_organization_sections_by_id_auto_populate(self):
        school = Organization(id=123, orgType='school')
        self.assertEqual(school.id, 123)
        self.assertIn(155528, school.sections_by_id)

    @mock.patch('digitalplatform.requests.dp_request')
    def test_organization_sections_called_once(self, mock_dp_request):
        mock_dp_request.return_value = MockResponse(200, dp_school_section_list_mock)
        school = Organization(id=123, orgType='school')
        self.assertEqual(school.id, 123)
        self.assertFalse(mock_dp_request.called)
        section = school.sections[0]
        self.assertEqual(section.id, 155528)
        self.assertTrue(mock_dp_request.called)
        section = school.sections[1]
        self.assertEqual(section.id, 155611)
        mock_dp_request.assert_called_once()

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(404)))
    def test_organization_get_organization_not_found(self):
        with self.assertRaisesMessage(Organization.DoesNotExist, 'Organization matching query does not exist.'):
            Organization.objects.get(org_id=1234)

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(500)))
    def test_organization_get_organization_error(self):
        with self.assertRaisesMessage(Organization.DoesNotExist, 'Organization matching query does not exist.'):
            self.assertIsNone(Organization.objects.get(org_id=1234))

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(200, dp_district_org_mock)))
    def test_organization_get_district(self):
        district = Organization.objects.get(org_id=1234)
        self.assertEqual(str(district), "District #3317035 - ANTIOCH UNIFIED SCHOOL DIST")
        self.assertEqual(district.id, 3317035)
        self.assertEqual(district.name, "ANTIOCH UNIFIED SCHOOL DIST")
        self.assertEqual(district.orgType, "district")
        self.assertEqual(district.countryCode, "USA")
        self.assertEqual(district.currentSchoolYear, 2017)
        self.assertEqual(district.schoolStart, {
            "monthOfYear": 8,
            "dayOfMonth": 1
        })

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(200, dp_district_school_list_mock)))
    def test_organization_get_district_schools(self):
        schools = Organization.objects.filter_by_staff_and_parent(staff_id=1234, parent_id=1234)

        self.assertEqual(str(schools[0]), "School #3317034 - ANTIOCH MIDDLE SCHOOL")
        self.assertEqual(schools[0].id, 3317034)
        self.assertEqual(schools[0].name, "ANTIOCH MIDDLE SCHOOL")
        self.assertEqual(schools[0].parent, 3317035)
        self.assertEqual(schools[0].orgType, "school")
        self.assertEqual(schools[0].countryCode, "USA")
        self.assertEqual(schools[0].currentSchoolYear, 2017)
        self.assertEqual(schools[0].schoolStart, {
            "monthOfYear": 8,
            "dayOfMonth": 1
        })

        self.assertEqual(str(schools[1]), "School #3317036 - OTHER SCHOOL")
        self.assertEqual(schools[1].id, 3317036)
        self.assertEqual(schools[1].name, "OTHER SCHOOL")
        self.assertEqual(schools[0].parent, 3317035)
        self.assertEqual(schools[1].orgType, "school")
        self.assertEqual(schools[1].countryCode, "USA")
        self.assertEqual(schools[1].currentSchoolYear, 2017)
        self.assertEqual(schools[1].schoolStart, {
            "monthOfYear": 8,
            "dayOfMonth": 1
        })

    def test_organization_student_grades_map(self):
        st1 = Student(id=1, grade='K')
        st2 = Student(id=2, grade='1')
        st3 = Student(id=3, grade='1')
        org = Organization(id=1, students=[st1, st2, st3])
        self.assertEqual(org.student_grades_map(), {'K': [st1], '1': [st2, st3]})

    def test_organization_student_grades_map_counts(self):
        org = Organization(id=1, students=[Student(id=1, grade='K'), Student(id=2, grade='1'), Student(id=3, grade='1')])
        self.assertEqual(org.student_grades_map_counts(), {'K': 1, '1': 2})

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(200, "{}")))
    def test_organization_school_sections_none(self):
        school = Organization(id=123, orgType='school')
        self.assertEqual(school.sections, [])

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(200, dp_school_section_list_mock)))
    def test_organization_school_sections(self):
        school = Organization(id=123, orgType='school')
        self.assertEqual(school.id, 123)
        self.assertEqual(len(school.sections), 40)
        self.assertEqual(str(school.sections[0]), "Section #155528 - Tuarez's Class")
        self.assertEqual(school.sections[0].id, 155528)
        self.assertEqual(school.sections[0].name, "Tuarez's Class")

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(404)))
    def test_organization_school_teacher_not_found(self):
        school = Organization(id=123, orgType='school')
        with self.assertRaisesMessage(Teacher.DoesNotExist, 'Teacher matching query does not exist.'):
            school.get_teacher(staff_id=99)

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(500)))
    def test_organization_school_teacher_error(self):
        school = Organization(id=123, orgType='school')
        with self.assertRaisesMessage(Teacher.DoesNotExist, 'Teacher matching query does not exist.'):
            school.get_teacher(staff_id=99)

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(200, dp_teacher_mock)))
    def test_organization_school_teacher_error2(self):
        school = Organization(id=123, orgType='school', teachers=[], teachers_by_id={})
        with self.assertRaisesMessage(Teacher.DoesNotExist, 'Teacher matching query does not exist.'):
            school.get_teacher(staff_id=9999)
        school.teachers_by_id = {99: Teacher(id=99)}
        school.get_teacher(staff_id=99)

    @mock.patch('digitalplatform.requests.dp_request')
    def test_organization_school_teacher(self, mock_dp_request):
        mock_dp_request.side_effect = [
            MockResponse(200, dp_teacher_mock),
            MockResponse(200, dp_teacher_55_mock)
        ]

        school = Organization(id=123, orgType='school')
        teacher = school.get_teacher(staff_id=3349305)
        self.assertEqual(teacher.id, 3349305)
        self.assertEqual(str(teacher), "Teacher #3349305 - Ooka Dev")
        self.assertEqual(teacher.firstName, "Ooka")
        self.assertEqual(teacher.lastName, "Dev")
        self.assertEqual(teacher.name, "Ooka Dev")
        self.assertEqual(teacher.email, "dnadgar@scholastic.com")
        self.assertTrue(teacher.active)

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(500, "")))
    def test_organization_school_section_students_error(self):
        section = Section(id=123)
        self.assertEqual(section.students, [])

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(200, dp_students_mock)))
    def test_organization_school_section_students_success(self):
        section = Section(id=123)
        self.assertEqual(len(section.students), 3)
        student = section.students[0]
        self.assertEqual(str(student), "Student #3349306 - Brent Mitton")
        self.assertEqual(student.id, 3349306)
        self.assertEqual(student.firstName, "Brent")
        self.assertEqual(student.lastName, "Mitton")
        self.assertEqual(student.grade, "1")
        self.assertTrue(student.active)

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(200, dp_student_info_mock)))
    def test_organization_student_success(self):
        student = Student.objects.get(student_id=3726125)
        self.assertEqual(str(student), "Student #3726125 - Brent Mitton")
        self.assertEqual(student.id, 3726125)
        self.assertEqual(student.firstName, "Brent")
        self.assertEqual(student.lastName, "Mitton")
        self.assertEqual(student.grade, "k")

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(200, dp_student_info_mock)))
    def test_roster_student(self):
        student = Student.objects.get(student_id=3726125)
        self.assertTrue(student.active)
        self.assertEqual(student.id, 3726125)
        self.assertEqual(student.firstName, 'Brent')
        self.assertEqual(student.lastName, 'Mitton')
        self.assertEqual(student.grade, 'k')
        self.assertEqual(student.name, 'Brent Mitton')

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(200, dp_student_sections_mock)))
    def test_student_sections(self):
        student = Student(id=3726125)
        sections = student.sections
        self.assertEqual(len(sections), 1)
        self.assertEqual(sections[0].id, 247382)
        self.assertEqual(sections[0].organizationId, 3317034)
        self.assertEqual(sections[0].name, "Simon's Class")

    @mock.patch('digitalplatform.requests.dp_request', mock.Mock(return_value=MockResponse(200, dp_student_sections_mock)))
    def test_roster_student_is_in_organization(self):
        student = Student(id=3726125)
        # print(student.sections[0)

        self.assertTrue(student.is_in_organization(3317034))
        self.assertFalse(student.is_in_organization(9999))

    @mock.patch('digitalplatform.requests.dp_request')
    def test_organization_sections_by_staff_id(self, mock_dp_request):
        mock_dp_request.side_effect = [
            MockResponse(200, dp_district_school_list_mock),
            MockResponse(200, dp_school_section_list_mock),
            MockResponse(200, dp_school_section_list_mock)            
        ]
        district = Organization(id=123, orgType='district')
        sections = district.get_sections_by_staff_id(staff_id=3317045)
        self.assertEqual(len(sections), 80)
