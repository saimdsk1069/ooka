===============
Django SDM Auth
===============

This is an application that is used to handle authentication in a Django application using Scholastic Digital Manager

Quick start
-----------

1. Install the library

    (venv) $ pip install git+ssh://git@bitbucket.org/scholastic/django-sdm-auth.git

2. Add "django_sdm_auth" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'sdm_authentication',
    ]

3. Include the polls URLconf in your project urls.py like this::

    url(r'^auth/', include('sdm_authentication.urls')),


4. Add settings. Refer to https://pyjwt.readthedocs.io/en/latest/ for their specific usage.

    # By default, the JWT private key is the same as the site's secret key
    JWT_PRIVATE_KEY = SECRET_KEY
    JWT_LEEWAY = 0
    JWT_AUDIENCE = None
    JWT_ISSUER = None
    JWT_ALGORITHM = 'HS256'
    COOKIE_DOMAIN = '.scholastic.com'
    ENV_NAME = 'jenkins'
    # Angular URL
    SPA_URL = "https://word-dev.scholastic.com"
    SERVICES_BASE_URL = "https://services.ooka-qa.scholastic.com"


5. Add the require_valid_jwt decorator to whichever view you require be available only when a valid JWT is passed in
the Authorization header. The decoded payload will be appended as a kwarg *jwt_payload*.

6. It's the view's responsibility to inspect the *jwt_payload* to determine access control.

7. Use the BaseSDMGameUser model class to create a GameUser model within a "gameplay" app. Customize as necessary. This model
will provide the JWT to authorize subsequent requests.

8. Django must have AWS credentials configured, or be connected to a local Dynamodb host.


Local development
-----------------

1. Remove git+ssh://git@bitbucket.org/scholastic/django-sdm-auth.git from requirements.txt.

2. Uninstall django-sdm-auth.

    (venv) $ pip uninstall django-sdm-auth

3. From your project root directory, check out this app from Bitbucket.

    $ git clone git+ssh://git@bitbucket.org/scholastic/django-sdm-auth.git

4. Create a symbolic link to the app within.

    $ ln -s django-sdm-auth/sdm_authentication sdm_authentication

5. Edit files as usual, and cd into the Git repo if you want to commit changes. If you are working on multiple projects that
need this library to work with both, you may want to symlink to a single copy for both projects.


Generating test JWTs
--------------------

    from sdm_authentication.utils import jwt_encode
    payload = {"some": "object"}
    token = jwt_encode(payload)

OR

    from gameplay.models import GameUser
    game_user = GameUser.objects.create(dp_id=123, dp_role='student')
    game_user.jwt_payload({})


Triggering a new release
------------------------

Must be a US-based employee to access the following:

https://sch-jenkins.apps.osnp2.scholastic.tech/job/ooka-builds/job/django-sdm-auth/
