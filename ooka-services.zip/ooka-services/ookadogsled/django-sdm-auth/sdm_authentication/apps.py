from django.apps import AppConfig


class SDMAuthenticationConfig(AppConfig):
    name = 'sdm_authentication'
