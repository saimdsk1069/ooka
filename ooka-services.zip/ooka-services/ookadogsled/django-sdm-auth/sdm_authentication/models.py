import datetime
import json
from calendar import timegm
from django.conf import settings
from django.db import models
from pynamodb.attributes import JSONAttribute, NumberAttribute, UnicodeAttribute, UTCDateTimeAttribute
from pynamodb.models import Model as PynamoModel


def dynamo_table_name(name): return settings.PROJECT_NAME + '_' + settings.ENV_NAME + '_' + name


class SDMAuthPynamoModel(PynamoModel):

    class Meta:
        read_capacity_units = 1
        write_capacity_units = 1
        host = "http://localhost:8000" if settings.ENV_NAME == "local" else None
        region = settings.AWS_DEFAULT_REGION


class BaseSDMGameUser(models.Model):
    DP_ROLES = (
        ('districtAdmin', 'District Admin'),
        ('schoolAdmin', 'School Admin'),
        ('student', 'Student'),
        ('teacher', 'Teacher')
    )
    dp_id = models.IntegerField(verbose_name="Digital Platform User ID", unique=True)
    dp_role = models.CharField(verbose_name="Digital Platform role", choices=DP_ROLES, max_length=16)
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)

    def __unicode__(self):
        return self.id

    class Meta:
        abstract = True

    def jwt_payload(self, lti_launch_request=None):
        """
        Generates a JSON Web Token payload for this GameUser.
        :param lti_launch_request: LTI launch request object, or just an empty dict.
        :type lti_launch_request: dict
        :return: payload object
        :rtype: dict
        """
        # @TODO Make future use of custom_dp_launch if necessary
        payload = dict(
            orig_iat=timegm(datetime.datetime.utcnow().utctimetuple()),
            servicesEnv=settings.ENV_NAME,
            servicesBaseUrl=settings.SERVICES_BASE_URL,
            gameUserId=self.id,
            dpId=self.dp_id,
            dpRole=self.dp_role,
        )

        if lti_launch_request:
            payload['givenName'] = lti_launch_request.get('lis_person_name_given', '')
            payload['familyName'] = lti_launch_request.get('lis_person_name_family', '')
            payload['dpRole'] = lti_launch_request['roles']

            custom_dp_launch_json = lti_launch_request.get('custom_dp_launch', '{}')
            custom_dp_launch = json.loads(custom_dp_launch_json)

            if 'launchContext' in custom_dp_launch:
                payload['dpRole'] = custom_dp_launch['launchContext']['role']
                if custom_dp_launch['launchContext']['role'] == 'student':
                    # @TODO - What if they are in multiple sections?
                    payload['sectionId'] = int(custom_dp_launch['studentContext']['enrollments'][0]['id'])
                    payload['scholasticGradeCode'] = custom_dp_launch['studentContext']['grade']['scholasticGradeCode']
                    payload['gradeSystemCode'] = custom_dp_launch['studentContext']['grade']['gradeSystemCode']
                # @TODO - What if they have multiple roles?
                elif custom_dp_launch['orgContext']['roles'][0] == 'teacher':
                    payload['sections'] = [s['id'] for s in custom_dp_launch['teacherContext']['classes']]

            if 'orgContext' in custom_dp_launch:
                if custom_dp_launch['orgContext']['organization']['orgType'] == 'district':
                    payload['dpRole'] = 'districtAdmin'
                    payload['districtId'] = int(custom_dp_launch['orgContext']['organization']['id'])
                elif custom_dp_launch['orgContext']['organization']['orgType'] == 'school':
                    if 'parent' in custom_dp_launch['orgContext']['organization']:
                        payload['districtId'] = int(custom_dp_launch['orgContext']['organization']['parent'])
                    payload['schoolId'] = int(custom_dp_launch['orgContext']['organization']['id'])
                    if 'schoolAdmin' in custom_dp_launch['orgContext']['roles']:
                        payload['dpRole'] = 'schoolAdmin'
        return payload

    def lti_launch_request_save(self, data):
        # Bootstrap the table - there must be a better way
        if not LTILaunchRequest.exists():
            LTILaunchRequest.create_table(wait=True)

        try:
            gsa = LTILaunchRequest.get(self.id)
            gsa.update(actions=[LTILaunchRequest.data.set(data)])
        except LTILaunchRequest.DoesNotExist:
            game_state_item = LTILaunchRequest(game_user_id=self.id, data=data)
            game_state_item.save()

    def lti_launch_request_get(self):
        try:
            gsa = LTILaunchRequest.get(self.id)
            return gsa.data
        except LTILaunchRequest.DoesNotExist:
            pass
        return None


class LTILaunchRequest(SDMAuthPynamoModel):
    game_user_id = NumberAttribute(hash_key=True)
    data = JSONAttribute(null=False)
    created = UTCDateTimeAttribute(null=False, default=datetime.datetime.utcnow)

    class Meta(SDMAuthPynamoModel.Meta):
        table_name = dynamo_table_name('LTILaunchRequest')

    def update(self, *args, **kwargs):
        kwargs['actions'].append(LTILaunchRequest.created.set(datetime.datetime.utcnow()))
        return super(LTILaunchRequest, self).update(*args, **kwargs)
