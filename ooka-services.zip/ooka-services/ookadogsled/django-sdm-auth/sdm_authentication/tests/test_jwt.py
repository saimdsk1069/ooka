import jwt
import json
from django.http import HttpResponse
from django.test import TestCase, override_settings
from ..utils import jwt_decode, require_valid_jwt
from django.test import RequestFactory
from gameplay.models import GameUser

VALID_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9." \
              "eyJmb28iOiJiYXIiLCJvcmlnX2lhdCI6MTUxMjY4NDI2NCwiZ2FtZVVzZXJJZCI6MTF9." \
              "45uy9XsBZnKyBWGTzYERFgSJWWbqEtAbxsXoonxgyZY"

STUDENT_SDM_LAUNCH_REQUEST = """
{"context_id":"9","custom_country_code":"USA","custom_dp_launch":"{   \\"identifiers\\" : {     \\"studentId\\" : \\"3349308\\"   },   \\"orgContext\\" : {     \\"organization\\" : {       \\"id\\" : \\"3317034\\",       \\"name\\" : \\"ANTIOCH MIDDLE SCHOOL\\",       \\"parent\\" : \\"3317035\\",       \\"orgType\\" : \\"school\\",       \\"identifiers\\" : {         \\"ucn\\" : \\"600035016\\",         \\"source\\" : \\"SPS\\",         \\"idamSiteId\\" : \\"39130473258657955\\",         \\"spsOrgId\\" : \\"287383\\"       },       \\"lastModifiedDate\\" : \\"2017-07-24T14:14:38.000-0400\\",       \\"address\\" : {         \\"city\\" : \\"ANTIOCH\\",         \\"state\\" : \\"CA\\",         \\"zipCode\\" : \\"94509\\",         \\"address1\\" : \\"1500 D ST\\"       },       \\"countryCode\\" : \\"USA\\",       \\"currentSchoolYear\\" : \\"2017\\",       \\"overrideSchoolYearStart\\" : true,       \\"schoolStart\\" : {         \\"monthOfYear\\" : 8,         \\"dayOfMonth\\" : 1       },       \\"siteAuthStatus\\" : true,       \\"useSchoolRostering\\" : false     },     \\"entitlements\\" : [ {       \\"id\\" : \\"47\\",       \\"name\\" : \\"Ooka Island Adventure\\",       \\"applicationCode\\" : \\"ooka\\",       \\"url\\" : \\"http://services.ooka-dev.scholastic.com/auth/lti\\",       \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/ooka_logo.png\\",       \\"active\\" : true,       \\"rosterSupport\\" : \\"full\\"     }, {       \\"id\\" : \\"49\\",       \\"name\\" : \\"W.O.R.D.\\",       \\"applicationCode\\" : \\"word\\",       \\"url\\" : \\"http://services.word-dev.scholastic.com/auth/lti\\",       \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/word_logo.png\\",       \\"active\\" : true,       \\"rosterSupport\\" : \\"full\\"     } ],     \\"currentSchoolCalendar\\" : {       \\"description\\" : \\"2017-2018 School Year\\",       \\"startDate\\" : \\"2017-08-01\\",       \\"endDate\\" : \\"2018-07-31\\",       \\"timezone\\" : \\"America/New_York\\"     },     \\"roles\\" : [ \\"student\\" ]   },   \\"launchContext\\" : {     \\"application\\" : {       \\"id\\" : \\"47\\",       \\"name\\" : \\"Ooka Island Adventure\\",       \\"applicationCode\\" : \\"ooka\\",       \\"url\\" : \\"http://services.ooka-dev.scholastic.com/auth/lti\\",       \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/ooka_logo.png\\",       \\"active\\" : true,       \\"rosterSupport\\" : \\"full\\"     },     \\"productEntitlements\\" : [ {       \\"id\\" : \\"115\\",       \\"name\\" : \\"Ooka Island Adventure\\",       \\"productCode\\" : \\"ooka\\",       \\"applicationId\\" : \\"47\\",       \\"active\\" : true,       \\"includesStudentAccess\\" : true,       \\"teacherDirectedSubscriptions\\" : {         \\"enabled\\" : false       }     } ],     \\"role\\" : \\"student\\"   },   \\"studentContext\\" : {     \\"grade\\" : {       \\"scholasticGradeCode\\" : \\"1\\",       \\"gradeSystemCode\\" : \\"USA\\",       \\"localGradeName\\" : \\"Grade 1\\"     },     \\"enrollments\\" : [ {       \\"id\\" : \\"168741\\",       \\"organizationId\\" : \\"3317034\\",       \\"staff\\" : {         \\"primaryTeacherId\\" : \\"3349305\\"       },       \\"nickname\\" : \\"Ooka Dev Grade 1\\",       \\"lowGrade\\" : \\"1\\",       \\"highGrade\\" : \\"1\\",       \\"active\\" : true,       \\"schoolYear\\" : \\"2017\\",       \\"easyLogin\\" : {         \\"enabled\\" : true       },       \\"identifiers\\" : { },       \\"displayName\\" : \\"Ooka Dev Grade 1\\"     } ]   },   \\"sessionContext\\" : {     \\"sessionType\\" : \\"DAS\\",     \\"sessionToken\\" : \\"4914e60c-a0a4-43a5-83bc-0e6834cd879f\\",     \\"easyLogin\\" : false   } }","custom_sdm_nav_ctx":"{   \\"user_id\\" : \\"3349308\\",   \\"name\\" : \\"Ryan P\\",   \\"portalBaseUrl\\" : \\"https://dp-portal-dev1.scholastic-labs.io\\",   \\"orgId\\" : \\"3317034\\",   \\"orgName\\" : \\"ANTIOCH MIDDLE SCHOOL\\",   \\"orgType\\" : \\"school\\",   \\"appCodes\\" : [ \\"ooka\\", \\"word\\" ],   \\"extSessionId\\" : \\"4914e60c-a0a4-43a5-83bc-0e6834cd879f\\",   \\"extSessionEndpoint\\" : \\"https://cnp0ebsm29.execute-api.us-east-1.amazonaws.com/dev1/extendedsession\\",   \\"appCode\\" : \\"ooka\\",   \\"appId\\" : \\"47\\",   \\"parentOrgId\\" : \\"3317035\\",   \\"env\\" : \\"dev1\\",   \\"easyLogin\\" : false,   \\"role\\" : \\"student\\" }","custom_timezone_id":"UTC-05:00","launch_presentation_locale":"en_us","lis_person_name_family":"Palmer","lis_person_name_full":"Ryan Palmer","lis_person_name_given":"Ryan","lti_message_type":"basic-lti-launch-request","lti_version":"LTI-1p0","oauth_consumer_key":"l0JkeOfrC2g2ALqB1dtghOjuxP8a","oauth_nonce":"104460490499758","oauth_signature_method":"HMAC-SHA1","oauth_timestamp":"1520438986","oauth_version":"1.0","resource_link_id":"sdm","roles":"Student","tool_consumer_info_product_family_code":"ScholasticDigitalPlatform","tool_consumer_info_version":"2013111804.04","tool_consumer_instance_name":"dev1","user_id":"3349308"}
"""

TEACHER_SDM_LAUNCH_REQUEST = """
{"context_id":"9","custom_country_code":"USA","custom_dp_launch":"{   \\"identifiers\\" : {     \\"staffId\\" : \\"3349305\\"   },   \\"orgContext\\" : {     \\"organization\\" : {       \\"id\\" : \\"3317034\\",       \\"name\\" : \\"ANTIOCH MIDDLE SCHOOL\\",       \\"parent\\" : \\"3317035\\",       \\"orgType\\" : \\"school\\",       \\"identifiers\\" : {         \\"ucn\\" : \\"600035016\\",         \\"source\\" : \\"SPS\\",         \\"idamSiteId\\" : \\"39130473258657955\\",         \\"spsOrgId\\" : \\"287383\\"       },       \\"lastModifiedDate\\" : \\"2017-07-24T14:14:38.000-0400\\",       \\"address\\" : {         \\"city\\" : \\"ANTIOCH\\",         \\"state\\" : \\"CA\\",         \\"zipCode\\" : \\"94509\\",         \\"address1\\" : \\"1500 D ST\\"       },       \\"countryCode\\" : \\"USA\\",       \\"currentSchoolYear\\" : \\"2017\\",       \\"overrideSchoolYearStart\\" : true,       \\"schoolStart\\" : {         \\"monthOfYear\\" : 8,         \\"dayOfMonth\\" : 1       },       \\"siteAuthStatus\\" : true,       \\"useSchoolRostering\\" : false     },     \\"entitlements\\" : [ {       \\"id\\" : \\"49\\",       \\"name\\" : \\"W.O.R.D.\\",       \\"applicationCode\\" : \\"word\\",       \\"url\\" : \\"http://services.word-dev.scholastic.com/auth/lti\\",       \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/word_logo.png\\",       \\"active\\" : true,       \\"rosterSupport\\" : \\"full\\"     }, {       \\"id\\" : \\"47\\",       \\"name\\" : \\"Ooka Island Adventure\\",       \\"applicationCode\\" : \\"ooka\\",       \\"url\\" : \\"http://services.ooka-dev.scholastic.com/auth/lti\\",       \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/ooka_logo.png\\",       \\"active\\" : true,       \\"rosterSupport\\" : \\"full\\"     } ],     \\"currentSchoolCalendar\\" : {       \\"description\\" : \\"2017-2018 School Year\\",       \\"startDate\\" : \\"2017-08-01\\",       \\"endDate\\" : \\"2018-07-31\\",       \\"timezone\\" : \\"America/New_York\\"     },     \\"roles\\" : [ \\"teacher\\" ]   },   \\"launchContext\\" : {     \\"application\\" : {       \\"id\\" : \\"47\\",       \\"name\\" : \\"Ooka Island Adventure\\",       \\"applicationCode\\" : \\"ooka\\",       \\"url\\" : \\"http://services.ooka-dev.scholastic.com/auth/lti\\",       \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/ooka_logo.png\\",       \\"active\\" : true,       \\"rosterSupport\\" : \\"full\\"     },     \\"productEntitlements\\" : [ {       \\"id\\" : \\"115\\",       \\"name\\" : \\"Ooka Island Adventure\\",       \\"productCode\\" : \\"ooka\\",       \\"applicationId\\" : \\"47\\",       \\"active\\" : true,       \\"includesStudentAccess\\" : true,       \\"teacherDirectedSubscriptions\\" : {         \\"enabled\\" : false       }     } ],     \\"role\\" : \\"teacher\\"   },   \\"teacherContext\\" : {     \\"classes\\" : [ {       \\"id\\" : \\"168741\\",       \\"organizationId\\" : \\"3317034\\",       \\"staff\\" : {         \\"primaryTeacherId\\" : \\"3349305\\"       },       \\"nickname\\" : \\"Ooka Dev Grade 1\\",       \\"lowGrade\\" : \\"1\\",       \\"highGrade\\" : \\"1\\",       \\"active\\" : true,       \\"schoolYear\\" : \\"2017\\",       \\"easyLogin\\" : {         \\"enabled\\" : true       },       \\"identifiers\\" : { },       \\"displayName\\" : \\"Ooka Dev Grade 1\\"     }, {       \\"id\\" : \\"235660\\",       \\"organizationId\\" : \\"3317034\\",       \\"staff\\" : {         \\"primaryTeacherId\\" : \\"3349305\\"       },       \\"nickname\\" : \\"Hello1\\",       \\"lowGrade\\" : \\"k\\",       \\"highGrade\\" : \\"k\\",       \\"active\\" : true,       \\"schoolYear\\" : \\"2017\\",       \\"easyLogin\\" : {         \\"enabled\\" : true       },       \\"identifiers\\" : { },       \\"displayName\\" : \\"Hello1\\"     } ]   },   \\"sessionContext\\" : {     \\"sessionType\\" : \\"DAS\\",     \\"sessionToken\\" : \\"7827eb3e-898e-4970-97d0-71d32541fe0d\\",     \\"easyLogin\\" : false   } }","custom_sdm_nav_ctx":"{   \\"user_id\\" : \\"3349305\\",   \\"name\\" : \\"Dev\\",   \\"portalBaseUrl\\" : \\"https://dp-portal-dev1.scholastic-labs.io\\",   \\"orgId\\" : \\"3317034\\",   \\"orgName\\" : \\"ANTIOCH MIDDLE SCHOOL\\",   \\"orgType\\" : \\"school\\",   \\"appCodes\\" : [ \\"word\\", \\"ooka\\" ],   \\"staff\\" : true,   \\"admin\\" : false,   \\"extSessionId\\" : \\"7827eb3e-898e-4970-97d0-71d32541fe0d\\",   \\"extSessionEndpoint\\" : \\"https://cnp0ebsm29.execute-api.us-east-1.amazonaws.com/dev1/extendedsession\\",   \\"appCode\\" : \\"ooka\\",   \\"appId\\" : \\"47\\",   \\"parentOrgId\\" : \\"3317035\\",   \\"env\\" : \\"dev1\\",   \\"role\\" : \\"educator\\",   \\"iamUserId\\" : \\"98186632\\" }","custom_timezone_id":"UTC-05:00","launch_presentation_locale":"en_us","lis_person_contact_email_primary":"dnadgar@scholastic.com","lis_person_name_family":"Dev","lis_person_name_full":"Ooka Dev","lis_person_name_given":"Ooka","lti_message_type":"basic-lti-launch-request","lti_version":"LTI-1p0","oauth_consumer_key":"l0JkeOfrC2g2ALqB1dtghOjuxP8a","oauth_nonce":"104439548438870","oauth_signature_method":"HMAC-SHA1","oauth_timestamp":"1520438965","oauth_version":"1.0","resource_link_id":"sdm","roles":"Instructor","tool_consumer_info_product_family_code":"ScholasticDigitalPlatform","tool_consumer_info_version":"2013111804.04","tool_consumer_instance_name":"dev1","user_id":"3349305"}
"""

TEACHER_SDM_LAUNCH_REQUEST_QA1 = """
{"context_id":"9","custom_country_code":"USA","custom_dp_launch":"{   \\"identifiers\\" : {     \\"staffId\\" : \\"243855\\"   },   \\"orgContext\\" : {     \\"organization\\" : {       \\"id\\" : \\"27130\\",       \\"name\\" : \\"VENICE HEIGHTS ELEM SCHOOL\\",       \\"orgType\\" : \\"school\\",       \\"identifiers\\" : {         \\"ucn\\" : \\"600084459\\",         \\"source\\" : \\"SPS\\",         \\"spsOrgId\\" : \\"211552\\"       },       \\"lastModifiedDate\\" : \\"2018-02-19T17:56:03.000-0500\\",       \\"address\\" : {         \\"city\\" : \\"SANDUSKY\\",         \\"state\\" : \\"OH\\",         \\"zipCode\\" : \\"44870\\",         \\"address1\\" : \\"4501 VENICE HEIGHTS BLVD\\"       },       \\"countryCode\\" : \\"USA\\",       \\"currentSchoolYear\\" : \\"2017\\",       \\"overrideSchoolYearStart\\" : false,       \\"schoolStart\\" : {         \\"monthOfYear\\" : 8,         \\"dayOfMonth\\" : 1       },       \\"betaTester\\" : false     },     \\"entitlements\\" : [ {       \\"id\\" : \\"55\\",       \\"name\\" : \\"Ooka Island Adventure\\",       \\"applicationCode\\" : \\"ooka\\",       \\"url\\" : \\"https://ookadogsled.qa.micro.scholastic.com/auth/lti\\",       \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/ooka_logo.png\\",       \\"active\\" : true,       \\"rosterSupport\\" : \\"full\\"     } ],     \\"currentSchoolCalendar\\" : {       \\"description\\" : \\"2017-2018 School Year\\",       \\"startDate\\" : \\"2017-08-01\\",       \\"endDate\\" : \\"2018-07-31\\",       \\"timezone\\" : \\"America/New_York\\"     },     \\"roles\\" : [ \\"teacher\\" ]   },   \\"launchContext\\" : {     \\"application\\" : {       \\"id\\" : \\"55\\",       \\"name\\" : \\"Ooka Island Adventure\\",       \\"applicationCode\\" : \\"ooka\\",       \\"url\\" : \\"https://ookadogsled.qa.micro.scholastic.com/auth/lti\\",       \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/ooka_logo.png\\",       \\"active\\" : true,       \\"rosterSupport\\" : \\"full\\"     },     \\"productEntitlements\\" : [ {       \\"id\\" : \\"111\\",       \\"name\\" : \\"Ooka Island Adventure\\",       \\"productCode\\" : \\"ooka\\",       \\"applicationId\\" : \\"55\\",       \\"active\\" : true,       \\"includesStudentAccess\\" : true,       \\"teacherDirectedSubscriptions\\" : {         \\"enabled\\" : false       }     } ],     \\"role\\" : \\"teacher\\"   },   \\"teacherContext\\" : {     \\"classes\\" : [ {       \\"id\\" : \\"44849\\",       \\"organizationId\\" : \\"27130\\",       \\"staff\\" : {         \\"primaryTeacherId\\" : \\"243855\\"       },       \\"nickname\\" : \\"Gayathri\'s Class\\",       \\"lowGrade\\" : \\"1\\",       \\"highGrade\\" : \\"1\\",       \\"active\\" : true,       \\"schoolYear\\" : \\"2017\\",       \\"easyLogin\\" : {         \\"enabled\\" : true       },       \\"identifiers\\": { },       \\"displayName\\" : \\"Gayathri\'s Class\\"     } ]   },   \\"sessionContext\\" : {     \\"sessionType\\" : \\"DAS\\",     \\"sessionToken\\" : \\"654d8ce9-521e-4691-8e96-a1db464a36f6\\",     \\"easyLogin\\" : false   } }","custom_sdm_nav_ctx":"{   \\"user_id\\" : \\"243855\\",   \\"name\\" : \\"test\\",   \\"portalBaseUrl\\" : \\"https: //dp-portal-qa1.scholastic.com\\",   \\"orgId\\" : \\"27130\\",   \\"orgName\\" : \\"VENICEHEIGHTSELEMSCHOOL\\",   \\"orgType\\" : \\"school\\",   \\"appCodes\\" : [ \\"ooka\\" ],   \\"staff\\" : true,   \\"admin\\" : false,   \\"extSessionId\\" : \\"654d8ce9-521e-4691-8e96-a1db464a36f6\\",   \\"extSessionEndpoint\\" : \\"https: //jw1nnu8eu0.execute-api.us-east-1.amazonaws.com/qa1/extendedsession\\",   \\"appCode\\" : \\"ooka\\",   \\"appId\\" : \\"55\\",   \\"env\\" : \\"qa1\\",   \\"role\\" : \\"educator\\",   \\"iamUserId\\" : \\"97766345\\" }","custom_timezone_id":"UTC-05: 00","launch_presentation_locale":"en_us","lis_person_contact_email_primary":"ooka.t1@sch.com","lis_person_name_family":"test","lis_person_name_full":"ookatest","lis_person_name_given":"ooka","lti_message_type":"basic-lti-launch-request","lti_version":"LTI-1p0","oauth_consumer_key":"FJfDkDA3WnoK6VWyhZDokTVfgfsa","oauth_nonce":"36772369700954","oauth_signature":"O+Enj7bAohiXjujgxajq4PSKNjk=","oauth_signature_method":"HMAC-SHA1","oauth_timestamp":"1524779519","oauth_version":"1.0","resource_link_id":"sdm","roles":"Instructor","tool_consumer_info_product_family_code":"ScholasticDigitalPlatform","tool_consumer_info_version":"2013111804.04","tool_consumer_instance_name":"qa1","user_id":"243855"}
"""

SCHOOL_ADMIN_SDM_LAUNCH_REQUEST = """
{"context_id":"9","custom_country_code":"USA","custom_dp_launch":"{ \\"identifiers\\" :  { \\"staffId\\" : \\"3718161\\" } , \\"orgContext\\" : { \\"organization\\" : { \\"id\\" : \\"383\\", \\"name\\" : \\"RED LAKE ELEMENTARY SCHOOL\\", \\"parent\\" : \\"3317148\\", \\"orgType\\" : \\"school\\", \\"identifiers\\" :  { \\"ucn\\" : \\"600067326\\", \\"source\\" : \\"SPS\\", \\"spsOrgId\\" : \\"11803354\\" } , \\"lastModifiedDate\\" : \\"2017-05-10T15:00:43.000-0400\\", \\"address\\" :  { \\"city\\" : \\"REDLAKE\\", \\"state\\" : \\"MN\\", \\"zipCode\\" : \\"56671\\", \\"address1\\" : \\"HWY 1\\" } , \\"countryCode\\" : \\"USA\\", \\"currentSchoolYear\\" : \\"2017\\", \\"overrideSchoolYearStart\\" : false, \\"schoolStart\\" :  { \\"monthOfYear\\" : 8, \\"dayOfMonth\\" : 1 } , \\"betaTester\\" : false, \\"siteAuthStatus\\" : false, \\"useSchoolRostering\\" : false }, \\"entitlements\\" : [  { \\"id\\" : \\"1\\", \\"name\\" : \\"Reading Pro\\", \\"applicationCode\\" : \\"srpus\\", \\"url\\" : \\"http://localhost:8080/litpro/lti\\", \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/srpus_logo.png\\", \\"active\\" : false, \\"groupCode\\" : \\"RP\\", \\"rosterSupport\\" : \\"full\\" } ,  { \\"id\\" : \\"47\\", \\"name\\" : \\"Ooka Island Adventure\\", \\"applicationCode\\" : \\"ooka\\", \\"url\\" : \\"http://services.ooka-dev.scholastic.com/auth/lti\\", \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/ooka_logo.png\\", \\"active\\" : true, \\"rosterSupport\\" : \\"full\\" } ], \\"currentSchoolCalendar\\" :  { \\"description\\" : \\"2017-2018 School Year\\", \\"startDate\\" : \\"2017-08-01\\", \\"endDate\\" : \\"2018-07-31\\", \\"timezone\\" : \\"America/New_York\\" } , \\"roles\\" : [ \\"schoolAdmin\\" ] }, \\"launchContext\\" : { \\"application\\" :  { \\"id\\" : \\"47\\", \\"name\\" : \\"Ooka Island Adventure\\", \\"applicationCode\\" : \\"ooka\\", \\"url\\" : \\"http://services.ooka-dev.scholastic.com/auth/lti\\", \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/ooka_logo.png\\", \\"active\\" : true, \\"rosterSupport\\" : \\"full\\" } , \\"productEntitlements\\" : [ { \\"id\\" : \\"115\\", \\"name\\" : \\"Ooka Island Adventure\\", \\"productCode\\" : \\"ooka\\", \\"applicationId\\" : \\"47\\", \\"active\\" : true, \\"includesStudentAccess\\" : true, \\"teacherDirectedSubscriptions\\" :  { \\"enabled\\" : false } } ], \\"role\\" : \\"teacher\\" }, \\"teacherContext\\" :  { \\"classes\\" : [ ] } , \\"sessionContext\\" :  { \\"sessionType\\" : \\"das\\", \\"sessionToken\\" : \\"d7af3bd9-29e7-43d9-9357-746422005417\\", \\"impersonatedByCsrId\\" : \\"60630\\", \\"easyLogin\\" : false } }","custom_sdm_nav_ctx":"  { \\"user_id\\" : \\"3718161\\", \\"name\\" : \\"sadmin\\", \\"portalBaseUrl\\" : \\"https://dp-portal-dev1.scholastic-labs.io\\", \\"orgId\\" : \\"383\\", \\"orgName\\" : \\"RED LAKE ELEMENTARY SCHOOL\\", \\"orgType\\" : \\"school\\", \\"appCodes\\" : [ \\"srpus\\", \\"ooka\\" ], \\"staff\\" : true, \\"admin\\" : true, \\"extSessionId\\" : \\"d7af3bd9-29e7-43d9-9357-746422005417\\", \\"extSessionEndpoint\\" : \\"https://cnp0ebsm29.execute-api.us-east-1.amazonaws.com/dev1/extendedsession\\", \\"appCode\\" : \\"ooka\\", \\"appId\\" : \\"47\\", \\"parentOrgId\\" : \\"3317148\\", \\"env\\" : \\"dev1\\", \\"role\\" : \\"educator\\", \\"iamUserId\\" : \\"98201905\\" } ","custom_timezone_id":"UTC-05:00","launch_presentation_locale":"en_us","lis_person_contact_email_primary":"ooka.sadmin@gmail.com","lis_person_name_family":"sadmin","lis_person_name_full":"ooka sadmin","lis_person_name_given":"ooka","lti_message_type":"basic-lti-launch-request","lti_version":"LTI-1p0","oauth_consumer_key":"l0JkeOfrC2g2ALqB1dtghOjuxP8a","oauth_nonce":"23856858685695","oauth_signature":"U9TZR2Q+mGbUEqhnmw7K0nRvA1o=","oauth_signature_method":"HMAC-SHA1","oauth_timestamp":"1522295423","oauth_version":"1.0","resource_link_id":"sdm","roles":"urn:lti:instrole:ims/lis/Administrator","tool_consumer_info_product_family_code":"ScholasticDigitalPlatform","tool_consumer_info_version":"2013111804.04","tool_consumer_instance_name":"dev1","user_id":"3718161"}
"""

DISTRICT_ADMIN_SDM_LAUNCH_REQUEST = """
{"context_id":"9","custom_country_code":"USA","custom_dp_launch":"{ \\"identifiers\\" :  { \\"staffId\\" : \\"3718160\\" } , \\"orgContext\\" : { \\"organization\\" : { \\"id\\" : \\"797\\", \\"name\\" : \\"#Virginia Beach Test District 1\\", \\"orgType\\" : \\"district\\", \\"identifiers\\" :  { \\"sourceId\\" : \\"5787aa1978ef4c010000081f\\", \\"source\\" : \\"Clever\\" } , \\"lastModifiedDate\\" : \\"2016-10-05T04:51:57.000-0400\\", \\"active\\" : true, \\"countryCode\\" : \\"USA\\", \\"currentSchoolYear\\" : \\"2017\\", \\"overrideSchoolYearStart\\" : false, \\"schoolStart\\" :  { \\"monthOfYear\\" : 8, \\"dayOfMonth\\" : 1 } , \\"betaTester\\" : false, \\"siteAuthStatus\\" : false, \\"useSchoolRostering\\" : false }, \\"entitlements\\" : [  { \\"id\\" : \\"20\\", \\"name\\" : \\"Next Step Guided Reading: K-2\\", \\"applicationCode\\" : \\"nsgrak2\\", \\"url\\" : \\"https://tg-credmgr-d.digital.scholastic.com/credManager/nsgra\\", \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/nsgrak2_logo.png\\", \\"active\\" : true, \\"groupCode\\" : \\"NSGRA\\", \\"rosterSupport\\" : \\"roster_only\\" } ,  { \\"id\\" : \\"3\\", \\"name\\" : \\"BookFlix\\", \\"applicationCode\\" : \\"bkflix\\", \\"url\\" : \\"https://tg-credmgr-d.digital.scholastic.com/credManager/bkflix\\", \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/bookflix_logo.png\\", \\"active\\" : true, \\"groupCode\\" : \\"FLIX\\", \\"rosterSupport\\" : \\"full\\" } ,  { \\"id\\" : \\"31\\", \\"name\\" : \\"FreedomFlix\\", \\"applicationCode\\" : \\"fflix\\", \\"url\\" : \\"https://tg-credmgr-d.digital.scholastic.com/credManager/fflix\\", \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/freedomflix_logo.png\\", \\"active\\" : true, \\"groupCode\\" : \\"FLIX\\", \\"rosterSupport\\" : \\"full\\" } ,  { \\"id\\" : \\"21\\", \\"name\\" : \\"Next Step Guided Reading: 3-6\\", \\"applicationCode\\" : \\"nsgra36\\", \\"url\\" : \\"https://tg-credmgr-d.digital.scholastic.com/credManager/nsgra\\", \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/nsgra36_logo.png\\", \\"active\\" : true, \\"groupCode\\" : \\"NSGRA\\", \\"rosterSupport\\" : \\"roster_only\\" } ,  { \\"id\\" : \\"47\\", \\"name\\" : \\"Ooka Island Adventure\\", \\"applicationCode\\" : \\"ooka\\", \\"url\\" : \\"http://services.ooka-dev.scholastic.com/auth/lti\\", \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/ooka_logo.png\\", \\"active\\" : true, \\"rosterSupport\\" : \\"full\\" } ], \\"currentSchoolCalendar\\" :  { \\"description\\" : \\"2017-2018 School Year\\", \\"startDate\\" : \\"2017-08-01\\", \\"endDate\\" : \\"2018-07-31\\", \\"timezone\\" : \\"America/New_York\\" } , \\"roles\\" : [ \\"schoolAdmin\\" ] }, \\"launchContext\\" : { \\"application\\" :  { \\"id\\" : \\"47\\", \\"name\\" : \\"Ooka Island Adventure\\", \\"applicationCode\\" : \\"ooka\\", \\"url\\" : \\"http://services.ooka-dev.scholastic.com/auth/lti\\", \\"thumbnail\\" : \\"//digital.scholastic.com/media/applications/thumbnails/ooka_logo.png\\", \\"active\\" : true, \\"rosterSupport\\" : \\"full\\" } , \\"productEntitlements\\" : [ { \\"id\\" : \\"115\\", \\"name\\" : \\"Ooka Island Adventure\\", \\"productCode\\" : \\"ooka\\", \\"applicationId\\" : \\"47\\", \\"active\\" : true, \\"includesStudentAccess\\" : true, \\"teacherDirectedSubscriptions\\" :  { \\"enabled\\" : false } } ], \\"role\\" : \\"teacher\\" }, \\"teacherContext\\" :  { \\"classes\\" : [ ] } , \\"sessionContext\\" :  { \\"sessionType\\" : \\"das\\", \\"sessionToken\\" : \\"7ec5f6d6-8194-4a7a-a784-7c87e71d3daf\\", \\"impersonatedByCsrId\\" : \\"60630\\", \\"easyLogin\\" : false } }","custom_sdm_nav_ctx":"  { \\"user_id\\" : \\"3718160\\", \\"name\\" : \\"admin\\", \\"portalBaseUrl\\" : \\"https://dp-portal-dev1.scholastic-labs.io\\", \\"orgId\\" : \\"797\\", \\"orgName\\" : \\"#Virginia Beach Test District 1\\", \\"orgType\\" : \\"district\\", \\"appCodes\\" : [ \\"nsgrak2\\", \\"bkflix\\", \\"fflix\\", \\"nsgra36\\", \\"ooka\\" ], \\"staff\\" : true, \\"admin\\" : true, \\"extSessionId\\" : \\"7ec5f6d6-8194-4a7a-a784-7c87e71d3daf\\", \\"extSessionEndpoint\\" : \\"https://cnp0ebsm29.execute-api.us-east-1.amazonaws.com/dev1/extendedsession\\", \\"appCode\\" : \\"ooka\\", \\"appId\\" : \\"47\\", \\"env\\" : \\"dev1\\", \\"role\\" : \\"educator\\", \\"iamUserId\\" : \\"98201904\\" } ","custom_timezone_id":"UTC-05:00","launch_presentation_locale":"en_us","lis_person_contact_email_primary":"ooka.Dadmin@gmail.com","lis_person_name_family":"admin","lis_person_name_full":"ooka admin","lis_person_name_given":"ooka","lti_message_type":"basic-lti-launch-request","lti_version":"LTI-1p0","oauth_consumer_key":"l0JkeOfrC2g2ALqB1dtghOjuxP8a","oauth_nonce":"23119162054957","oauth_signature":"44KFHMK7SjlhXHIJVcudSBusXSY=","oauth_signature_method":"HMAC-SHA1","oauth_timestamp":"1522294686","oauth_version":"1.0","resource_link_id":"sdm","roles":"urn:lti:instrole:ims/lis/Administrator","tool_consumer_info_product_family_code":"ScholasticDigitalPlatform","tool_consumer_info_version":"2013111804.04","tool_consumer_instance_name":"dev1","user_id":"3718160"}
"""

@require_valid_jwt
def example_view(request, game_user_id, jwt_payload):
    return HttpResponse()


@override_settings(JWT_PRIVATE_KEY='gz#fh@jt%jbh_s=o96@yq4!*eww2j-8r)y@z23mj@cos#2v9(!')
class JWTTestCase(TestCase):

    def test_empty_launch_request_payload(self):
        gu = GameUser(id=123, dp_id=123, dp_role='teacher')
        payload = gu.jwt_payload()
        self.assertEqual(payload['dpRole'], 'teacher')
        self.assertFalse('givenName' in payload)
        self.assertFalse('familyName' in payload)
        self.assertFalse('scholasticGradeCode' in payload)
        self.assertFalse('gradeSystemCode' in payload)

    def test_student_payload(self):
        """
        Test that the payload generator does its thing.
        """
        gu = GameUser(id=123, dp_id=123, dp_role='student')
        payload = gu.jwt_payload(json.loads(STUDENT_SDM_LAUNCH_REQUEST))
        self.assertEqual(payload['dpRole'], 'student')
        self.assertEqual(payload['givenName'], 'Ryan')
        self.assertEqual(payload['familyName'], 'Palmer')
        self.assertEqual(payload['districtId'], 3317035)
        self.assertEqual(payload['schoolId'], 3317034)
        self.assertEqual(payload['sectionId'], 168741)
        self.assertEqual(payload['scholasticGradeCode'], '1')
        self.assertEqual(payload['gradeSystemCode'], 'USA')

    def test_teacher_payload(self):
        gu = GameUser(id=123, dp_id=123, dp_role='teacher')
        payload = gu.jwt_payload(json.loads(TEACHER_SDM_LAUNCH_REQUEST))
        self.assertEqual(payload['dpRole'], 'teacher')
        self.assertEqual(payload['givenName'], 'Ooka')
        self.assertEqual(payload['familyName'], 'Dev')
        self.assertEqual(payload['districtId'], 3317035)
        self.assertEqual(payload['schoolId'], 3317034)
        self.assertEqual(payload['sections'], ['168741', '235660'])
        # Teachers aren't attached to a particular section, and have no grade info
        self.assertFalse('sectionId' in payload)
        self.assertFalse('scholasticGradeCode' in payload)
        self.assertFalse('gradeSystemCode' in payload)

    def test_teacher_qa_payload_no_district(self):
        gu = GameUser(id=123, dp_id=123, dp_role='teacher')
        payload = gu.jwt_payload(json.loads(TEACHER_SDM_LAUNCH_REQUEST_QA1))
        self.assertEqual(payload['dpRole'], 'teacher')
        self.assertEqual(payload['givenName'], 'ooka')
        self.assertEqual(payload['familyName'], 'test')
        self.assertNotIn('districtId', payload)
        self.assertEqual(payload['schoolId'], 27130)
        self.assertEqual(payload['sections'], ['44849'])
        # Teachers aren't attached to a particular section, and have no grade info
        self.assertFalse('sectionId' in payload)
        self.assertFalse('scholasticGradeCode' in payload)
        self.assertFalse('gradeSystemCode' in payload)

    def test_school_admin_payload(self):
        """
        Test that the payload generator does its thing.
        """
        gu = GameUser(id=123, dp_id=123)
        payload = gu.jwt_payload(json.loads(SCHOOL_ADMIN_SDM_LAUNCH_REQUEST))
        self.assertEqual(payload['dpRole'], 'schoolAdmin')
        self.assertEqual(payload['givenName'], 'ooka')
        self.assertEqual(payload['familyName'], 'sadmin')
        self.assertEqual(payload['districtId'], 3317148)
        self.assertEqual(payload['schoolId'], 383)
        # School admins have no scholasticGradeCode aren't attached to a particular section.
        self.assertFalse('sectionId' in payload)
        self.assertFalse('sections' in payload)
        self.assertFalse('scholasticGradeCode' in payload)
        self.assertFalse('gradeSystemCode' in payload)

    def test_district_admin_payload(self):
        """
        Test that the payload generator does its thing.
        """
        gu = GameUser(id=123, dp_id=123)
        payload = gu.jwt_payload(json.loads(DISTRICT_ADMIN_SDM_LAUNCH_REQUEST))
        self.assertEqual('districtAdmin', payload['dpRole'])
        self.assertEqual(payload['givenName'], 'ooka')
        self.assertEqual(payload['familyName'], 'admin')
        self.assertEqual(payload['districtId'], 797)
        # School admins have no scholasticGradeCode aren't attached to a particular section.
        self.assertFalse('schoolId' in payload)
        self.assertFalse('sectionId' in payload)
        self.assertFalse('scholasticGradeCode' in payload)
        self.assertFalse('gradeSystemCode' in payload)

    def test_token_tampering(self):
        """
        Test that a modified JWT fails validation
        """
        token = VALID_TOKEN
        decoded = jwt_decode(token)
        self.assertEqual(decoded, {'foo': 'bar', 'gameUserId': 11, 'orig_iat': 1512684264})
        token_split = token.split('.')
        # Set a new payload that contains some modified data
        invalid_token_parts = [
            token_split[0],
            'eyJmb28iOiJiYXoiLCJyeWFuIjoiaXNfY29vbCIsIm9yaWdfaWF0IjoxNTEyNjg0MjY0fQ',
            token_split[1]
        ]
        invalid_token = ".".join(invalid_token_parts)
        with self.assertRaises(jwt.exceptions.DecodeError):
            jwt_decode(invalid_token)


@override_settings(JWT_PRIVATE_KEY='gz#fh@jt%jbh_s=o96@yq4!*eww2j-8r)y@z23mj@cos#2v9(!')
class JWTDecoratorTestCase(TestCase):

    def setUp(self):
        self.factory = RequestFactory()

    def test_require_valid_jwt_decorator(self):
        # No JWT - forbidden
        request = self.factory.get('test-path')
        response = example_view(request)
        self.assertEqual(response.status_code, 403)

        # Invalid JWT - bad request
        request = self.factory.get('test-path', **{'HTTP_AUTHORIZATION': 'silly-human'})
        response = example_view(request)
        self.assertEqual(response.status_code, 400)

        request = self.factory.get('test-path', **{'HTTP_AUTHORIZATION': 'Bearer something'})
        response = example_view(request)
        self.assertEqual(response.status_code, 400)

        request = self.factory.get('test-path', **{'HTTP_AUTHORIZATION': 'Bearer %s' % VALID_TOKEN})
        response = example_view(request)
        self.assertEqual(response.status_code, 200)
