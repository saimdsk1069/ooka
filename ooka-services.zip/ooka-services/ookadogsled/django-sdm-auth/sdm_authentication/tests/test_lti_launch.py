import json
from django.conf import settings
from django.test import mock, TestCase
from django.shortcuts import reverse
from gameplay.models import GameUser
from .testing_consts import *
from ..views import get_or_create_sdm_game_user, LaunchLTI


# patch time.time() to get past oauth validation
mock_time = mock.Mock()
mock_time.return_value = 1510945239


class LTILaunchTestCase(TestCase):

    @mock.patch('time.time', mock_time)
    def test_successful_post(self):
        """
        Test that the endpoint accepts data posted from SDM and sets cookies correctly
        """

        self.assertEqual(GameUser.objects.count(), 0)

        # do the post
        response = self.client.post(reverse('lti_launch'),
                                    SDM_POST_DATA,
                                    content_type="application/x-www-form-urlencoded",
                                    HTTP_X_FORWARDED_PROTO="http",  # set the headers required
                                    HTTP_HOST="api.word-dev.scholastic.com",
                                    REQUEST_URI="/dev/lti")

        self.assertEqual(response.status_code, 303)

        # we should have two cookies set
        self.assertIn('sdm_nav_ctx', response.cookies)
        self.assertIn(settings.JWT_COOKIE_NAME, response.cookies)

        # and let's make sure that the cookies are reflective of what we posted
        self.assertIn("VERMILION%20PARISH%20LIBRARY", str(response.cookies['sdm_nav_ctx']))

        game_user = GameUser.objects.latest()
        # Spot check to ensure the Launch Request saved.
        self.assertEqual(game_user.lti_launch_request_get()['user_id'], '3367018')

    def test_timeout_failure(self):
        """
        Test that requests older than 60 seconds do not pass auth validation
        (do not patch the time.time() method)
        """
        response = self.client.post(reverse('lti_launch'),
                                    SDM_POST_DATA,
                                    content_type="application/x-www-form-urlencoded",
                                    HTTP_X_FORWARDED_PROTO="http",  # set the headers required
                                    HTTP_HOST="api.word-dev.scholastic.com",
                                    REQUEST_URI="/dev/lti")
        self.assertEqual(response.status_code, 303)

        # Our cookie should not be set
        self.assertNotIn('sdm_nav_ctx', response.cookies)

    @mock.patch('time.time', mock_time)
    def test_bad_key(self):
        """
        Test that passing in a bad consumer key will break things
        """
        bad_post_data = SDM_POST_DATA.replace("l0JkeOfrC2g2ALqB1dtghOjuxP8a", "l0jkeOfrC2g2ALqB1dtghOjuxP8a")

        response = self.client.post(reverse('lti_launch'),
                                    bad_post_data,
                                    content_type="application/x-www-form-urlencoded",
                                    HTTP_X_FORWARDED_PROTO="http",  # set the headers required
                                    HTTP_HOST="api.word-dev.scholastic.com",
                                    REQUEST_URI="/dev/lti")
        self.assertEqual(response.status_code, 303)

        # Our cookie should not be set
        self.assertNotIn('sdm_nav_ctx', response.cookies)

    def test_generate_base_string(self):
        """
        Test that the base string is generated correctly from POST data
        """
        # load a dictionary with the request params
        request_params = json.loads(SDM_POST_JSON)

        # set the url
        launch_url = "http://api.word-dev.scholastic.com/dev/lti"

        # compare known good string with generated string
        self.assertEqual(LaunchLTI._get_base_string(launch_url, request_params), CORRECT_BASE_STRING)

    def test_get_or_create_sdm_game_user(self):
        game_user = get_or_create_sdm_game_user(123, 'teacher')
        self.assertEqual(game_user.dp_id, 123)
        self.assertEqual(game_user.dp_role, 'teacher')
