from django.test import TestCase
from gameplay.models import GameUser


class TestModels(TestCase):

    def setUp(self):
        self.game_user = GameUser.objects.create(dp_id=1, dp_role='student')

    def test_lti_launch_request_method(self):
        # No launch packet = should be empty
        self.assertEqual(self.game_user.lti_launch_request_get(), None)
        test_lti_launch_request = {'some': 'request'}
        self.game_user.lti_launch_request_save(test_lti_launch_request)
        self.assertEqual(self.game_user.lti_launch_request_get(), test_lti_launch_request)
