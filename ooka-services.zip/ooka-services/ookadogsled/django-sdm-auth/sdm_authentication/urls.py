from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^lti$', views.LaunchLTI.as_view(), name='lti_launch'),
]
