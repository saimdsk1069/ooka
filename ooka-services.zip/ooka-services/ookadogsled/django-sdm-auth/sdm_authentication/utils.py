import base64
import jwt
from django.http import HttpResponseRedirect, JsonResponse
from django.conf import settings
from urllib.parse import quote
from functools import wraps
from django.utils.decorators import available_attrs


def quote_with_slashes(text):
    """
    When we're URL encoding during the OAuth process we are expecting that forward slashes also be encoded.
    This is not normally needed.
    """
    quoted_text = quote(text)
    quoted_text = quoted_text.replace("/", "%2F")
    return quoted_text


class HttpResponseSeeOther(HttpResponseRedirect):
    status_code = 303


def jwt_encode(payload):
    return jwt.encode(
        payload,
        settings.JWT_PRIVATE_KEY,
        settings.JWT_ALGORITHM
    ).decode('utf-8')


def jwt_decode(token):
    return jwt.decode(
        token,
        settings.JWT_PRIVATE_KEY,
        verify=True,
        options={'verify_exp': True},
        leeway=settings.JWT_LEEWAY,
        audience=settings.JWT_AUDIENCE,
        issuer=settings.JWT_ISSUER,
        algorithms=[settings.JWT_ALGORITHM],
    )


def base64_url_decode(inp):
    padding_factor = (4 - len(inp) % 4) % 4
    inp += "="*padding_factor
    return base64.b64decode(inp.translate(dict(zip(map(ord, u'-_'), u'+/'))))


def require_valid_jwt(view_func):
    """
    View decorator that makes some JWT signed with our secret key a requirement for the request.
    """

    def wrapped_view(*args, **kwargs):
        request = args[0]
        jwt_header_string = request.META.get('HTTP_AUTHORIZATION', None)
        if not jwt_header_string:
            return JsonResponse({"status": "error", "message": "No JWT header string"}, status=403)

        # Validate the Authorization header
        prefix = "Bearer "
        if not jwt_header_string.startswith(prefix):
            return JsonResponse({"status": "error", "message": "Bad request - missing Bearer token."}, status=400)

        unverified_jwt = jwt_header_string[len(prefix):]

        try:
            payload = jwt_decode(unverified_jwt)
        except jwt.ExpiredSignatureError as e:
            return JsonResponse({"status": "error", "message": "Expired signature."}, status=400)
        except jwt.exceptions.InvalidTokenError as e:
            return JsonResponse({"status": "error", "message": "Invalid JWT: %s" % e}, status=400)

        try:
            kwargs['game_user_id'] = payload['gameUserId']
        except KeyError:
            return JsonResponse({"status": "error", "message": "Missing gameUserId in JWT"}, status=400)

        try:
            kwargs['game_user_id'] = int(kwargs['game_user_id'])
        except ValueError:
            # logger.error("student_id was not an integer")
            return JsonResponse({"status": "error", "message": "game_user_id was not an integer"}, status=400)

        kwargs['jwt_payload'] = payload
        return view_func(*args, **kwargs)

    return wraps(view_func, assigned=available_attrs(view_func))(wrapped_view)
