import json
import time
from base64 import b64encode

from Crypto.Hash import HMAC, SHA
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import View
from django.conf import settings
from .utils import quote_with_slashes as quote, HttpResponseSeeOther, jwt_encode
from gameplay.models import GameUser

MAX_COOKIE_LENGTH = 4096


def get_or_create_sdm_game_user(dp_id, dp_role):
    """
    :param dp_id: DP User Id
    :param dp_role: Launch context role
    :return: GameUser object
    """

    try:
        game_user = GameUser.objects.get(dp_id=dp_id)
        if game_user.dp_role != dp_role:
            raise Exception("Found a game user with a phony dp_role value.")
    except GameUser.DoesNotExist:
        game_user = GameUser.objects.create(dp_id=dp_id, dp_role=dp_role)
    return game_user


class LaunchLTI(View):
    """
    LTI Launch view, accepts a POST from SDM, validates the request and then sets cookies as needed
    for SDM Nav bar and access control in other endpoints.
    """
    http_method_names = ['post']  # only accept posts to this view

    def __init__(self, *args, **kwargs):
        super(LaunchLTI, self).__init__(*args, **kwargs)

        # TODO: Store in env specific settings for ENV variables
        self.oauth_env = 'dev'
        self.redirect_location = settings.SPA_URL

    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        """
        Disable CSRF protection on this view.
        """
        return super(LaunchLTI, self).dispatch(request, *args, **kwargs)

    def post(self, request):
        """
        Accept a POST from SDM as a application/x-www-form-urlencoded.
        Return sdm_nav_ctx cookie, dp_launch cookie, dp_jwt cookie
        """

        # QueryDicts are multidicts - meaning each key is mapped to a list. We don't need this.
        request_params = {k: i for k, i in request.POST.items()}

        # the current url should match the url passed as the launchUrl.
        launch_url = "%s://%s%s" % (request.META['HTTP_X_FORWARDED_PROTO'],
                                    request.META['HTTP_HOST'],
                                    request.META['REQUEST_URI'])

        # check to make sure that everything passes oauth
        if not self._oauth_validates(launch_url, request_params):
            return HttpResponseSeeOther(self.redirect_location)

        # everything has passed validation, set the cookies and return the response
        custom_sdm_nav_ctx_str = request_params.get('custom_sdm_nav_ctx', None)
        custom_sdm_nav_ctx = json.loads(custom_sdm_nav_ctx_str)
        custom_dp_launch_str = request_params.get('custom_dp_launch', None)
        custom_dp_launch = json.loads(custom_dp_launch_str)

        duration = 60 * 60 * 24  # 1 day
        response = HttpResponseSeeOther(self.redirect_location)
        sdm_nav_ctx_cookie = quote(json.dumps(custom_sdm_nav_ctx))
        assert len(sdm_nav_ctx_cookie) < MAX_COOKIE_LENGTH
        response.set_cookie('sdm_nav_ctx', sdm_nav_ctx_cookie, max_age=duration, domain=settings.COOKIE_DOMAIN)

        # Provision the GameUser and set the JWT
        dp_id = request_params.get('user_id', None)
        dp_role = custom_dp_launch['launchContext']['role']
        game_user = get_or_create_sdm_game_user(dp_id, dp_role)

        # Store the full LTI Launch Request
        game_user.lti_launch_request_save(request_params)

        # Prepare the JWT cookie using the whole request_params
        lti_launch_request = request_params
        payload = game_user.jwt_payload(lti_launch_request)
        token = jwt_encode(payload)
        assert len(token) < MAX_COOKIE_LENGTH
        response.set_cookie(settings.JWT_COOKIE_NAME, token, max_age=duration, domain=settings.COOKIE_DOMAIN)

        return response

    def _oauth_validates(self, launch_url, request_params):
        # 1. Retrieve the consumer secret that corresponds to the key passed in the oauth_consumer_key field
        try:
            oauth_consumer = request_params.get('oauth_consumer_key', None)
            oauth_signature = request_params.get('oauth_signature', None)
            oauth_env = self._get_oauth_env(oauth_consumer)
        except KeyError:
            return False

        # 2. Use the secret to generate the oAuth signature per the LTI Basic Launch standard
        # a. generate the base_string

        base_string = LaunchLTI._get_base_string(launch_url, request_params)
        base_string = base_string.encode('utf-8')

        key = bytes(oauth_env['oauth_secret'] + '&', encoding='utf-8')

        # Use the secret and the base string to generate a signature and make sure that it matches
        # the signature passed with the request
        hmac = HMAC.new(key, base_string, digestmod=SHA)
        generated_signature = b64encode(hmac.digest()).decode()

        # Reject the request if the auth signatures don't match
        if generated_signature != oauth_signature:
            return False

        # Reject if the oauth request is too old
        oauth_timestamp = float(request_params.get('oauth_timestamp', 0))
        if (time.time() - oauth_timestamp) > 60:
            return False

        return True

    @staticmethod
    def _get_base_string(resource_url, params, method="POST"):
        """
        Return the resource and params as one big string that is encoded with URI encoding.
        """
        # Start with something like `POST&https://example.com&`
        base_string = method + '&' + quote(resource_url) + '&'
        del params['oauth_signature']

        # I don't trust python dictionaries to maintain sorting correctly, so this should ensure it
        sorted_keys = sorted(params.keys())
        for i in range(len(sorted_keys)):
            base_string = base_string + quote(sorted_keys[i]) + quote('=') + quote(quote(params[sorted_keys[i]])) + quote('&')

        # remove the final encoded '&'
        base_string = base_string[:-3]

        return base_string

    def _get_oauth_env(self, oauth_consumer):

        # TODO: These secret keys should not live here.
        if oauth_consumer == 'l0JkeOfrC2g2ALqB1dtghOjuxP8a':
            env = {
                'oauth_env': self.oauth_env,
                'oauth_secret': 'TZKQl9qToKK1dp2G2G4zcKp2meIa',
                'oauth_consumer_key': oauth_consumer
            }
        elif oauth_consumer == 'whuWmZxMXDqsbxNG7ioqjs23Nfoa':
            env = {
                'oauth_env': self.oauth_env,
                'oauth_secret': 'KomjmKF2J2j9CPkaSa9yrOyHAyoa',
                'oauth_consumer_key': oauth_consumer
            }
        elif oauth_consumer == 'FJfDkDA3WnoK6VWyhZDokTVfgfsa':
            env = {
                'oauth_env': self.oauth_env,
                'oauth_secret': 'Wzc_c2n2fwhhH24vd2DjMUDg79oa',
                'oauth_consumer_key': oauth_consumer
            }
        else:
            raise KeyError('Invalid consumer key provided.')

        return env

