from fabric.api import *
from fabric.colors import green
from hypchat import HypChat

hc = HypChat("hmQqwA69g6naHM5T03mdx6MpuOqunMFckJtiVIj1")

env.use_ssh_config = True

@task
def restart_apache2():
    """Reboot Apache2 server."""
    sudo("apachectl restart")

@task
@hosts("ooka_dev")
def dev():
    with cd('/var/www/ooka-services-dev.scholastic.com/ookadogsled'), prefix('source venv/bin/activate'):
        run('git pull origin dev')
        run('pip install -r requirements.txt --upgrade')
        run('python manage.py migrate')
        run('python manage.py collectstatic --noinput')
        run('celery multi restart ooka_dev -A ookadogsled -l DEBUG')
        execute(restart_apache2)
        print(green("Finished deploying to Ooka Dogsled Dev"))
        hc.get_room(4212381).notification("Successfully deployed Ooka Dogsled Dev.", notify=True, color="green")
