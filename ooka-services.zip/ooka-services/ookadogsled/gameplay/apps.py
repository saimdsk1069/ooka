from django.apps import AppConfig


class GameplayConfig(AppConfig):
    name = 'gameplay'
