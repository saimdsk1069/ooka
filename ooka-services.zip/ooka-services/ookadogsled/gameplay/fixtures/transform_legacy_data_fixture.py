import json


def transform():
    # To export legacy data for the tables that are actively managed by Django:
    # ./manage.py dumpdata --indent 4 ookaportal.Activity ookaportal.ActivityLevel ookaportal.ActivityLevelReportMappings ookaportal.ActivityLevelText ookaportal.Book ookaportal.Page ookaportal.PageText ookaportal.Cheereadermessages ookaportal.GuidedPlayFlow ookaportal.Items ookaportal.PopAndDropAnswer ookaportal.PopAndDropQuestion ookaportal.PopAndDropQuestionTextTiming ookaportal.Region  ookaportal.Text ookaportal.ZobotGuidedPlay > ooka_sdm_db_fixture.json

    file_object = open('ooka_sdm_db_fixture.json', "r")
    file_contents = file_object.read()
    file_json = json.loads(file_contents)

    # Rename all ookaportal.* tables to gameplay.*
    for k, v in enumerate(file_json):
        file_json[k]['model'] = 'gameplay.%s' % v['model'][11:]

        model_name_replacements = {
            "gameplay.page": "gameplay.bookpage",
            "gameplay.pagetext": "gameplay.bookpagetext",
            "gameplay.cheereadermessages": "gameplay.cheereadermessage",
            "gameplay.items": "gameplay.inventoryitem"
        }
        if file_json[k]['model'] in model_name_replacements:
            file_json[k]['model'] = model_name_replacements[file_json[k]['model']]
        print "New name", file_json[k]['model']

    # Field renaming
    for k, v in enumerate(file_json):
        field_replacements = {
            'region': {},
            'activity': {
                "activityname": "name",
                "activityscenename": "scene_name",
                "isscorebased": "is_score_based",
                "maxlevel": "max_level",
                "activityreportdisplay": "report_display"
            },
            'activitylevel': {
                "activitylevellabel": "label",
                "activity": "activity_id",
                "levelnumber": "level_number",
                "orderid": "order",
                "nextactivitylevel": "next_activity_level_id",
                "unlocktypeid": "unlock_type_id",
                "unlockvalue": "unlock_value",
                "questiontype": "question_type",
                "customlevelforuserid": None
            },
            'activitylevelreportmappings': {
                "activityid": "activity_id",
                "activitylevelnumber": "activity_level_number",
                "reportleveldisplay": "report_level_display"
            },
            'activityleveltext': {
                "activitylevel": "activity_level_id",
                "text": "text_id",
                "readabletext": "readable_text",
                "orderid": "order"
            },
            'book': {
                "bookname": "name",
                "soundpath": "sound_path",
                "booklevel": "book_level",
                "nextbookid": "next_book_id",
                "readablename": "readable_name",
            },
            'bookpage': {
                "bookid": "book_id",
                "pagenumber": "page_number",
                "imagepath": None
            },
            'bookpagetext': {
                "pageid": "page_id",
                "textcontent": "text_content",
                "xlocation": "x_location",
                "ylocation": "y_location",
                "dropincomment": "drop_in_comment",
                "soundpath": "sound_path",
                "orderid": "order"
            },
            'cheereadermessage': {
                "messagename": "message_name",
                "messageaudioname": "message_audio_name"
            },
            'guidedplayflow': {
                "activity": "activity_id"
            },
            'inventoryitem': {
                "itemname": "name",
                "itemprice": "price",
                "itemdescription": "description",
                "itemcategory": "category",
                "itemtier": "tier",
                "clothesid": "clothes_id",
                "prereqitem": "prereq_item_id"
            },
            'popanddropanswer': {
                "questionid": "question_id",
                "audioclip": "audio_clip",
            },
            'popanddropquestion': {
                "bookid": "book_id",
                "questiontext": "question_text",
                "audioclip": "audio_clip",
                "reviewonpagenumber": "review_on_page_number"
            },
            'popanddropquestiontexttiming': {
                "questionid": "question_id"
            },
            'text': {
                "texttypeid": "text_type_id",
                "soundfilepath": "sound_file_path"
            },
            'zobotguidedplay': {
                "activity_level": "activity_level_id",
                "guided_play_level": "guided_play_level_id",
                "activity": "activity_id"
            }
        }

        for old_field_name, field_value in file_json[k]['fields'].items():
            if old_field_name in field_replacements[file_json[k]['model'][9:]]:
                if field_replacements[file_json[k]['model'][9:]][old_field_name]:
                    new_field_name = field_replacements[file_json[k]['model'][9:]][old_field_name]
                    file_json[k]['fields'][new_field_name] = field_value
                    del (file_json[k]['fields'][old_field_name])
                else:
                    # We don't need this field anymore.
                    # print "Removing field", old_field_name, file_json[k]['fields'][old_field_name]
                    del (file_json[k]['fields'][old_field_name])

        for field_name, field_value in file_json[k]['fields'].items():
            if field_name[-3:] == '_id' and field_value == 0 and field_name is not 'clothes_id':
                # print "Another problem, FKs can't be 0.", field_name, field_value
                file_json[k]['fields'][field_name] = None

    for k, v in enumerate(file_json):
        if v['pk'] == 0:
            print "We have a problem with:", v
            print "Deleting", k, file_json[k]
            del(file_json[k])

    # Add missing data

    # @TODO What can we do about this??
    file_json.append({
        "pk": 9000,
        "model": "gameplay.activitylevel",
        "fields": {
            "activity_id": 25,
            "next_activity_level_id": None,
            "label": "Game finished?",
            "level_number": 86,
            "unlock_type_id": 9,
            "question_type": 3,
            "active": 1,
            "order": 1,
            "unlock_value": 0.0
        }
    })

    # Fold in additional data from the database
    additional_data_file_object = open('ooka_sdm_db_additional_records.json', "r")
    additional_data_file_contents = additional_data_file_object.read()
    additional_data_file_json = json.loads(additional_data_file_contents)
    file_json.extend(additional_data_file_json)

    with open('transformed_data.json', 'w') as outfile:
        json.dump(file_json, outfile, indent=4)
    print "DONE!"

if __name__ == '__main__':
    transform()
