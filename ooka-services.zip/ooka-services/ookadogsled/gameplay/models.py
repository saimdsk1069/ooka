import datetime
import logging
import uuid
from django.conf import settings
from django.db import models
from elasticsearch.exceptions import NotFoundError
from pynamodb.models import Model as PynamoModel
from pynamodb.attributes import JSONAttribute, NumberAttribute, UnicodeAttribute, UTCDateTimeAttribute
from sdm_authentication.models import BaseSDMGameUser
from ookadogsled.elasticsearch_client import es, es_index_name
from reporting.report_constants import al_comprehension_mappings, al_phonological_mappings, al_progress_mapping
logger = logging.getLogger(__name__)


def dynamo_table_name(name): return settings.PROJECT_NAME + '_' + settings.ENV_NAME + '_' + name


class BasePynamoModel(PynamoModel):

    class Meta:
        read_capacity_units = 50
        write_capacity_units = 10
        host = "http://localhost:8000" if settings.ENV_NAME == "local" else None
        region = settings.AWS_DEFAULT_REGION


class Region(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=16)

    def __str__(self):
        return "%s" % self.name


class GameState(BasePynamoModel):
    game_user_id = NumberAttribute(hash_key=True)
    tag = UnicodeAttribute(range_key=True)
    data = JSONAttribute(null=False)
    created = UTCDateTimeAttribute(null=False, default=datetime.datetime.utcnow)
    modified = UTCDateTimeAttribute(null=False, default=datetime.datetime.utcnow)

    class Meta(BasePynamoModel.Meta):
        table_name = dynamo_table_name('GameState')

    def update(self, *args, **kwargs):
        kwargs['actions'].append(GameState.modified.set(datetime.datetime.utcnow()))
        return super(GameState, self).update(*args, **kwargs)

    # TODO: GameState updates should sync UserActivityLevelProgress and UserBookProgress for reporting purposes


class GameUser(BaseSDMGameUser):
    auth_token = models.UUIDField(default=uuid.uuid4, blank=True, null=True)
    region = models.ForeignKey(Region, null=True, blank=True)
    # Ookamist is actually in cents. Round down to nearest 100.
    ooka_mist = models.IntegerField(default=1000)
    elf_count = models.IntegerField(default=0)
    avatar_body_type = models.IntegerField(null=True, default=0)
    avatar_mesh_data = models.TextField(default='__')
    avatar_material_data = models.TextField(default='__')
    stickers = models.TextField(null=True, default=None)
    clothes_position = models.IntegerField(null=True, blank=True)
    playground_position = models.IntegerField(default=0)
    music_position = models.IntegerField(null=True, blank=True)
    zopet_position = models.IntegerField(null=True, blank=True)
    viewing_category = models.IntegerField(null=True, default=0)
    current_readirect_step = models.IntegerField(default=0)
    readirect_custom_level = models.IntegerField(default=0)
    start_my_compass = models.BooleanField(default=False, verbose_name='Start My Compass')
    time_played = models.IntegerField(default=0)
    zopet_status = models.IntegerField(null=True, default=0)
    completed_game_states = models.IntegerField(null=True, default=0)
    all_items_unlocked = models.BooleanField(default=False)
    finished_play_flow = models.BooleanField(default=False)
    flag_readirect = models.BooleanField(default=True, verbose_name="Enable READirect")
    reporting_enabled = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)

    def __str__(self):
        return "GameUser #%d - DP %s %d" % (self.id, self.dp_role.capitalize(), self.dp_id)

    class Meta:
        get_latest_by = 'id'

    def regenerate_auth_token(self):
        self.auth_token = uuid.uuid4()
        self.save(update_fields=['auth_token'])

    def jwt_payload(self, *args, **kwargs):
        payload = super(GameUser, self).jwt_payload(*args, **kwargs)
        payload['authToken'] = str(self.auth_token)
        payload['sessionKey'] = str(uuid.uuid4())
        payload['region'] = self.region.code if self.region else 'us_canada'
        payload['debug'] = settings.ENV_NAME == 'dev'
        payload['assetsUrl'] = settings.UNITY_ASSETS_URL
        payload['androidAssets'] = settings.ANDROID_ASSETS_PATH
        payload['iosAssets'] = settings.IOS_ASSETS_PATH
        payload['webglAssets'] = settings.WEBGL_ASSETS_PATH
        return payload

    def update_state(self, tag, data):
        """
        Creates or updates the game state for a game user.
        :param tag: string
        :param data: object
        :return: True if we updated an existing state object, False if we created a new state object
        """
        created = False
        try:
            gsa = GameState.get(self.id, tag)
            gsa.update(actions=[GameState.data.set(data)])
            created = True
        except GameState.DoesNotExist:
            game_state_item = GameState(game_user_id=self.id, tag=tag, data=data)
            game_state_item.save()

        # Process incoming state objects to yield additional data
        if tag == 'books-progress':
            self.game_state_books_progress(data)

        # @TODO We possibly need to update UserActivityLevelProgress
        return created

    def get_state(self, tag):
        """
        Retrive the game state for a game user.
        :param tag: string
        :return: GameState object. Throws GameState.DoesNotExist if GameState record is not found.
        """
        return GameState.get(self.id, tag)

    def game_state_books_progress(self, books_progress):
        for book_id, book_progress in books_progress['content']['progress'].items():
            book_id = int(book_id)
            comprehension_state = int(book_progress['comprehension_state'])
            times_read = int(book_progress['times_read'])
            try:
                book_progress_record = self.book_progress.get(book_id=book_id)
                book_progress_record.comprehension_state = comprehension_state
                book_progress_record.times_read = times_read
                book_progress_record.save()
            except UserBookProgress.DoesNotExist:
                self.book_progress.create(book_id=book_id, comprehension_state=comprehension_state, times_read=times_read)

    es_skill_performance_skills = [
        "auditory", "alphabet", "correspondence", "consonants", "vowels", "syllables", "blending",
        "concept", "sight", "text", "recallPictureText", "sequencingPictures", "sequencingText"
    ]

    @staticmethod
    def es_skill_performance_label(performance):
        """
        :param performance: Percentage performance float, 0.0-1.0
        :return: label string corresponding to the performance grade
        """
        if performance >= 0.7:
            return 'proficient'
        elif performance >= 0.6:
            return 'practicing'
        return 'learning'

    def es_score_skill_performance_summary_query(self):
        query = {
            'size': 0,
            'query': {
                'term': {
                    'dp_id': self.dp_id
                }
            },
            'aggs': {
                'skills': {
                    'terms': {
                        'field': 'skill_label'
                    },
                    'aggs': {
                        'skill_correct': {
                            'sum': {
                                'field': 'score'
                            }
                        }
                    }
                },
                'total_correct': {
                    'sum': {
                        'field': 'score'
                    }
                }
            }
        }
        return query

    def es_score_skill_performance_summary(self):
        """
        Queries Elastic Search's score index to get a summary of skill performance data
        :return: dict of the results
        """
        # Future consideration: decide how far back to look by using the YYYY-MM-DD naming pattern of the score index
        # to selectively query for a partial result
        index_name = '%s*' % es_index_name('score')
        results = es.search(index=index_name, doc_type='default', body=self.es_score_skill_performance_summary_query())
        return results


class GameUserUnitySession(models.Model):
    session_key = models.CharField(max_length=36)
    ip_address = models.GenericIPAddressField()
    game_user = models.ForeignKey(GameUser, on_delete=models.CASCADE, related_name='unity_sessions')
    dp_role = models.CharField(max_length=32)
    district_id = models.IntegerField(null=True, blank=True)
    school_id = models.IntegerField(null=True, blank=True)
    section_id = models.IntegerField(null=True, blank=True)
    grade_system_code = models.CharField(max_length=128, blank=True)
    scholastic_grade_code = models.CharField(max_length=128, blank=True)
    gameplay_location = models.ForeignKey('GameplayLocation', null=True)
    created = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['id']
        get_latest_by = 'id'

    def save(self, *args, **kwargs):
        """
        Upon saving, create or update the corresponding document in Elastic Search
        """
        saved = super(GameUserUnitySession, self).save(*args, **kwargs)
        self.es_upsert()
        return saved

    es_template_name = 'unity_session_v1'
    es_template = {
        "index_patterns": ["ookasdm_*_unity_session*"],
        "mappings": {
            "default": {
                "properties": {
                    "session_key": {
                        "type": "keyword"
                    },
                    "ip_address": {
                        "type": "ip"
                    },
                    "dp_role": {
                        "type": "keyword"
                    },
                    "grade_system_code": {
                        "type": "keyword"
                    },
                    "scholastic_grade_code": {
                        "type": "keyword"
                    },
                    "gameplay_location": {
                        "type": "keyword"
                    },
                    "created": {
                        "type": "date",
                        "format": "epoch_second"
                    },
                }
            }
        }
    }

    def es_body(self):
        return {
            'doc': {
                'session_key': self.session_key,
                'ip_address': self.ip_address,
                'game_user_id': self.game_user.id,
                'dp_id': self.game_user.dp_id,
                'dp_role': self.dp_role,
                'district_id': self.district_id,
                'school_id': self.school_id,
                'section_id': self.section_id,
                'grade_system_code': self.grade_system_code,
                'scholastic_grade_code': self.scholastic_grade_code,
                'gameplay_location': self.gameplay_location.location if self.gameplay_location else '',
                'created': int(self.created.timestamp()),
                'updated': int(datetime.datetime.now().timestamp())
            }
        }

    def es_upsert(self):
        """
        Updates or inserts the Skill Performance record into the score-YYYY.MM.DD index based on its creation datetime.
        """
        body = self.es_body()
        index_name = es_index_name('unity_session', d=self.created)
        try:
            es.update(index=index_name, doc_type="default", id=self.session_key, body=body, retry_on_conflict=1)
        except NotFoundError:
            es.create(index=index_name, doc_type='default', id=self.session_key, body=body['doc'])


class Activity(models.Model):
    name = models.CharField(max_length=30)
    scene_name = models.CharField(max_length=30, blank=True)
    is_score_based = models.BooleanField()
    active = models.BooleanField()
    max_level = models.IntegerField()
    report_display = models.CharField(max_length=30, blank=True)

    class Meta:
        ordering = ['id']


class ActivityLevel(models.Model):
    label = models.CharField(max_length=100, blank=True)
    activity = models.ForeignKey(Activity, models.PROTECT)
    level_number = models.IntegerField()
    order = models.IntegerField(default=1)
    next_activity_level = models.ForeignKey('ActivityLevel', models.PROTECT, null=True, blank=True)
    unlock_type = models.ForeignKey('UnlockType')
    active = models.BooleanField(default=True)
    unlock_value = models.FloatField(default=0.0)
    question_type = models.IntegerField()

    class Meta:
        ordering = ['level_number']

    def get_comprehension_label(self, activity_part):
        """
        Matches the Activity Level Id and the Activity Part to the comprehension label
        :return: string of the label, if this activity level applies to comprehension
        """
        if activity_part:
            if self.id in al_comprehension_mappings:
                if activity_part in al_comprehension_mappings[self.id]:
                    return al_comprehension_mappings[self.id][activity_part]
        return ''

    def get_phonological_label(self, activity_part):
        """
        Matches the Activity Level Id and the Activity Part to the phonological label
        :return: string of the label, if this activity level applies to phonological
        """
        if activity_part:
            if self.id in al_phonological_mappings:
                if activity_part in al_phonological_mappings[self.id]:
                    return al_phonological_mappings[self.id][activity_part]
        return ''

    @property
    def get_level_number(self):
        """
        Ignore the level number on the AL record itself
        :return: int, level number
        """
        if str(self.id) in al_progress_mapping:
            return al_progress_mapping[str(self.id)]["level"]
        return None


class ActivityLevelReportMappings(models.Model):
    activity = models.ForeignKey(Activity, models.PROTECT)
    activity_level_number = models.IntegerField()
    report_level_display = models.IntegerField()

    class Meta:
        ordering = ['activity_level_number']


class ActivityLevelText(models.Model):
    activity_level = models.ForeignKey(ActivityLevel, models.PROTECT)
    text = models.ForeignKey('Text', models.PROTECT)
    readable_text = models.CharField(max_length=20)
    order = models.IntegerField(default=0)
    weight = models.IntegerField(default=1)  # always 1
    section = models.IntegerField(default=0)

    class Meta:
        ordering = ['order']


class AppliedIntervention(models.Model):
    game_user = models.ForeignKey('GameUser')
    pre_book = models.ForeignKey('Book', related_name='pre_book')
    post_book = models.ForeignKey('Book', related_name='post_book')
    intervention_type = models.CharField(max_length=32, blank=True, null=True)
    created = models.DateTimeField()

    class Meta:
        ordering = ['id']

    @staticmethod
    def create_from_intervention_event(data):
        timestamp = datetime.datetime.strptime(data['timestamp'], "%Y-%m-%d %H:%M:%S %z")
        if "intervention_type" not in data:
            data['intervention_type'] = None

        AppliedIntervention.objects.create(game_user_id=data['game_user_id'], pre_book_id=data['pre_book'],
                                           post_book_id=data['post_book'], intervention_type=data['intervention_type'],
                                           created=timestamp)


class Book(models.Model):
    name = models.CharField(max_length=50)
    active = models.BooleanField(default=True)
    sound_path = models.CharField(max_length=80)
    book_level = models.IntegerField()
    next_book = models.ForeignKey('Book', null=True, blank=True)  # Hint: it's just PK + 1 -rp
    readable_name = models.CharField(max_length=50)
    regions = models.ManyToManyField("Region")

    class Meta:
        ordering = ['id']

    def __str__(self):
        return "Book #%d - %s" % (self.id, self.readable_name)


class BookPage(models.Model):
    book = models.ForeignKey('Book', models.PROTECT)
    page_number = models.IntegerField()
    active = models.BooleanField()

    class Meta:
        ordering = ['page_number']


class BookPageText(models.Model):
    page = models.ForeignKey(BookPage, models.PROTECT)
    text_content = models.CharField(max_length=512)
    x_location = models.IntegerField(null=True, blank=True)
    y_location = models.IntegerField(null=True, blank=True)
    drop_in_comment = models.IntegerField()
    sound_path = models.CharField(max_length=128)
    order = models.IntegerField()
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ['order']


class BookPageTextTiming(models.Model):
    book_page_text = models.ForeignKey(BookPageText)
    timing = models.FloatField()


class CheereaderMessage(models.Model):
    message_name = models.CharField(max_length=40, blank=True)
    message_audio_name = models.CharField(max_length=40, blank=True)

    class Meta:
        verbose_name = 'CHEEReader Message'
        verbose_name_plural = 'CHEEReader Messages'


class CheereaderSentMessage(models.Model):
    game_user = models.ForeignKey(GameUser, models.CASCADE)
    from_field = models.CharField(max_length=64)
    message = models.ForeignKey(CheereaderMessage)

    class Meta:
        verbose_name = 'CHEEReader message sent'
        verbose_name_plural = 'CHEEReader messages sent'


class ElfLoriAnswer(models.Model):
    book = models.ForeignKey('Book')
    text = models.CharField(max_length=512)
    sound_path = models.CharField(max_length=8)
    order = models.IntegerField()
    image_path = models.CharField(max_length=24, null=True, blank=True)
    scramble_order = models.IntegerField()

    class Meta:
        ordering = ['order']


class ElfLoriAnswerTextTiming(models.Model):
    answer = models.ForeignKey(ElfLoriAnswer)
    timing = models.FloatField()

    class Meta:
        ordering = ['id']


class GuidedPlayFlow(models.Model):
    activity = models.ForeignKey(Activity, related_name='guided_play_flow_steps')
    level_number = models.IntegerField()


class InventoryItem(models.Model):
    name = models.CharField(max_length=40)
    price = models.IntegerField()
    description = models.CharField(max_length=60)
    category = models.IntegerField(default=0)
    unlocked = models.BooleanField()
    tier = models.IntegerField()
    clothes_id = models.IntegerField()
    prereq_item = models.ForeignKey('InventoryItem', null=True, blank=True)


class PopAndDropQuestion(models.Model):
    book = models.ForeignKey(Book, models.PROTECT)
    question_text = models.CharField(max_length=255)
    audio_clip = models.CharField(max_length=255)
    review_on_page_number = models.IntegerField()

    class Meta:
        ordering = ['id']


class PopAndDropAnswer(models.Model):
    question = models.ForeignKey(PopAndDropQuestion)
    label = models.CharField(max_length=255)
    texture = models.CharField(max_length=30, blank=True)
    audio_clip = models.CharField(max_length=255)
    correct = models.BooleanField()

    class Meta:
        ordering = ['id']


class PopAndDropQuestionTextTiming(models.Model):
    question = models.ForeignKey(PopAndDropQuestion)
    timing = models.FloatField()

    class Meta:
        ordering = ['id']


class GameplayLocation(models.Model):
    ip_address = models.GenericIPAddressField(unique=True)
    LOCATION_CHOICES = (('school', 'At School'), ('home', 'At Home'))
    location = models.CharField(choices=LOCATION_CHOICES, blank=True, max_length=24)
    notes = models.TextField(blank=True)
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)

    def save(self, force_insert=False, force_update=False, using=None, update_fields=None):
        if self.location != '':
            query_dict = {
                "query": {
                    "term": {
                        "ip_address": self.ip_address
                    }
                },
                "script": {
                    "inline": "ctx._source.gameplay_location = params.gameplay_location",
                    "lang": "painless",
                    "params": {"gameplay_location": self.location}
                },
            }
            results = es.update_by_query(index='%s*' % es_index_name('score'), doc_type="default", body=query_dict)
            logger.debug("Updated %d Elastic Search Score values to %s" % (results['updated'], self.location))

        return super(GameplayLocation, self).save(force_insert, force_update, using, update_fields)


class Score(models.Model):
    game_user = models.ForeignKey(GameUser, on_delete=models.CASCADE, related_name='scores')
    activity = models.ForeignKey(Activity, on_delete=models.SET_NULL, null=True, blank=True)
    activity_level = models.ForeignKey(ActivityLevel, on_delete=models.SET_NULL, null=True, blank=True)
    activity_part = models.CharField(max_length=8, null=True, blank=True)
    score = models.BooleanField()
    timing = models.FloatField(default=0.0)
    submitted_text = models.ForeignKey('Text', on_delete=models.SET_NULL, null=True, blank=True,
                                       related_name='submitted_scores')
    correct_text = models.ForeignKey('Text', on_delete=models.SET_NULL, null=True, blank=True,
                                     related_name='correct_scores')
    platform = models.CharField(choices=settings.PLATFORM_CHOICES, blank=True, max_length=64)
    session_key = models.CharField(max_length=36)
    ip_address = models.GenericIPAddressField()
    gameplay_location = models.ForeignKey(GameplayLocation, null=True)
    created = models.DateTimeField(null=True, blank=True)

    class Meta:
        get_latest_by = 'created'

    def save(self, *args, **kwargs):
        """
        Upon saving, create or update the corresponding document in Elastic Search
        """
        saved = super(Score, self).save(*args, **kwargs)
        self.es_score_upsert()
        return saved

    @staticmethod
    def create_from_telemetry_event(data):
        """
        Convenience methods for creating score records from telemetry events
        :param data:
        :return:
        """
        score = data['isCorrect'] == 1
        timestamp = datetime.datetime.strptime(data['timestamp'], "%Y-%m-%d %H:%M:%S %z")
        return Score.objects.create(
            game_user_id=data['game_user_id'], activity_id=data['activityId'], activity_level_id=data['activityLevelId'],
            score=score, timing=float(data['timing']), submitted_text_id=data['submittedTextId'],
            correct_text_id=data['correctTextId'], activity_part=data['activityPart'], platform=data.get('platform', ''),
            session_key=data['session_key'], ip_address=data['ip_address'], created=timestamp)

    def as_dict(self):
        return {
            "id": self.pk,
            "gameUserId": self.game_user.id,
            "activityId": self.activity.id,
            "activityLevelId": self.activity_level.id,
            "isCorrect": int(self.score),
            "timing": self.timing,
            "submittedTextId": self.submitted_text.id,
            "correctTextId": self.correct_text.id,
            "platform": self.platform,
            "created": self.created.timestamp()
        }

    es_score_template_name = 'score_v1'
    es_score_template = {
        "index_patterns": ["ookasdm_*_score*"],
        "mappings": {
            "default": {
                "properties": {
                    "session_key": {
                        "type": "keyword"
                    },
                    "skill_label": {
                        "type": "keyword"
                    },
                    "skill_type": {
                        "type": "keyword"
                    },
                    "activity_part": {
                        "type": "keyword"
                    },
                    "timing": {
                        "type": "float"
                    },
                    "ip_address": {
                        "type": "ip"
                    },
                    "gameplay_location": {
                        "type": "keyword"
                    },
                    "created": {
                        "type": "date",
                        "format": "epoch_second"
                    },
                    "updated": {
                        "type": "date",
                        "format": "epoch_second"
                    }
                }
            }
        }
    }

    def es_score_body(self):
        """
        Creates the body for the Elastic Search score-YYYY.MM.DD index
        :return: body dict
        """
        comprehension_label = self.activity_level.get_comprehension_label(self.activity_part)
        phonological_label = self.activity_level.get_phonological_label(self.activity_part)

        if comprehension_label != '':
            skill_label = comprehension_label
            skill_type = 'comprehension'
        elif phonological_label != '':
            skill_label = phonological_label
            skill_type = 'phonological'
        else:
            skill_label = ''
            skill_type = ''

        return {
            'doc': {
                'session_key': self.session_key,
                'game_user_id': self.game_user_id,
                'dp_id': self.game_user.dp_id,
                'activity_id': self.activity_id,
                'activity_level_id': self.activity_level_id,
                'activity_level_level_number': self.activity_level.get_level_number,
                'activity_part': self.activity_part,
                'skill_label': skill_label,
                'skill_type': skill_type,
                'score': self.score,
                'timing': self.timing,
                'platform': self.platform,
                'gameplay_location': self.gameplay_location.location if self.gameplay_location else '',
                'ip_address': self.ip_address,
                'created': int(self.created.timestamp()),
                'updated': int(datetime.datetime.now().timestamp())
            }
        }

    def es_score_upsert(self):
        """
        Updates or inserts the Score record into the score-YYYY.MM.DD index based on its creation datetime.
        """
        body = self.es_score_body()
        index_name = es_index_name('score', d=self.created)
        try:
            es.update(index=index_name, doc_type="default", id=self.id, body=body, retry_on_conflict=1)
        except NotFoundError:
            es.create(index=index_name, doc_type='default', id=self.id, body=body['doc'])


class SeashellAnswer(models.Model):
    book = models.ForeignKey(Book)
    text = models.CharField(max_length=512, blank=True)

    class Meta:
        ordering = ['id']


class SeashellAnswerTextTiming(models.Model):
    answer = models.ForeignKey(SeashellAnswer)
    timing = models.FloatField()

    class Meta:
        ordering = ['id']


class TextType(models.Model):
    name = models.CharField(max_length=20)
    active = models.BooleanField()


class Text(models.Model):
    text_type = models.ForeignKey(TextType)
    text = models.CharField(max_length=10, unique=True)
    sound_file_path = models.CharField(max_length=20)
    active = models.BooleanField()
    sound1 = models.CharField(max_length=11)
    sound2 = models.CharField(max_length=11)
    sound3 = models.CharField(max_length=11)

    class Meta:
        ordering = ['id']


class TextWeight(models.Model):
    name = models.CharField(max_length=30, blank=True)
    count = models.IntegerField()
    active = models.BooleanField()


class UnlockType(models.Model):
    type = models.CharField(max_length=50)
    threshold = models.IntegerField(null=True)
    description = models.CharField(max_length=256, blank=True)


class UserActivityLevelProgress(models.Model):
    """
    Keeps track of the ActivityLevel that a given game user has reached. Not used for gameplay but for reporting
    """
    game_user = models.ForeignKey(GameUser)
    activity_level = models.ForeignKey(ActivityLevel)
    created = models.DateTimeField(auto_now_add=True)


class UserBookProgress(models.Model):
    """
    Keeps track of the Book that a given game user has reached. Not used for gameplay but for reporting
    """
    game_user = models.ForeignKey(GameUser, related_name='book_progress')
    book = models.ForeignKey(Book)
    times_read = models.IntegerField(default=1)
    # ComprehensionState is used to identify where a player was in the book flow
    # 1: finished the first reading but not the first set of activites
    # 2: finished the first and the activities
    # 0: finished the entire book
    COMPREHENSION_CHOICES = (
        (1, 'Finished the first reading but not the first set of activites'),
        (2, 'Finished the first reading and the activities'),
        (0, 'Finished the entire book')
    )
    comprehension_state = models.IntegerField(choices=COMPREHENSION_CHOICES, default=0)
    created = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        """
        Upon saving, create or update the corresponding document in Elastic Search
        """
        saved = super(UserBookProgress, self).save(*args, **kwargs)
        self.es_upsert()
        return saved

    es_template_name = 'book_progress_v1'
    es_template = {
        "index_patterns": ["ookasdm_*_book_progress*"],
        "mappings": {
            "default": {
                "properties": {
                    "created": {
                        "type": "date",
                        "format": "epoch_second"
                    },
                    "updated": {
                        "type": "date",
                        "format": "epoch_second"
                    }
                }
            }
        }
    }

    def es_body(self):
        """
        Creates the body for the Elastic Search level_progress index
        :return: body dict
        """
        return {
            'doc': {
                'dp_id': self.game_user.dp_id,
                'book_id': self.book_id,
                'times_read': self.times_read,
                'comprehension_state': self.comprehension_state,
                'created': int(self.created.timestamp()),
                'updated': int(datetime.datetime.now().timestamp())
            }
        }

    def es_upsert(self):
        """
        Updates or inserts the Level Progress record into the level_progress index.
        """
        body = self.es_body()
        index_name = es_index_name('book_progress')
        try:
            es.update(index=index_name, doc_type="default", id=self.id, body=body, retry_on_conflict=1)
        except NotFoundError:
            es.create(index=index_name, doc_type='default', id=self.id, body=body['doc'])


class WordSwapQuestion(models.Model):
    book = models.ForeignKey(Book)
    question_sentence = models.CharField(max_length=256)
    question_clip = models.CharField(max_length=16)
    correct_answer = models.IntegerField()

    class Meta:
        ordering = ['id']


class WordSwapAnswer(models.Model):
    question = models.ForeignKey(WordSwapQuestion)
    answer_text = models.CharField(max_length=256)
    answer_clip = models.CharField(max_length=256)
    order = models.IntegerField()

    class Meta:
        ordering = ['order']


class WordSwapAnswerSentence(models.Model):
    answer = models.ForeignKey(WordSwapAnswer)
    question = models.ForeignKey(WordSwapQuestion)
    book = models.ForeignKey(Book)
    answer_sentence = models.CharField(max_length=256)
    answer_clip = models.CharField(max_length=64)

    class Meta:
        ordering = ['id']


class WordSwapAnswerSentenceTextTiming(models.Model):
    answer = models.ForeignKey(WordSwapAnswer)
    timing = models.FloatField()

    class Meta:
        ordering = ['id']


class WordSwapQuestionTextTiming(models.Model):
    question = models.ForeignKey(WordSwapQuestion)
    timing = models.FloatField()

    class Meta:
        ordering = ['id']


class ZobotGuidedPlay(models.Model):
    step = models.IntegerField()
    activity_level = models.ForeignKey(ActivityLevel, models.PROTECT)
    guided_play_level = models.ForeignKey(GuidedPlayFlow, models.PROTECT)
    activity = models.ForeignKey(Activity)
    sticker_to_receive = models.IntegerField(null=True, blank=True)
    level_label = models.CharField(max_length=255)

    class Meta:
        ordering = ['step']


class GameUserGuidedPlayProgress(models.Model):
    game_user = models.ForeignKey(GameUser, models.CASCADE, related_name='guided_play_progress')
    guided_play_step = models.ForeignKey(ZobotGuidedPlay)
    created = models.DateTimeField(auto_now_add=True)
