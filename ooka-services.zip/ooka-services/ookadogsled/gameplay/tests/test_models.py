import datetime
import json
import time
from django.test import TestCase
from gameplay.models import Activity, ActivityLevel, Book, GameUser, GameplayLocation, Score, Text, TextType, UnlockType,\
    UserBookProgress
from ookadogsled.elasticsearch_client import es, es_index_name

BASE_TELEMETRY = {
    "game_user_id": 12, "dp_id": 3, "scholastic_grade_code": "1",
    "timestamp": "2018-03-19 12:12:12 +0100", "platform": "Test", "timing": "100.1", "submittedTextId": 123,
    "correctTextId": 123, "session_key": "something", "ip_address": "127.0.0.1"
}

TELEMETRY = [
    # auditory: 2/3 = practicing
    {**BASE_TELEMETRY, **{"activityId": 1, "activityLevelId": 20, "isCorrect": 0, "activityPart": "A"}},
    {**BASE_TELEMETRY, **{"activityId": 1, "activityLevelId": 20, "isCorrect": 1, "activityPart": "A"}},
    {**BASE_TELEMETRY, **{"activityId": 1, "activityLevelId": 20, "isCorrect": 1, "activityPart": "A"}},
    # correspondence 2/4 = learning
    {**BASE_TELEMETRY, **{"activityId": 1, "activityLevelId": 20, "isCorrect": 0, "activityPart": "B"}},
    {**BASE_TELEMETRY, **{"activityId": 1, "activityLevelId": 20, "isCorrect": 0, "activityPart": "B"}},
    {**BASE_TELEMETRY, **{"activityId": 1, "activityLevelId": 20, "isCorrect": 1, "activityPart": "B"}},
    {**BASE_TELEMETRY, **{"activityId": 1, "activityLevelId": 20, "isCorrect": 1, "activityPart": "B"}},
    # consonants 4/5 = proficient
    {**BASE_TELEMETRY, **{"activityId": 1, "activityLevelId": 103, "isCorrect": 1, "activityPart": "C"}},
    {**BASE_TELEMETRY, **{"activityId": 1, "activityLevelId": 103, "isCorrect": 1, "activityPart": "C"}},
    {**BASE_TELEMETRY, **{"activityId": 1, "activityLevelId": 103, "isCorrect": 0, "activityPart": "C"}},
    {**BASE_TELEMETRY, **{"activityId": 1, "activityLevelId": 103, "isCorrect": 1, "activityPart": "C"}},
    {**BASE_TELEMETRY, **{"activityId": 1, "activityLevelId": 103, "isCorrect": 1, "activityPart": "C"}},
]

ES_SCORES_BASE = {
    'session_key': 'some-uuid', 'game_user_id': 15, 'dp_id': 12, 'activity_id': 1, 'activity_level_id': 106,
    'activity_part': 'A', 'skill_label': 'auditory', 'skill_type': 'phonological', 'timing': 100.1,
    'platform': 'IPhonePlayer', 'gameplay_location': '', 'score': True
}

ES_SCORES = [
    {**ES_SCORES_BASE, **{'id': 1, 'ip_address': '127.0.0.1', 'created': 1521457932}},
    {**ES_SCORES_BASE, **{'id': 2, 'ip_address': '127.0.0.1', 'created': 1521457937}},
    {**ES_SCORES_BASE, **{'id': 3, 'ip_address': '127.0.0.1', 'created': 1521457952}},
    {**ES_SCORES_BASE, **{'id': 4, 'ip_address': '127.0.0.2', 'created': 1521457982}},
    {**ES_SCORES_BASE, **{'id': 5, 'ip_address': '127.0.0.2', 'created': 1521457992}},
]


class GameUserTestCase(TestCase):

    def setUp(self):
        self.game_user = GameUser.objects.create(dp_id=1, dp_role='student')

    def test_str(self):
        gu = GameUser.objects.create(dp_id=12, dp_role="student")
        self.assertEqual(str(gu), 'GameUser #%d - DP Student 12' % gu.id)

    def test_get_auth_token_from_jwt(self):
        """
        Test that the GameUsers authToken is always in the JWT
        """
        gu = GameUser.objects.create(dp_id=12, dp_role="student")
        payload = gu.jwt_payload()
        self.assertIn('authToken', payload)

    def test_jwt_payload_json_encode(self):
        """
        Test that we can convert a JWT payload to a JSON string
        """
        gu = GameUser.objects.create(dp_id=12, dp_role="student")
        payload = gu.jwt_payload()
        json.dumps(payload)

    def test_jwt_debug(self):
        gu = GameUser.objects.create(dp_id=12, dp_role="student")
        payload = gu.jwt_payload()
        self.assertFalse(payload['debug'])

        with self.settings(ENV_NAME='dev'):
            payload = gu.jwt_payload()
            self.assertTrue(payload['debug'])

    def test_unity_assets_url(self):
        gu = GameUser.objects.create(dp_id=12, dp_role="student")
        payload = gu.jwt_payload()
        self.assertEqual(payload['assetsUrl'], 'https://s3.amazonaws.com/ooka-sdm-unity-assets/')
        self.assertEqual(payload['androidAssets'], 'android/v1/')
        self.assertEqual(payload['iosAssets'], 'ios/v1/')
        self.assertEqual(payload['webglAssets'], 'webgl/v1/')

    def test_auth_token_method(self):
        self.assertIsNotNone(self.game_user.auth_token)
        old_token = self.game_user.auth_token
        self.game_user.regenerate_auth_token()
        self.assertNotEqual(old_token, self.game_user.auth_token)


class GameUserScoreElasticSearchTestCase(TestCase):

    def setUp(self):
        es.indices.put_template(Score.es_score_template_name, Score.es_score_template)

        self.game_user = GameUser.objects.create(id=12, dp_id=3, dp_role="student")

        tt = TextType.objects.create(name="noun", active=True)
        ut = UnlockType.objects.create(type="Quantity Entries", threshold=100,
                                       description="User needs to attain a certain number of scores 'Threshold' to advance.")
        self.text = Text.objects.create(id=123, text_type=tt, text="A", sound_file_path="/dev/null/",
                                        active=True, sound1="blah", sound2="bluh", sound3="bleh")

        self.a = Activity.objects.create(id=1, name="Cave of Sounds", scene_name="CaveOfSounds", is_score_based=True,
                                         active=True, max_level=49, report_display="Cave of Sounds")

        self.al = ActivityLevel.objects.create(id=20, activity=self.a, level_number=9, unlock_type=ut, question_type=1)
        self.al = ActivityLevel.objects.create(id=103, activity=self.a, level_number=9, unlock_type=ut, question_type=1)
        self.al = ActivityLevel.objects.create(id=106, label="Cave Discover the Sounds 8-1: TH/o_e", activity=self.a,
                                               level_number=10, order=1, unlock_type=ut, active=True, unlock_value=0.,
                                               question_type=1)

        for t in TELEMETRY:
            Score.create_from_telemetry_event(t)

        # Wait one second for the Elastic Search index to catch up
        time.sleep(1)

    def tearDown(self):
        es.indices.delete(index='%s*' % es_index_name("score"))

    def test_ok(self):
        results = self.game_user.es_score_skill_performance_summary()
        self.assertTrue(len(results['aggregations']['skills']['buckets']) > 0)


class UserBookProgressStateChangeTestCase(TestCase):

    def setUp(self):
        es.indices.put_template(UserBookProgress.es_template_name, UserBookProgress.es_template)
        self.book = Book.objects.create(book_level=1)
        self.game_user = GameUser.objects.create(id=12, dp_id=12345)
        time.sleep(1)

    def tearDown(self):
        es.indices.delete(index=es_index_name("book_progress"), ignore=404)
        time.sleep(1)

    def test_user_book_progress(self):
        book_progress_query = {
            'query': {
                'bool': {
                    'must': [
                        {
                            'term': {
                                'dp_id': self.game_user.dp_id
                            }
                        }
                    ]
                }
            }
        }
        # Should be no index, nothing in it
        book_progress_index_name = es_index_name('book_progress')
        results = es.search(index=book_progress_index_name, doc_type='default', body=book_progress_query, ignore=404)
        self.assertEqual(results['status'], 404)

        # When a user book record is created, it should persist a doc in ES
        ubp = UserBookProgress.objects.create(book=self.book, game_user=self.game_user, times_read=1)
        time.sleep(2)
        results = es.search(index=book_progress_index_name, doc_type='default', body=book_progress_query)
        self.assertEqual(results['hits']['hits'][0]['_source']['times_read'], 1)

        # When a user book record is updated, it should update the doc in ES
        ubp.times_read = 99
        ubp.save()
        time.sleep(2)
        results = es.search(index=book_progress_index_name, doc_type='default', body=book_progress_query)
        self.assertEqual(results['hits']['hits'][0]['_source']['times_read'], 99)


class GameLocationTestCase(TestCase):

    def setUp(self):
        es.indices.put_template(Score.es_score_template_name, Score.es_score_template)
        for score in ES_SCORES:
            es.index(index=es_index_name("score", datetime.datetime.now()), doc_type="default", id=score['id'], body=score)

        # Wait for the search index to catch up else bad things happen
        time.sleep(2)

    def tearDown(self):
        es.indices.delete(index=es_index_name("score", datetime.datetime.now()))

    def test_jwt_service_gameplay_location(self):
        query_dict = {
            "query": {
                "term": {
                    "gameplay_location": 'loc_test'
                }
            }
        }

        # Verify we have no matching values to start.
        gpl = GameplayLocation.objects.create(ip_address="127.0.0.2")
        self.assertEqual(gpl.location, '')
        results = es.search(index='%s*' % es_index_name("score"), body=query_dict)
        self.assertEqual(results['hits']['total'], 0)

        # Update the location to reflect the known location value
        gpl.location = 'loc_test'
        gpl.save()

        # Test we have queried ES
        time.sleep(1)
        results = es.search(index='%s*' % es_index_name("score"), body=query_dict)
        self.assertEqual(results['hits']['total'], 2)


class ScoreTestCase(TestCase):

    def setUp(self):
        es.indices.put_template(Score.es_score_template_name, Score.es_score_template)
        tt = TextType.objects.create(name="noun", active=True)
        ut = UnlockType.objects.create(type="Quantity Entries", threshold=100,
                                       description="User needs to attain a certain number of scores 'Threshold' to advance.")
        self.game_user = GameUser.objects.create(id=12, dp_id=12, dp_role="student")
        self.text = Text.objects.create(text_type=tt, text="A", sound_file_path="/dev/null/",
                                        active=True, sound1="blah", sound2="bluh", sound3="bleh")

        self.a = Activity.objects.create(id=1, name="Cave of Sounds", scene_name="CaveOfSounds", is_score_based=True,
                                         active=True, max_level=49, report_display="Cave of Sounds")

        self.al = ActivityLevel.objects.create(id=106, label="Cave Discover the Sounds 8-1: TH/o_e", activity=self.a,
                                               level_number=10, order=1, unlock_type=ut, active=True, unlock_value=0.,
                                               question_type=1)

    def test_create_from_telemetry_event(self):
        data = {
            'session_key': 'some-uuid',
            'game_user_id': self.game_user.id,
            'activityId': self.a.pk,
            'activityLevelId': self.al.pk,
            'activityPart': 'A',
            'timing': '100.1',
            'isCorrect': 1,
            'submittedTextId': self.text.pk,
            'correctTextId': self.text.pk,
            'timestamp': '2018-03-19 12:12:12 +0100',
            'ip_address': '127.0.0.1',
            'platform': 'IPhonePlayer'
        }
        score = Score.create_from_telemetry_event(data)
        index_name = es_index_name('score', d=score.created)
        es.delete(index=index_name, doc_type="default", id=score.id)
        self.assertEqual(score.timing, 100.1)
        self.assertEqual(score.session_key, 'some-uuid')

    def test_es_score_upsert(self):
        outside = GameplayLocation.objects.create(ip_address='127.0.0.1', location='outside')
        data = {
            'session_key': 'some-uuid',
            'game_user_id': self.game_user.id,
            'activityId': self.a.pk,
            'activityLevelId': self.al.pk,
            'activityPart': 'A',
            'timing': '100.1',
            'isCorrect': 1,
            'submittedTextId': self.text.pk,
            'correctTextId': self.text.pk,
            'timestamp': '2018-03-19 12:12:12 +0100',
            'ip_address': '127.0.0.1',
            'platform': 'IPhonePlayer'
        }
        score = Score.create_from_telemetry_event(data)
        score.gameplay_location = outside
        score.save()
        index_name = es_index_name('score', d=score.created)
        result = es.get(index=index_name, doc_type="default", id=score.id)
        doc = result['_source']
        self.assertEqual(doc['session_key'], 'some-uuid')
        self.assertEqual(doc['game_user_id'], self.game_user.id)
        self.assertEqual(doc['dp_id'], 12)
        self.assertEqual(doc['activity_id'], 1)
        self.assertEqual(doc['activity_level_id'], 106)
        self.assertEqual(doc['activity_part'], 'A')
        self.assertEqual(doc['skill_label'], 'auditory')
        self.assertEqual(doc['skill_type'], 'phonological')
        self.assertEqual(doc['timing'], 100.1)
        self.assertEqual(doc['platform'], 'IPhonePlayer')
        self.assertEqual(doc['ip_address'], '127.0.0.1')
        self.assertEqual(doc['gameplay_location'], 'outside')
        self.assertEqual(doc['created'], 1521457932)
        self.assertTrue(doc['score'])

    def test_es_score_upsert_no_gameplay_location(self):
        data = {
            'session_key': 'some-uuid',
            'game_user_id': self.game_user.id,
            'activityId': self.a.pk,
            'activityLevelId': self.al.pk,
            'activityPart': 'A',
            'timing': '100.1',
            'isCorrect': 1,
            'submittedTextId': self.text.pk,
            'correctTextId': self.text.pk,
            'timestamp': '2018-03-19 12:12:12 +0100',
            'ip_address': '127.0.0.1',
            'platform': 'IPhonePlayer'
        }
        score = Score.create_from_telemetry_event(data)
        index_name = es_index_name('score', d=score.created)
        result = es.get(index=index_name, doc_type="default", id=score.id)
        self.assertEqual(result['_source']['gameplay_location'], '')
