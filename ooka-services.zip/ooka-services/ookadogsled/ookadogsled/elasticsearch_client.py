import json
import os
import sys
from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth


AWS_DEFAULT_REGION = 'us-east-1'
ELASTICSEARCH_SERVER = json.loads(os.environ["ELASTICSEARCH_SERVER"])


def es_index_name(name, d=None, d_format='%Y.%m.%d'):
    """
    Creates the index name to use for
    :param name: base index name
    :param d: datetime that should be appended to the base index name
    :param d_format: strftime format string to use, defaults to YYYY.MM.dd
    :return:
    """
    base = "ookasdm_%s_%s%s" % (os.environ["ENV"], name, '_test' if sys.argv[1:2] in [['test'], ['jenkins']] else '')
    if d:
        return '%s.%s' % (base, d.strftime(d_format))
    return base


if ELASTICSEARCH_SERVER['port'] == 443:
    # for ES setups that take place over https
    awsauth = AWS4Auth(os.environ["AWS_ACCESS_KEY_ID"], os.environ["AWS_SECRET_ACCESS_KEY"], AWS_DEFAULT_REGION, 'es')
    es = Elasticsearch(
        hosts=[ELASTICSEARCH_SERVER],
        http_auth=awsauth,
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection
    )
else:
    # for local ES setups
    es = Elasticsearch([{'host': ELASTICSEARCH_SERVER['host'], 'port': ELASTICSEARCH_SERVER['port']}])
