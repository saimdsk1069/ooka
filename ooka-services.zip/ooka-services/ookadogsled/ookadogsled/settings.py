import json
import os
import urllib
import sys

PROJECT_NAME = 'OokaSDM'
ENV_NAME = os.environ["ENV"]
TESTING = sys.argv[1:2] == ['test'] or sys.argv[1:2] == ['jenkins']
DEBUG = bool(os.environ["DEBUG"])

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

SECRET_KEY = os.environ["SECRET_KEY"]

# Add IP address range so that Openshift health checks pass the ALLOWED_HOSTS check.
ALLOWED_HOSTS = ["0.0.0.0","ookadogsled.%s.micro.scholastic.com" % ENV_NAME]  + ['172.16.%s.%s' %(i,j) for i in range(256) for j in range (256)]

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django_celery_results',
    'django_jenkins',
    'corsheaders',
    'sdm_authentication',
    'gameplay',
    'unity_bffs',
    'web_bffs',
    'reporting',
    'raven.contrib.django.raven_compat',
    'dashboard'
]

# Coverage report apps to consider
PROJECT_APPS = [
    'sdm_authentication',
    'digitalplatform',
    'gameplay',
    'ookadogsled',
    'reporting',
    'unity_bffs',
    'web_bffs',
    'dashboard'
]

MIDDLEWARE = [
    'django.middleware.common.CommonMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
]

ROOT_URLCONF = 'ookadogsled.urls'

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '%(levelname)s %(asctime)s %(module)s %(process)d %(thread)d %(message)s'
        },
    },
    'handlers': {
        'console': {
            'level': 'INFO',
            'class': 'logging.StreamHandler',
            'formatter': 'verbose'
        },
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': True
        },
    },
}

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'ookadogsled.wsgi.application'

DATABASES = json.loads(os.environ["DATABASES"])

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
        'LOCATION': os.environ["ELASTICACHE_HOST"],
    }
}

# Password validation
# https://docs.djangoproject.com/en/1.11/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
# https://docs.djangoproject.com/en/1.11/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_L10N = True

USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.11/howto/static-files/

STATIC_URL = '/assets/'

STATIC_ROOT = os.path.join(BASE_DIR, 'assets/')
AWS_DEFAULT_REGION = 'us-east-1'

PLATFORM_CHOICES = [
    ('webgl_sdm', 'WebGL SDM'),
    ('ios_sdm', 'iOS SDM'),
    ('android_sdm', 'Android SDM'),
]

JWT_PRIVATE_KEY = SECRET_KEY
JWT_LEEWAY = 0
JWT_AUDIENCE = None
JWT_ISSUER = None
JWT_ALGORITHM = 'HS256'

# Used by LTI login process to set cookies
COOKIE_DOMAIN = '.ookadogsled.%s.micro.scholastic.com' % ENV_NAME

# Cross-origin request policies
CORS_ORIGIN_ALLOW_ALL = False
CORS_ORIGIN_WHITELIST = [
    "ookadogsled.%s.micro.scholastic.com" % ENV_NAME,
    "ooka.ookadogsled.%s.micro.scholastic.com" % ENV_NAME,
    # For Angular running locally on :8080
    "ooka.ookadogsled.%s.micro.scholastic.com:8080" % ENV_NAME,
    "ooka-sdm-webgl-assets.s3.amazonaws.com"
]
CORS_ALLOW_HEADERS = (
    'accept',
    'accept-encoding',
    'authorization',
    'content-type',
    'origin',
    'user-agent',
    'x-csrftoken',
    'x-requested-with',
)
CORS_ALLOW_METHODS = (
    'GET',
    'OPTIONS',
    'POST',
)

ELASTICSEARCH_SERVER = json.loads(os.environ["ELASTICSEARCH_SERVER"])

# SDM API
DP_API_URL = os.environ["DP_API_URL"]
# To test the access token:
# $ curl -H "Authorization: Bearer <DP_API_ACCESS_TOKEN>" https://nonprod.api.scholastic.com/dev1/app/dp-api/1.1/apps/
DP_API_ACCESS_TOKEN = os.environ["DP_API_ACCESS_TOKEN"]

# Angular URL
SPA_URL = 'https://ooka.ookadogsled.%s.micro.scholastic.com/' % ENV_NAME
SERVICES_BASE_URL = 'https://ookadogsled.%s.micro.scholastic.com' % ENV_NAME
JWT_COOKIE_NAME = 'ooka_jwt'

AWS_ACCESS_KEY_ID = os.environ["AWS_ACCESS_KEY_ID"]
AWS_SECRET_ACCESS_KEY = os.environ["AWS_SECRET_ACCESS_KEY"]

# AWS credentials set above
CELERY_BROKER_TRANSPORT_OPTIONS = {"queue_name_prefix": "ooka_%s_celery-" % ENV_NAME}

CELERY_BROKER_URL = 'sqs://{0}:{1}@'.format(
    urllib.parse.quote(AWS_ACCESS_KEY_ID, safe=''),
    urllib.parse.quote(AWS_SECRET_ACCESS_KEY, safe='')
)
CELERY_RESULT_BACKEND = 'django-db'

RAVEN_CONFIG = {
    'dsn': os.environ["RAVEN_CONFIG_DSN"],
    'environment': ENV_NAME
}

JENKINS_TASKS = (
    'django_jenkins.tasks.run_pep8',
)

UNITY_ASSETS_URL = 'https://s3.amazonaws.com/ooka-sdm-unity-assets/'
ANDROID_ASSETS_PATH = 'android/v1/'
IOS_ASSETS_PATH = 'ios/v1/'
WEBGL_ASSETS_PATH = 'webgl/v1/'
