from django.test import TestCase
from ..elasticsearch_client import es_index_name


class ElasticSearchClientTestCase(TestCase):

    def test_name_tool(self):
        name = 'test_index'
        full_name = es_index_name(name)
        self.assertEqual(full_name, 'ookasdm_local_test_index_test')

