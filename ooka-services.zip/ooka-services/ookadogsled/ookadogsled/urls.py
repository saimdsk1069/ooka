from django.conf import settings
from django.conf.urls import url, include
from django.conf.urls.static import static
from django.views.generic import RedirectView
from .views import android_assetlinks, apple_app_site_association, celery_check, health_check


urlpatterns = [
    url(r'^auth/', include('sdm_authentication.urls')),
    url(r'^web/', include('web_bffs.urls', namespace='web_bffs')),
    url(r'^unity/', include('unity_bffs.urls', namespace='unity_bffs')),
    url(r'^celery', celery_check, name='celery-check'),
    url(r'^apple-app-site-association', apple_app_site_association, name='apple-app-site-association'),
    url(r'^.well-known/assetlinks.json', android_assetlinks, name='android-assetlinks'),
    url(r'^health', health_check, name='health-check'),
    url(r'^$', RedirectView.as_view(url=settings.SPA_URL), name='dash-redirect'),
    url(r'^dash/', include('dashboard.urls', namespace='dashboard')),
]

if settings.ENV_NAME == 'local':
    urlpatterns = urlpatterns + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
