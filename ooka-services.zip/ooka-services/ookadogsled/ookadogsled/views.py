import time
from django.db import connections
from django.db.utils import OperationalError
from django.http import HttpResponse, HttpResponseServerError, JsonResponse
from .celery import heartbeet


def android_assetlinks(request):
    data = [
        {
            "relation": ["delegate_permission/common.handle_all_urls"],
            "target": {
                "namespace": "android_app",
                "package_name": "com.scholastic.ookaisland",
                "sha256_cert_fingerprints": [
                    "5E:91:1D:EE:80:B5:8A:86:63:AC:2C:60:26:B1:2F:C6:99:19:B9:DB:07:17:CE:BA:81:71:E7:35:CA:5B:BF:EC"
                ]
            }
        }
    ]
    return JsonResponse(data, safe=False)


def apple_app_site_association(request):
    data = {
        "applinks": {
            "apps": [],
            "details": [
                {
                    "appID": "7S643WDT74.com.scholastic.OokaIsland",
                    "paths": ["/launcher*"]
                }
            ]
        }
    }
    return JsonResponse(data)


def celery_check(request):
    result = heartbeet.delay()
    ct = 1
    while not result.ready():
        time.sleep(1)
        ct += 1
        if ct > 30:
            return HttpResponse(status=503)
    return HttpResponse('Ok')


def health_check(request):
    db_conn = connections['default']
    try:
        c = db_conn.cursor()
    except OperationalError:
        return HttpResponse('No db connection')

    return HttpResponse('Ok!')
