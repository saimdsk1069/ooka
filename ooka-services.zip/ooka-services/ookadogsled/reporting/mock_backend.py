import random

# quick and dirty hardcoding to make some mock data available to front end

PLACE_NAMES = ["Southwheat", "Raylea", "Fieldbarrow", "Ironcrest", "Fieldpond", "Greenmont", "Springbarrow", "Anthony",
               "Leon", "Albany", "Monticello", "Dudley", "Bethel", "Chamois", "Gould", "Keller", "Flint Hill",
               "Brunswick", "Caribou", "Roseburg", "Memphis", "Buttonwillow", "Earl", "Winchester", "Sausalito",
               "Leonard", "Mount Vernon", "Lowry", "Moseley", "Wexford", "Blandford", "Quitman", "Markleysburg",
               "Cornelius", "Lemon Grove", "Estiffanulga", "Ogunquit", "Gene Autry", "Nice", "Lacey", "Waukenabo"]

SCHOOL_TYPES = ["Elementary School", "Middle School", "Academy for Young Mutants", "Kindergarten", "School"]

FIRST_NAMES = ["Sanai", "Mariyah", "Marina", "Ryan", "Cassie", "Kian", "Alexzander", "Carson", "Kathy", "Lorena",
               "Naima", "Harmony", "Peter", "Isabel", "Karli", "Alannah", "Deborah", "Aryan", "Jean", "Gloria", "Erika",
               "Teagan", "Braiden", "Camden", "Zane", "Chad", "Lilianna", "Anya", "Oscar", "Nancy", "Reynaldo",
               "Alexus", "Malia", "Andrew", "Mckenzie", "Dereon", "Vance", "Monserrat", "Pedro", "Jenna"]
LAST_NAMES = ["Benitez", "Randolph", "Clarke", "Ross", "Luna", "Ali", "Dougherty", "Lambert", "Mcguire", "Hampton",
              "Carroll", "Haas", "Stark", "Hunter", "Mora", "Bean", "Cook", "Wilkerson", "Watkins", "Petersen",
              "Cabrera", "Mccullough", "Davidson", "Hart", "Walsh", "Warner", "Dodson", "Pacheco", "York",
              "Chandler", "Newton", "Madden", "Downs", "Hardin", "Bautista", "Torres", "Bray", "Stevens", "Stout",
              "Norman"]


def phonological_table(type):
    pass


def phonological_scores(querytype, queryval):
    return generate_data(querytype, queryval, "phonologicalSkills", _gen_skills)


def phonological_distribution(querytype, queryval):
    return generate_data(querytype, queryval, "phonologicalDistribution", _gen_distribution)


def phonological_progress(querytype, queryval):
    return generate_data(querytype, queryval, "phonologicalProgress", _gen_progress)


def generate_data(querytype, queryval, data_field_name, data_generator):
    mock_data = {}
    mock_data['labels'] = _gen_labels()
    mock_data['cohorts'] = []

    # generate some random cohorts
    if querytype == 'staffId':
        mock_data['cohorts'].append({
            "name": "Ooka School District",
            "cohortId": queryval,
            "cohortGroup": "schoolsGroup",
            data_field_name: data_generator()
        })
        for i in range(random.randint(5, 20)):
            mock_data['cohorts'].append({
                "name": _gen_random_school_name(),
                "cohortId": _gen_random_int(),
                "cohortGroup": "school",
                data_field_name: data_generator()
            })
    elif querytype == "schoolId":
        mock_data['cohorts'].append({
            "name": _gen_random_school_name(),
            "cohortId": queryval,
            "cohortGroup": "school",
            data_field_name: data_generator()
        })
        for i in range(random.randint(5, 20)):
            mock_data['cohorts'].append({
                "name": "Section %d" % _gen_random_int(),
                "cohortId": _gen_random_int(),
                "cohortGroup": "section",
                data_field_name: data_generator()
            })
    elif querytype == "sectionId":
        mock_data['cohorts'].append({
            "name": "Section %d" % _gen_random_int(),
            "cohortId": queryval,
            "cohortGroup": "section",
            data_field_name: data_generator()
        })
        for i in range(random.randint(5, 20)):
            mock_data['cohorts'].append({
                "name": _gen_random_name(),
                "cohortId": _gen_random_int(),
                "cohortGroup": "student",
                data_field_name: data_generator()
            })
    elif querytype == "studentId":
        mock_data['cohorts'].append({
            "name": _gen_random_name(),
            "cohortId": queryval,
            "cohortGroup": "student",
            data_field_name: data_generator()
        })

    return mock_data


def _gen_labels():
    return {
        "auditory": "Auditory Recognition",
        "alphabet": "Alphabet Knowledge",
        "correspondence": "Letter-Sound Correspondence",
        "consonants": "Identify Consonants",
        "vowels": "Identify Vowels",
        "syllables": "Identify Syllables",
        "blending": "Blending"
    }


def _gen_random_int():
    return random.randint(1000, 40000)


def _gen_random_mark():
    return random.randint(50, 101)


def _gen_skills():
    return {
        "auditory": _gen_random_mark(),
        "alphabet": _gen_random_mark(),
        "correspondence": _gen_random_mark(),
        "consonants": _gen_random_mark(),
        "vowels": _gen_random_mark(),
        "syllables": _gen_random_mark(),
        "blending": _gen_random_mark()
    }


def _gen_distribution():
    data = {}
    skills = ["auditory", "alphabet", "correspondence", "consonants", "vowels", "syllables", "blending"]

    for s in skills:
        n1, n2, n3 = _gen_triplet_numbers()
        data[s] = {
            "learning": n1,
            "practicing": n2,
            "proficient": n3
        }

    return data


def _gen_progress():
    data = {}
    skills = ["auditory", "alphabet", "correspondence", "consonants", "vowels", "syllables", "blending"]

    for s in skills:
        data[s] = []
        for i in range(1, random.randint(2, 25)):
            data[s].append({
                "level": i,
                "value": _gen_random_mark(),
                "callout:": {"completedBy": _gen_random_mark(), "skillsPracticed": "ee, oo, aw"}
            })

    return data


def _gen_triplet_numbers():
    n1 = random.randint(0, 40)
    n2 = random.randint(n1, 80-n1)
    n3 = 100-n2-n1

    return n1, n2, n3


def _gen_random_school_name():
    return random.choice(PLACE_NAMES) + " " + random.choice(SCHOOL_TYPES)


def _gen_random_name():
    return random.choice(FIRST_NAMES) + " " + random.choice(LAST_NAMES)
