# this is a mapping from the phonological activitylevels (and parts) to the phonological skill that those
# levels relate to
al_phonological_mappings = {
    20: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    103: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    104: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    105: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    106: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    107: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    108: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    109: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    110: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    111: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    112: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    113: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    114: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    115: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    116: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    117: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    118: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    119: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    120: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    121: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    122: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    123: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    124: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    125: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    207: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    208: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    209: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    210: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    211: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    212: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    213: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    214: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    215: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    216: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    217: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    218: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    219: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    220: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    221: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    222: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    223: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    224: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    225: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    226: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    227: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    228: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    229: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    230: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    231: {"A": "auditory", "B": "correspondence", "C": "consonants"},
    96: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    97: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    98: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    99: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    100: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    101: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    102: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    232: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    233: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    234: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    235: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    236: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    237: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    238: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    5090: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    5091: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    5092: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    5093: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    5094: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    5095: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    5096: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    5097: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    5098: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    5099: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    5100: {"A": "alphabet", "B": "alphabet", "C": "alphabet"},
    88: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    89: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    90: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    91: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    92: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    93: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    94: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    95: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    239: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    240: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    241: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    242: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    243: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    244: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    245: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    246: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    247: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    248: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    249: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    250: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    251: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    252: {"A": "correspondence", "B": "vowels", "C": "vowels"},
    53: {"A": "syllables", "B": "syllables", "C": "syllables"},
    54: {"A": "syllables", "B": "syllables", "C": "syllables"},
    55: {"A": "syllables", "B": "syllables", "C": "syllables"},
    56: {"A": "syllables", "B": "syllables", "C": "syllables"},
    57: {"A": "syllables", "B": "syllables", "C": "syllables"},
    58: {"A": "syllables", "B": "syllables", "C": "syllables"},
    59: {"A": "syllables", "B": "syllables", "C": "syllables"},
    140: {"A": "syllables", "B": "syllables", "C": "syllables"},
    141: {"A": "syllables", "B": "syllables", "C": "syllables"},
    142: {"A": "syllables", "B": "syllables", "C": "syllables"},
    143: {"A": "syllables", "B": "syllables", "C": "syllables"},
    144: {"A": "syllables", "B": "syllables", "C": "syllables"},
    145: {"A": "syllables", "B": "syllables", "C": "syllables"},
    146: {"A": "syllables", "B": "syllables", "C": "syllables"},
    147: {"A": "syllables", "B": "syllables", "C": "syllables"},
    148: {"A": "syllables", "B": "syllables", "C": "syllables"},
    149: {"A": "syllables", "B": "syllables", "C": "syllables"},
    150: {"A": "syllables", "B": "syllables", "C": "syllables"},
    151: {"A": "syllables", "B": "syllables", "C": "syllables"},
    152: {"A": "syllables", "B": "syllables", "C": "syllables"},
    153: {"A": "syllables", "B": "syllables", "C": "syllables"},
    65: {"A": "blending", "B": "blending", "C": "blending"},
    66: {"A": "blending", "B": "blending", "C": "blending"},
    67: {"A": "blending", "B": "blending", "C": "blending"},
    68: {"A": "blending", "B": "blending", "C": "blending"},
    69: {"A": "blending", "B": "blending", "C": "blending"},
    181: {"A": "blending", "B": "blending", "C": "blending"},
    182: {"A": "blending", "B": "blending", "C": "blending"},
    183: {"A": "blending", "B": "blending", "C": "blending"},
    184: {"A": "blending", "B": "blending", "C": "blending"},
    185: {"A": "blending", "B": "blending", "C": "blending"},
    186: {"A": "blending", "B": "blending", "C": "blending"},
    187: {"A": "blending", "B": "blending", "C": "blending"},
    188: {"A": "blending", "B": "blending", "C": "blending"},
    189: {"A": "blending", "B": "blending", "C": "blending"},
    190: {"A": "blending", "B": "blending", "C": "blending"},
    191: {"A": "blending", "B": "blending", "C": "blending"},
    192: {"A": "blending", "B": "blending", "C": "blending"},
    193: {"A": "blending", "B": "blending", "C": "blending"},
    194: {"A": "blending", "B": "blending", "C": "blending"},
    60: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    61: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    62: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    63: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    64: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    255: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    257: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    70: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    71: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    72: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    73: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    74: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    75: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    76: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    126: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    127: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    128: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    129: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    130: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    131: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    132: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    133: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    134: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    135: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    136: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    137: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    138: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    139: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    254: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    256: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    5088: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    5089: {"A": "correspondence", "B": "correspondence", "C": "correspondence"},
    41: {"A": "blending", "B": "blending", "C": "blending"},
    42: {"A": "blending", "B": "blending", "C": "blending"},
    43: {"A": "blending", "B": "blending", "C": "blending"},
    44: {"A": "blending", "B": "blending", "C": "blending"},
    45: {"A": "blending", "B": "blending", "C": "blending"},
    46: {"A": "blending", "B": "blending", "C": "blending"},
    47: {"A": "blending", "B": "blending", "C": "blending"},
    49: {"A": "blending", "B": "blending", "C": "blending"},
    50: {"A": "blending", "B": "blending", "C": "blending"},
    52: {"A": "blending", "B": "blending", "C": "blending"},
    195: {"A": "blending", "B": "blending", "C": "blending"},
    196: {"A": "blending", "B": "blending", "C": "blending"},
    197: {"A": "blending", "B": "blending", "C": "blending"},
    198: {"A": "blending", "B": "blending", "C": "blending"},
    199: {"A": "blending", "B": "blending", "C": "blending"},
    200: {"A": "blending", "B": "blending", "C": "blending"},
    201: {"A": "blending", "B": "blending", "C": "blending"},
    202: {"A": "blending", "B": "blending", "C": "blending"},
    203: {"A": "blending", "B": "blending", "C": "blending"},
    204: {"A": "blending", "B": "blending", "C": "blending"},
    205: {"A": "blending", "B": "blending", "C": "blending"},
    206: {"A": "blending", "B": "blending", "C": "blending"},
    260: {"A": "blending", "B": "blending", "C": "blending"},
    261: {"A": "blending", "B": "blending", "C": "blending"}
}

# this is a mapping for all comprehension activitylevels to the comprehension skill that those activitylevels
# relate to
al_book_mappings = {
    5036: 36,
    5037: 37,
    5038: 38,
    5039: 39,
    5040: 40,
    5041: 41,
    5042: 42,
    5043: 43,
    5044: 44,
    5045: 45,
    5046: 46,
    5047: 47,
    5048: 48,
    5049: 49,
    5050: 50,
    5051: 51,
    5052: 52,
    5053: 53,
    5054: 54,
    5055: 55,
    5056: 56,
    5057: 57,
    5058: 58,
    5059: 59,
    5060: 60,
    5061: 61,
    5062: 62,
    5063: 63,
    5064: 64,
    5065: 65,
    5066: 66,
    5067: 67,
    5068: 68,
    5069: 69,
    5070: 70,
    5071: 71,
    5072: 72,
    5073: 73,
    5074: 74,
    5075: 75,
    5076: 76,
    5077: 77,
    5078: 78,
    5079: 79,
    5080: 80,
    5081: 81,
    5082: 82,
    5083: 83,
    5084: 84,
    5085: 85,
    2001: 1,
    2002: 2,
    2003: 3,
    2004: 4,
    2005: 5,
    2006: 6,
    2007: 7,
    2008: 8,
    2009: 9,
    2010: 10,
    2011: 11,
    2012: 12,
    2013: 13,
    2014: 14,
    2015: 15,
    2016: 16,
    2017: 17,
    2018: 18,
    2019: 19,
    2020: 20,
    2021: 21,
    2022: 22,
    2023: 23,
    2024: 24,
    2025: 25,
    2026: 26,
    2027: 27,
    2028: 28,
    2029: 29,
    2030: 30,
    2031: 31,
    2032: 32,
    2033: 33,
    2034: 34,
    2035: 35,
    2036: 36,
    2037: 37,
    2038: 38,
    2039: 39,
    2040: 40,
    2041: 41,
    2042: 42,
    2043: 43,
    2044: 44,
    2045: 45,
    2046: 46,
    2047: 47,
    2048: 48,
    2049: 49,
    2050: 50,
    2051: 51,
    2052: 52,
    2053: 53,
    2054: 54,
    2055: 55,
    2056: 56,
    2057: 57,
    2058: 58,
    2059: 59,
    2060: 60,
    2061: 61,
    2062: 62,
    2063: 63,
    2064: 64,
    2065: 65,
    2066: 66,
    2067: 67,
    2068: 68,
    2069: 69,
    2070: 70,
    2071: 71,
    2072: 72,
    2073: 73,
    2074: 74,
    2075: 75,
    2076: 76,
    2077: 77,
    2078: 78,
    2079: 79,
    2080: 80,
    2081: 81,
    2082: 82,
    2083: 83,
    2084: 84,
    2085: 85,
    3001: 1,
    3002: 2,
    3003: 3,
    3004: 4,
    3005: 5,
    3006: 6,
    3007: 7,
    3008: 8,
    3009: 9,
    3010: 10,
    3011: 11,
    3012: 12,
    3013: 13,
    3014: 14,
    3015: 15,
    3016: 16,
    3017: 17,
    3018: 18,
    3019: 19,
    3020: 20,
    3021: 21,
    3022: 22,
    3023: 23,
    3024: 24,
    3025: 25,
    3026: 26,
    3027: 27,
    3028: 28,
    3029: 29,
    3030: 30,
    3031: 31,
    3032: 32,
    3033: 33,
    3034: 34,
    3035: 35
}

al_comprehension_mappings = {
    5036: "sequencingPictures",
    5037: "sequencingPictures",
    5038: "sequencingPictures",
    5039: "sequencingPictures",
    5040: "sequencingPictures",
    5041: "sequencingPictures",
    5042: "sequencingPictures",
    5043: "sequencingPictures",
    5044: "sequencingPictures",
    5045: "sequencingPictures",
    5046: "sequencingText",
    5047: "sequencingText",
    5048: "sequencingText",
    5049: "sequencingText",
    5050: "sequencingText",
    5051: "sequencingText",
    5052: "sequencingText",
    5053: "sequencingText",
    5054: "sequencingText",
    5055: "sequencingText",
    5056: "sequencingText",
    5057: "sequencingText",
    5058: "sequencingText",
    5059: "sequencingText",
    5060: "sequencingText",
    5061: "sequencingText",
    5062: "sequencingText",
    5063: "sequencingText",
    5064: "sequencingText",
    5065: "sequencingText",
    5066: "sequencingText",
    5067: "sequencingText",
    5068: "sequencingText",
    5069: "sequencingText",
    5070: "sequencingText",
    5071: "sequencingText",
    5072: "sequencingText",
    5073: "sequencingText",
    5074: "sequencingText",
    5075: "sequencingText",
    5076: "sequencingText",
    5077: "sequencingText",
    5078: "sequencingText",
    5079: "sequencingText",
    5080: "sequencingText",
    5081: "sequencingText",
    5082: "sequencingText",
    5083: "sequencingText",
    5084: "sequencingText",
    5085: "sequencingText",
    2001: "recallPictureText",
    2002: "recallPictureText",
    2003: "recallPictureText",
    2004: "recallPictureText",
    2005: "recallPictureText",
    2006: "recallPictureText",
    2007: "recallPictureText",
    2008: "recallPictureText",
    2009: "recallPictureText",
    2010: "recallPictureText",
    2011: "recallPictureText",
    2012: "recallPictureText",
    2013: "recallPictureText",
    2014: "recallPictureText",
    2015: "recallPictureText",
    2016: "recallPictureText",
    2017: "recallPictureText",
    2018: "recallPictureText",
    2019: "recallPictureText",
    2020: "recallPictureText",
    2021: "recallPictureText",
    2022: "recallPictureText",
    2023: "recallPictureText",
    2024: "recallPictureText",
    2025: "recallPictureText",
    2026: "recallPictureText",
    2027: "recallPictureText",
    2028: "recallPictureText",
    2029: "recallPictureText",
    2030: "recallPictureText",
    2031: "recallPictureText",
    2032: "recallPictureText",
    2033: "recallPictureText",
    2034: "recallPictureText",
    2035: "recallPictureText",
    2036: "recallPictureText",
    2037: "recallPictureText",
    2038: "recallPictureText",
    2039: "recallPictureText",
    2040: "recallPictureText",
    2041: "recallPictureText",
    2042: "recallPictureText",
    2043: "recallPictureText",
    2044: "recallPictureText",
    2045: "recallPictureText",
    2046: "text",
    2047: "text",
    2048: "text",
    2049: "text",
    2050: "text",
    2051: "text",
    2052: "text",
    2053: "text",
    2054: "text",
    2055: "text",
    2056: "text",
    2057: "text",
    2058: "text",
    2059: "text",
    2060: "text",
    2061: "text",
    2062: "text",
    2063: "text",
    2064: "text",
    2065: "text",
    2066: "text",
    2067: "text",
    2068: "text",
    2069: "text",
    2070: "text",
    2071: "text",
    2072: "text",
    2073: "text",
    2074: "text",
    2075: "text",
    2076: "text",
    2077: "text",
    2078: "text",
    2079: "text",
    2080: "text",
    2081: "text",
    2082: "text",
    2083: "text",
    2084: "text",
    2085: "text",
    3001: "concept",
    3002: "concept",
    3003: "concept",
    3004: "concept",
    3005: "concept",
    3006: "concept",
    3007: "concept",
    3008: "concept",
    3009: "concept",
    3010: "concept",
    3011: "concept",
    3012: "concept",
    3013: "concept",
    3014: "concept",
    3015: "concept",
    3016: "concept",
    3017: "concept",
    3018: "concept",
    3019: "concept",
    3020: "concept",
    3021: "concept",
    3022: "concept",
    3023: "concept",
    3024: "concept",
    3025: "concept",
    3026: "sight",
    3027: "sight",
    3028: "sight",
    3029: "sight",
    3030: "sight",
    3031: "sight",
    3032: "sight",
    3033: "sight",
    3034: "sight",
    3035: "sight"
}

# this is a mapping from skills to all of the activity levels that contribute to those skills
skill_reverse_mapping = {
  "auditory": [
    20,
    103,
    104,
    105,
    106,
    107,
    108,
    109,
    110,
    111,
    112,
    113,
    114,
    115,
    116,
    117,
    118,
    119,
    120,
    121,
    122,
    123,
    124,
    125,
    207,
    208,
    209,
    210,
    211,
    212,
    213,
    214,
    215,
    216,
    217,
    218,
    219,
    220,
    221,
    222,
    223,
    224,
    225,
    226,
    227,
    228,
    229,
    230,
    231
  ],
  "correspondence": [
    20,
    103,
    104,
    105,
    106,
    107,
    108,
    109,
    110,
    111,
    112,
    113,
    114,
    115,
    116,
    117,
    118,
    119,
    120,
    121,
    122,
    123,
    124,
    125,
    207,
    208,
    209,
    210,
    211,
    212,
    213,
    214,
    215,
    216,
    217,
    218,
    219,
    220,
    221,
    222,
    223,
    224,
    225,
    226,
    227,
    228,
    229,
    230,
    231,
    88,
    89,
    90,
    91,
    92,
    93,
    94,
    95,
    239,
    240,
    241,
    242,
    243,
    244,
    245,
    246,
    247,
    248,
    249,
    250,
    251,
    252,
    60,
    61,
    62,
    63,
    64,
    255,
    257,
    70,
    71,
    72,
    73,
    74,
    75,
    76,
    126,
    127,
    128,
    129,
    130,
    131,
    132,
    133,
    134,
    135,
    136,
    137,
    138,
    139,
    254,
    256,
    5088,
    5089
  ],
  "consonants": [
    106,
    107,
    108,
    109,
    110,
    111,
    112,
    113,
    114,
    115,
    116,
    117,
    118,
    119,
    120,
    121,
    122,
    123,
    124,
    125,
    207,
    208,
    209,
    210,
    211,
    212,
    213,
    214,
    215,
    216,
    217,
    218,
    219,
    220,
    221,
    222,
    223,
    224,
    225,
    226,
    227,
    228,
    229,
    230,
    231
  ],
  "alphabet": [
    96,
    97,
    98,
    99,
    100,
    101,
    102,
    232,
    233,
    234,
    235,
    236,
    237,
    238,
    5090,
    5091,
    5092,
    5093,
    5094,
    5095,
    5096,
    5097,
    5098,
    5099,
    5100
  ],
  "vowels": [
    88,
    89,
    90,
    91,
    92,
    93,
    94,
    95,
    239,
    240,
    241,
    242,
    243,
    244,
    245,
    246,
    247,
    248,
    249,
    250,
    251,
    252
  ],
  "syllables": [
    53,
    54,
    55,
    56,
    57,
    58,
    59,
    140,
    141,
    142,
    143,
    144,
    145,
    146,
    147,
    148,
    149,
    150,
    151,
    152,
    153
  ],
  "blending": [
    41,
    42,
    43,
    44,
    45,
    46,
    47,
    49,
    50,
    52,
    195,
    196,
    197,
    198,
    199,
    200,
    201,
    202,
    203,
    204,
    205,
    206,
    260,
    261,
    65,
    66,
    67,
    68,
    69,
    181,
    182,
    183,
    184,
    185,
    186,
    187,
    188,
    189,
    190,
    191,
    192,
    193,
    194
  ],
  "sequencingPictures": [
    5036,
    5037,
    5038,
    5039,
    5040,
    5041,
    5042,
    5043,
    5044,
    5045
  ],
  "sequencingText": [
    5046,
    5047,
    5048,
    5049,
    5050,
    5051,
    5052,
    5053,
    5054,
    5055,
    5056,
    5057,
    5058,
    5059,
    5060,
    5061,
    5062,
    5063,
    5064,
    5065,
    5066,
    5067,
    5068,
    5069,
    5070,
    5071,
    5072,
    5073,
    5074,
    5075,
    5076,
    5077,
    5078,
    5079,
    5080,
    5081,
    5082,
    5083,
    5084,
    5085
  ],
  "recallPictureText": [
    2001,
    2002,
    2003,
    2004,
    2005,
    2006,
    2007,
    2008,
    2009,
    2010,
    2011,
    2012,
    2013,
    2014,
    2015,
    2016,
    2017,
    2018,
    2019,
    2020,
    2021,
    2022,
    2023,
    2024,
    2025,
    2026,
    2027,
    2028,
    2029,
    2030,
    2031,
    2032,
    2033,
    2034,
    2035
  ],
  "text": [
    2036,
    2037,
    2038,
    2039,
    2040,
    2041,
    2042,
    2043,
    2044,
    2045,
    2046,
    2047,
    2048,
    2049,
    2050,
    2051,
    2052,
    2053,
    2054,
    2055,
    2056,
    2057,
    2058,
    2059,
    2060,
    2061,
    2062,
    2063,
    2064,
    2065,
    2066,
    2067,
    2068,
    2069,
    2070,
    2071,
    2072,
    2073,
    2074,
    2075,
    2076,
    2077,
    2078,
    2079,
    2080,
    2081,
    2082,
    2083,
    2084,
    2085
  ],
  "concept": [
    3001,
    3002,
    3003,
    3004,
    3005,
    3006,
    3007,
    3008,
    3009,
    3010,
    3011,
    3012,
    3013,
    3014,
    3015,
    3016,
    3017,
    3018,
    3019,
    3020,
    3021,
    3022,
    3023,
    3024,
    3025
  ],
  "sight": [
    3026,
    3027,
    3028,
    3029,
    3030,
    3031,
    3032,
    3033,
    3034,
    3035
  ]
}

# this is a mapping of activity levels to the game level with which they correspond. It also maps to the phonological
# skill that is practiced during that activitylevel
al_progress_mapping = {
  "20": {
    "level": 1,
    "A": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "B": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "C": []
  },
  "41": {
    "level": 1,
    "A": [
      "Onset & Rime"
    ],
    "B": [
      "Onset & Rime"
    ],
    "C": [
      "Onset & Rime"
    ]
  },
  "42": {
    "level": 2,
    "A": [
      "Onset & Rime"
    ],
    "B": [
      "Onset & Rime"
    ],
    "C": [
      "Onset & Rime"
    ]
  },
  "43": {
    "level": 3,
    "A": [
      "Onset & Rime"
    ],
    "B": [
      "Onset & Rime"
    ],
    "C": [
      "Onset & Rime"
    ]
  },
  "44": {
    "level": 4,
    "A": [
      "Onset & Rime"
    ],
    "B": [
      "Onset & Rime"
    ],
    "C": [
      "Onset & Rime"
    ]
  },
  "45": {
    "level": 5,
    "A": [
      "Blend 2 Sound Words"
    ],
    "B": [
      "Blend 2 Sound Words"
    ],
    "C": [
      "Blend 2 Sound Words"
    ]
  },
  "46": {
    "level": 6,
    "A": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "B": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "C": [
      "Blend 3 Sound Words",
      "Blend CV"
    ]
  },
  "47": {
    "level": 7,
    "A": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "B": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "C": [
      "Blend 3 Sound Words",
      "Blend CV"
    ]
  },
  "49": {
    "level": 8,
    "A": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "B": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "C": [
      "Blend 3 Sound Words",
      "Blend CV"
    ]
  },
  "50": {
    "level": 9,
    "A": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "B": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "C": [
      "Blend 3 Sound Words",
      "Blend CV"
    ]
  },
  "52": {
    "level": 10,
    "A": [
      "Blend 3 Sound Words",
      "Blend CVC Words"
    ],
    "B": [
      "Blend 3 Sound Words",
      "Blend CVC Words"
    ],
    "C": [
      "Blend 3 Sound Words",
      "Blend CVC Words"
    ]
  },
  "53": {
    "level": 4,
    "A": [
      "3 sound words",
      "2 sound syllables (cv)"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv)"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv)"
    ]
  },
  "54": {
    "level": 5,
    "A": [
      "3 sound words",
      "2 sound syllables (cv)"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv)"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv)"
    ]
  },
  "55": {
    "level": 6,
    "A": [
      "3 sound words",
      "2 sound syllables (cv)"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv)"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv)"
    ]
  },
  "56": {
    "level": 7,
    "A": [
      "3 sound words",
      "2 sound syllables (vc)"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (vc)"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (vc)"
    ]
  },
  "57": {
    "level": 8,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ]
  },
  "58": {
    "level": 9,
    "A": [
      "3 sound words",
      "2 sound syllables (cv)",
      "m",
      "sh",
      "f",
      "p",
      "t",
      "ee",
      "_o_",
      "oy"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv)",
      "m",
      "sh",
      "f",
      "p",
      "t",
      "ee",
      "_o_",
      "oy"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv)",
      "m",
      "sh",
      "f",
      "p",
      "t",
      "ee",
      "_o_",
      "oy"
    ]
  },
  "59": {
    "level": 10,
    "A": [
      "3 sound words",
      "2 sound syllables (cv)",
      "m",
      "sh",
      "f",
      "p",
      "t",
      "c",
      "k",
      "ee",
      "_o_",
      "_a_"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv)",
      "m",
      "sh",
      "f",
      "p",
      "t",
      "c",
      "k",
      "ee",
      "_o_",
      "_a_"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv)",
      "m",
      "sh",
      "f",
      "p",
      "t",
      "c",
      "k",
      "ee",
      "_o_",
      "_a_"
    ]
  },
  "60": {
    "level": 1,
    "A": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "B": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "C": [
      "m",
      "s",
      "oo",
      "ee"
    ]
  },
  "61": {
    "level": 2,
    "A": [
      "sh",
      "aw",
      "f"
    ],
    "B": [
      "sh",
      "aw",
      "f"
    ],
    "C": [
      "sh",
      "aw",
      "f"
    ]
  },
  "62": {
    "level": 3,
    "A": [
      "oy",
      "p",
      "t"
    ],
    "B": [
      "oy",
      "p",
      "t"
    ],
    "C": [
      "oy",
      "p",
      "t"
    ]
  },
  "63": {
    "level": 4,
    "A": [
      "_o_",
      "k",
      "_a_"
    ],
    "B": [
      "_o_",
      "k",
      "_a_"
    ],
    "C": [
      "_o_",
      "k",
      "_a_"
    ]
  },
  "64": {
    "level": 5,
    "A": [
      "c",
      "ck",
      "a_e",
      "b"
    ],
    "B": [
      "c",
      "ck",
      "a_e",
      "b"
    ],
    "C": [
      "c",
      "ck",
      "a_e",
      "b"
    ]
  },
  "65": {
    "level": 6,
    "A": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "B": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "C": [
      "Blend 3 Sound Words",
      "Blend CV"
    ]
  },
  "66": {
    "level": 7,
    "A": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "B": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "C": [
      "Blend 3 Sound Words",
      "Blend CV"
    ]
  },
  "67": {
    "level": 8,
    "A": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "B": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "C": [
      "Blend 3 Sound Words",
      "Blend CV"
    ]
  },
  "68": {
    "level": 9,
    "A": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "B": [
      "Blend 3 Sound Words",
      "Blend CV"
    ],
    "C": [
      "Blend 3 Sound Words",
      "Blend CV"
    ]
  },
  "69": {
    "level": 10,
    "A": [
      "Blend 3 Sound Words",
      "Blend CVC Words"
    ],
    "B": [
      "Blend 3 Sound Words",
      "Blend CVC Words"
    ],
    "C": [
      "Blend 3 Sound Words",
      "Blend CVC Words"
    ]
  },
  "70": {
    "level": 4,
    "A": [
      "_o_",
      "k",
      "_a_"
    ],
    "B": [
      "_o_",
      "k",
      "_a_"
    ],
    "C": [
      "_o_",
      "k",
      "_a_"
    ]
  },
  "71": {
    "level": 5,
    "A": [
      "c",
      "ck",
      "a_e",
      "b"
    ],
    "B": [
      "c",
      "ck",
      "a_e",
      "b"
    ],
    "C": [
      "c",
      "ck",
      "a_e",
      "b"
    ]
  },
  "72": {
    "level": 6,
    "A": [
      "d"
    ],
    "B": [
      "d"
    ],
    "C": [
      "d"
    ]
  },
  "73": {
    "level": 7,
    "A": [
      "g",
      "th"
    ],
    "B": [
      "g",
      "th"
    ],
    "C": [
      "g",
      "th"
    ]
  },
  "74": {
    "level": 8,
    "A": [
      "o_e",
      "h",
      "n"
    ],
    "B": [
      "o_e",
      "h",
      "n"
    ],
    "C": [
      "o_e",
      "h",
      "n"
    ]
  },
  "75": {
    "level": 9,
    "A": [
      "ch",
      "i_e"
    ],
    "B": [
      "ch",
      "i_e"
    ],
    "C": [
      "ch",
      "i_e"
    ]
  },
  "76": {
    "level": 10,
    "A": [
      "ow",
      "r"
    ],
    "B": [
      "ow",
      "r"
    ],
    "C": [
      "ow",
      "r"
    ]
  },
  "88": {
    "level": 3,
    "A": [
      "oy",
      "p",
      "t"
    ],
    "B": [
      "oo",
      "ee",
      "aw"
    ],
    "C": [
      "oo",
      "ee",
      "aw"
    ]
  },
  "89": {
    "level": 4,
    "A": [
      "_o_",
      "k",
      "_a_"
    ],
    "B": [
      "oo",
      "ee",
      "aw",
      "oy"
    ],
    "C": [
      "oo",
      "ee",
      "aw",
      "oy"
    ]
  },
  "90": {
    "level": 5,
    "A": [
      "c",
      "ck",
      "a_e",
      "b"
    ],
    "B": [
      "oo",
      "ee",
      "_o_",
      "oy"
    ],
    "C": [
      "oo",
      "ee",
      "_o_",
      "oy"
    ]
  },
  "91": {
    "level": 6,
    "A": [
      "d"
    ],
    "B": [
      "oo",
      "ee",
      "_o_",
      "_a_"
    ],
    "C": [
      "oo",
      "ee",
      "_o_",
      "_a_"
    ]
  },
  "92": {
    "level": 7,
    "A": [
      "g",
      "th"
    ],
    "B": [
      "_a_",
      "a_e"
    ],
    "C": [
      "_a_",
      "a_e"
    ]
  },
  "93": {
    "level": 8,
    "A": [
      "o_e",
      "h",
      "n"
    ],
    "B": [
      "oo",
      "ee",
      "_o_",
      "oy"
    ],
    "C": [
      "oo",
      "ee",
      "_o_",
      "oy"
    ]
  },
  "94": {
    "level": 9,
    "A": [
      "ch",
      "i_e"
    ],
    "B": [
      "_o_",
      "_a_",
      "a_e"
    ],
    "C": [
      "_o_",
      "_a_",
      "a_e"
    ]
  },
  "95": {
    "level": 10,
    "A": [
      "ow",
      "r"
    ],
    "B": [
      "oo",
      "ee"
    ],
    "C": [
      "oo",
      "ee"
    ]
  },
  "96": {
    "level": 1,
    "A": [
      "a",
      "b",
      "c",
      "d"
    ],
    "B": [
      "a",
      "b",
      "c",
      "d"
    ],
    "C": [
      "a",
      "b",
      "c",
      "d"
    ]
  },
  "97": {
    "level": 2,
    "A": [
      "e",
      "f",
      "g"
    ],
    "B": [
      "e",
      "f",
      "g"
    ],
    "C": [
      "e",
      "f",
      "g"
    ]
  },
  "98": {
    "level": 3,
    "A": [
      "h",
      "i",
      "j",
      "k"
    ],
    "B": [
      "h",
      "i",
      "j",
      "k"
    ],
    "C": [
      "h",
      "i",
      "j",
      "k"
    ]
  },
  "99": {
    "level": 4,
    "A": [
      "l",
      "m",
      "n",
      "o",
      "p"
    ],
    "B": [
      "l",
      "m",
      "n",
      "o",
      "p"
    ],
    "C": [
      "l",
      "m",
      "n",
      "o",
      "p"
    ]
  },
  "100": {
    "level": 5,
    "A": [
      "q",
      "r",
      "s",
      "t"
    ],
    "B": [
      "q",
      "r",
      "s",
      "t"
    ],
    "C": [
      "q",
      "r",
      "s",
      "t"
    ]
  },
  "101": {
    "level": 6,
    "A": [
      "u",
      "v"
    ],
    "B": [
      "u",
      "v"
    ],
    "C": [
      "u",
      "v"
    ]
  },
  "102": {
    "level": 7,
    "A": [
      "w",
      "x",
      "y",
      "z"
    ],
    "B": [
      "w",
      "x",
      "y",
      "z"
    ],
    "C": [
      "w",
      "x",
      "y",
      "z"
    ]
  },
  "103": {
    "level": 1,
    "A": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "B": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "C": []
  },
  "104": {
    "level": 1,
    "A": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "B": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "C": []
  },
  "105": {
    "level": 1,
    "A": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "B": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "C": []
  },
  "106": {
    "level": 2,
    "A": [
      "sh",
      "aw",
      "f"
    ],
    "B": [
      "sh",
      "aw",
      "f"
    ],
    "C": [
      "m",
      "s",
      "sh",
      "f"
    ]
  },
  "107": {
    "level": 2,
    "A": [
      "sh",
      "aw",
      "f"
    ],
    "B": [
      "sh",
      "aw",
      "f"
    ],
    "C": [
      "m",
      "s",
      "sh",
      "f"
    ]
  },
  "108": {
    "level": 3,
    "A": [
      "oy",
      "p",
      "t"
    ],
    "B": [
      "oy",
      "p",
      "t"
    ],
    "C": [
      "m",
      "s",
      "sh",
      "f"
    ]
  },
  "109": {
    "level": 3,
    "A": [
      "oy",
      "p",
      "t"
    ],
    "B": [
      "oy",
      "p",
      "t"
    ],
    "C": [
      "m",
      "s",
      "sh",
      "f"
    ]
  },
  "110": {
    "level": 4,
    "A": [
      "_o_",
      "k",
      "_a_"
    ],
    "B": [
      "_o_",
      "k",
      "_a_"
    ],
    "C": [
      "p",
      "t",
      "k",
      "m",
      "s",
      "sh",
      "f"
    ]
  },
  "111": {
    "level": 4,
    "A": [
      "_o_",
      "k",
      "_a_"
    ],
    "B": [
      "_o_",
      "k",
      "_a_"
    ],
    "C": [
      "p",
      "t",
      "k",
      "m",
      "s",
      "sh",
      "f"
    ]
  },
  "112": {
    "level": 4,
    "A": [
      "_o_",
      "k",
      "_a_"
    ],
    "B": [
      "_o_",
      "k",
      "_a_"
    ],
    "C": [
      "p",
      "t",
      "k",
      "m",
      "s",
      "sh",
      "f"
    ]
  },
  "113": {
    "level": 5,
    "A": [
      "c",
      "a_e",
      "b"
    ],
    "B": [
      "c",
      "ck",
      "a_e",
      "b"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g",
      "m ",
      "s",
      "h"
    ]
  },
  "114": {
    "level": 5,
    "A": [
      "c",
      "a_e",
      "b"
    ],
    "B": [
      "c",
      "ck",
      "a_e",
      "b"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g",
      "m ",
      "s",
      "h"
    ]
  },
  "115": {
    "level": 5,
    "A": [
      "c",
      "a_e",
      "b"
    ],
    "B": [
      "c",
      "ck",
      "a_e",
      "b"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g",
      "m ",
      "s",
      "h"
    ]
  },
  "116": {
    "level": 6,
    "A": [
      "d"
    ],
    "B": [
      "d"
    ],
    "C": [
      "b",
      "d",
      "g"
    ]
  },
  "117": {
    "level": 7,
    "A": [
      "g",
      "th"
    ],
    "B": [
      "g",
      "th"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g"
    ]
  },
  "118": {
    "level": 7,
    "A": [
      "g",
      "th"
    ],
    "B": [
      "g",
      "th"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g"
    ]
  },
  "119": {
    "level": 7,
    "A": [
      "g",
      "th"
    ],
    "B": [
      "g",
      "th"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g"
    ]
  },
  "120": {
    "level": 8,
    "A": [
      "o_e",
      "h",
      "n"
    ],
    "B": [
      "o_e",
      "h",
      "n"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g",
      "m",
      "s",
      "sh",
      "f"
    ]
  },
  "121": {
    "level": 8,
    "A": [
      "o_e",
      "h",
      "n"
    ],
    "B": [
      "o_e",
      "h",
      "n"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g",
      "m",
      "s",
      "sh",
      "f"
    ]
  },
  "122": {
    "level": 9,
    "A": [
      "ch",
      "i_e"
    ],
    "B": [
      "ch",
      "i_e"
    ],
    "C": [
      "m",
      "s",
      "sh",
      "f",
      "p",
      "t",
      "k",
      "b",
      "d",
      "g"
    ]
  },
  "123": {
    "level": 9,
    "A": [
      "ch",
      "i_e"
    ],
    "B": [
      "ch",
      "i_e"
    ],
    "C": [
      "m",
      "s",
      "sh",
      "f",
      "p",
      "t",
      "k",
      "b",
      "d",
      "g"
    ]
  },
  "124": {
    "level": 9,
    "A": [
      "ch",
      "i_e"
    ],
    "B": [
      "ch",
      "i_e"
    ],
    "C": [
      "m",
      "s",
      "sh",
      "f",
      "p",
      "t",
      "k",
      "b",
      "d",
      "g"
    ]
  },
  "125": {
    "level": 10,
    "A": [
      "ow",
      "r"
    ],
    "B": [
      "ow",
      "r"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g",
      "m",
      "s",
      "sh",
      "f"
    ]
  },
  "126": {
    "level": 11,
    "A": [
      "_u_",
      "j"
    ],
    "B": [
      "_u_",
      "j"
    ],
    "C": [
      "_u_",
      "j"
    ]
  },
  "127": {
    "level": 12,
    "A": [
      "v",
      "z"
    ],
    "B": [
      "v",
      "z"
    ],
    "C": [
      "v",
      "z"
    ]
  },
  "128": {
    "level": 13,
    "A": [
      "ar",
      "l"
    ],
    "B": [
      "ar",
      "l"
    ],
    "C": [
      "ar",
      "l"
    ]
  },
  "129": {
    "level": 14,
    "A": [
      "_i_",
      "th(the)"
    ],
    "B": [
      "_i_",
      "th(the)"
    ],
    "C": [
      "_i_",
      "th(the)"
    ]
  },
  "130": {
    "level": 15,
    "A": [
      "_e_",
      "oo(book)"
    ],
    "B": [
      "_e_",
      "oo(book)"
    ],
    "C": [
      "_e_",
      "oo(book)"
    ]
  },
  "131": {
    "level": 16,
    "A": [
      "er",
      "ur",
      "ir",
      "w"
    ],
    "B": [
      "er",
      "ur",
      "ir",
      "w"
    ],
    "C": [
      "er",
      "ur",
      "ir",
      "w"
    ]
  },
  "132": {
    "level": 17,
    "A": [
      "wh",
      "y"
    ],
    "B": [
      "wh",
      "y"
    ],
    "C": [
      "wh",
      "y"
    ]
  },
  "133": {
    "level": 18,
    "A": [
      "or",
      "x"
    ],
    "B": [
      "or",
      "x"
    ],
    "C": [
      "or",
      "x"
    ]
  },
  "134": {
    "level": 19,
    "A": [
      "qu",
      "ng"
    ],
    "B": [
      "qu",
      "ng"
    ],
    "C": [
      "qu",
      "ng"
    ]
  },
  "135": {
    "level": 20,
    "A": [
      "u_e"
    ],
    "B": [
      "u_e"
    ],
    "C": [
      "u_e"
    ]
  },
  "136": {
    "level": 21,
    "A": [
      "Review"
    ],
    "B": [
      "Review"
    ],
    "C": [
      "Review"
    ]
  },
  "137": {
    "level": 22,
    "A": [
      "Review"
    ],
    "B": [
      "Review"
    ],
    "C": [
      "Review"
    ]
  },
  "138": {
    "level": 23,
    "A": [
      "Review"
    ],
    "B": [
      "Review"
    ],
    "C": [
      "Review"
    ]
  },
  "139": {
    "level": 24,
    "A": [
      "Review"
    ],
    "B": [
      "Review"
    ],
    "C": [
      "Review"
    ]
  },
  "140": {
    "level": 11,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "oo",
      "ee",
      "oy"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "oo",
      "ee",
      "oy"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "oo",
      "ee",
      "oy"
    ]
  },
  "141": {
    "level": 12,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "ee",
      "_a_",
      "a_e"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "ee",
      "_a_",
      "a_e"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "ee",
      "_a_",
      "a_e"
    ]
  },
  "142": {
    "level": 13,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_o_",
      "_a_",
      "a_e"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_o_",
      "_a_",
      "a_e"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_o_",
      "_a_",
      "a_e"
    ]
  },
  "143": {
    "level": 14,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_o_",
      "_o_e"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_o_",
      "_o_e"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_o_",
      "_o_e"
    ]
  },
  "144": {
    "level": 15,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_o_",
      "_a_",
      "a_e",
      "o_e"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_o_",
      "_a_",
      "a_e",
      "o_e"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_o_",
      "_a_",
      "a_e",
      "o_e"
    ]
  },
  "145": {
    "level": 16,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "a_e",
      "o_e",
      "i_e"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "a_e",
      "o_e",
      "i_e"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "a_e",
      "o_e",
      "i_e"
    ]
  },
  "146": {
    "level": 17,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "a_e",
      "o_e",
      "i_e",
      "ow"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "a_e",
      "o_e",
      "i_e",
      "ow"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "a_e",
      "o_e",
      "i_e",
      "ow"
    ]
  },
  "147": {
    "level": 18,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_o_",
      "_a_",
      "_u_"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_o_",
      "_a_",
      "_u_"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_o_",
      "_a_",
      "_u_"
    ]
  },
  "148": {
    "level": 19,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_i_",
      "_e_"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_i_",
      "_e_"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_i_",
      "_e_"
    ]
  },
  "149": {
    "level": 20,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_i_",
      "_e_",
      "_a_"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_i_",
      "_e_",
      "_a_"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)",
      "_i_",
      "_e_",
      "_a_"
    ]
  },
  "150": {
    "level": 21,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ]
  },
  "151": {
    "level": 22,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ]
  },
  "152": {
    "level": 23,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ]
  },
  "153": {
    "level": 24,
    "A": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ],
    "B": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ],
    "C": [
      "3 sound words",
      "2 sound syllables (cv + vc)"
    ]
  },
  "181": {
    "level": 11,
    "A": [
      "Blend 3 Sound Words",
      "Blend CVC Words"
    ],
    "B": [
      "Blend 3 Sound Words",
      "Blend CVC Words"
    ],
    "C": [
      "Blend 3 Sound Words",
      "Blend CVC Words"
    ]
  },
  "182": {
    "level": 12,
    "A": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "B": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "C": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ]
  },
  "183": {
    "level": 13,
    "A": [
      "Rhyme syllable heard to visual",
      "Blend CVC words"
    ],
    "B": [
      "Rhyme syllable heard to visual",
      "Blend CVC words"
    ],
    "C": [
      "Rhyme syllable heard to visual",
      "Blend CVC words"
    ]
  },
  "184": {
    "level": 14,
    "A": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "B": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "C": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ]
  },
  "185": {
    "level": 15,
    "A": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "B": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "C": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ]
  },
  "186": {
    "level": 16,
    "A": [
      "Rhyme syllable heard to visual",
      "Blend CVC words"
    ],
    "B": [
      "Rhyme syllable heard to visual",
      "Blend CVC words"
    ],
    "C": [
      "Rhyme syllable heard to visual",
      "Blend CVC words"
    ]
  },
  "187": {
    "level": 17,
    "A": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "B": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "C": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ]
  },
  "188": {
    "level": 18,
    "A": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ],
    "B": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ],
    "C": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ]
  },
  "189": {
    "level": 19,
    "A": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ],
    "B": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ],
    "C": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ]
  },
  "190": {
    "level": 20,
    "A": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ],
    "B": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ],
    "C": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ]
  },
  "191": {
    "level": 21,
    "A": [
      "Rhyme word heard to visual",
      "Blend CVC words"
    ],
    "B": [
      "Rhyme word heard to visual",
      "Blend CVC words"
    ],
    "C": [
      "Rhyme word heard to visual",
      "Blend CVC words"
    ]
  },
  "192": {
    "level": 22,
    "A": [
      "Rhyme word heard to visual",
      "Blend CVC words"
    ],
    "B": [
      "Rhyme word heard to visual",
      "Blend CVC words"
    ],
    "C": [
      "Rhyme word heard to visual",
      "Blend CVC words"
    ]
  },
  "193": {
    "level": 23,
    "A": [
      "Review blending three sounds",
      "Blend CVC words"
    ],
    "B": [
      "Review blending three sounds",
      "Blend CVC words"
    ],
    "C": [
      "Review blending three sounds",
      "Blend CVC words"
    ]
  },
  "194": {
    "level": 24,
    "A": [
      "Review blending three sounds",
      "Blend CVC words"
    ],
    "B": [
      "Review blending three sounds",
      "Blend CVC words"
    ],
    "C": [
      "Review blending three sounds",
      "Blend CVC words"
    ]
  },
  "195": {
    "level": 11,
    "A": [
      "Blend 3 Sound Words",
      "Blend CVC Words"
    ],
    "B": [
      "Blend 3 Sound Words",
      "Blend CVC Words"
    ],
    "C": [
      "Blend 3 Sound Words",
      "Blend CVC Words"
    ]
  },
  "196": {
    "level": 12,
    "A": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "B": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "C": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ]
  },
  "197": {
    "level": 13,
    "A": [
      "Rhyme syllable heard to visual",
      "Blend CVC words"
    ],
    "B": [
      "Rhyme syllable heard to visual",
      "Blend CVC words"
    ],
    "C": [
      "Rhyme syllable heard to visual",
      "Blend CVC words"
    ]
  },
  "198": {
    "level": 14,
    "A": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "B": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "C": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ]
  },
  "199": {
    "level": 15,
    "A": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "B": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "C": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ]
  },
  "200": {
    "level": 16,
    "A": [
      "Rhyme syllable heard to visual",
      "Blend CVC words"
    ],
    "B": [
      "Rhyme syllable heard to visual",
      "Blend CVC words"
    ],
    "C": [
      "Rhyme syllable heard to visual",
      "Blend CVC words"
    ]
  },
  "201": {
    "level": 17,
    "A": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "B": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ],
    "C": [
      "Rhyme syllable heard to visual",
      "Blend CV/VC syllables"
    ]
  },
  "202": {
    "level": 18,
    "A": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ],
    "B": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ],
    "C": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ]
  },
  "203": {
    "level": 19,
    "A": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ],
    "B": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ],
    "C": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ]
  },
  "204": {
    "level": 20,
    "A": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ],
    "B": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ],
    "C": [
      "Rhyme word heard to visual",
      "Blend CV/VC words"
    ]
  },
  "205": {
    "level": 21,
    "A": [
      "Rhyme word heard to visual",
      "Blend CVC words"
    ],
    "B": [
      "Rhyme word heard to visual",
      "Blend CVC words"
    ],
    "C": [
      "Rhyme word heard to visual",
      "Blend CVC words"
    ]
  },
  "206": {
    "level": 22,
    "A": [
      "Rhyme word heard to visual",
      "Blend CVC words"
    ],
    "B": [
      "Rhyme word heard to visual",
      "Blend CVC words"
    ],
    "C": [
      "Rhyme word heard to visual",
      "Blend CVC words"
    ]
  },
  "207": {
    "level": 10,
    "A": [
      "ow",
      "r"
    ],
    "B": [
      "ow",
      "r"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g",
      "m",
      "s",
      "sh",
      "f"
    ]
  },
  "208": {
    "level": 11,
    "A": [
      "_u_",
      "j"
    ],
    "B": [
      "_u_",
      "j"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g",
      "m",
      "s",
      "sh",
      "f"
    ]
  },
  "209": {
    "level": 11,
    "A": [
      "_u_",
      "j"
    ],
    "B": [
      "_u_",
      "j"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g",
      "m",
      "s",
      "sh",
      "f"
    ]
  },
  "210": {
    "level": 12,
    "A": [
      "v",
      "z"
    ],
    "B": [
      "v",
      "z"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g"
    ]
  },
  "211": {
    "level": 12,
    "A": [
      "v",
      "z"
    ],
    "B": [
      "v",
      "z"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g"
    ]
  },
  "212": {
    "level": 13,
    "A": [
      "ar",
      "l"
    ],
    "B": [
      "ar",
      "l"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g",
      "h",
      "n",
      "ch",
      "v"
    ]
  },
  "213": {
    "level": 13,
    "A": [
      "ar",
      "l"
    ],
    "B": [
      "ar",
      "l"
    ],
    "C": [
      "p",
      "t",
      "k",
      "b",
      "d",
      "g",
      "h",
      "n",
      "ch",
      "v"
    ]
  },
  "214": {
    "level": 14,
    "A": [
      "_i_",
      "th"
    ],
    "B": [
      "_i_",
      "th(the)"
    ],
    "C": [
      "h",
      "n",
      "ch",
      "v",
      "th",
      "r",
      "j",
      "l",
      "z"
    ]
  },
  "215": {
    "level": 14,
    "A": [
      "_i_",
      "th"
    ],
    "B": [
      "_i_",
      "th(the)"
    ],
    "C": [
      "h",
      "n",
      "ch",
      "v",
      "th",
      "r",
      "j",
      "l",
      "z"
    ]
  },
  "216": {
    "level": 15,
    "A": [
      "_e_",
      "oo"
    ],
    "B": [
      "_e_",
      "oo(book)"
    ],
    "C": [
      "th",
      "r",
      "j",
      "l",
      "z",
      "m",
      "s",
      "sh",
      "f",
      "p",
      "t",
      "k"
    ]
  },
  "217": {
    "level": 15,
    "A": [
      "_e_",
      "oo"
    ],
    "B": [
      "_e_",
      "oo(book)"
    ],
    "C": [
      "th",
      "r",
      "j",
      "l",
      "z",
      "m",
      "s",
      "sh",
      "f",
      "p",
      "t",
      "k"
    ]
  },
  "218": {
    "level": 16,
    "A": [
      "er",
      "w"
    ],
    "B": [
      "er",
      "ur",
      "ir",
      "w"
    ],
    "C": [
      "m",
      "s",
      "sh",
      "f",
      "p",
      "t",
      "k"
    ]
  },
  "219": {
    "level": 16,
    "A": [
      "er",
      "w"
    ],
    "B": [
      "er",
      "ur",
      "ir",
      "w"
    ],
    "C": [
      "m",
      "s",
      "sh",
      "f",
      "p",
      "t",
      "k"
    ]
  },
  "220": {
    "level": 17,
    "A": [
      "wh",
      "y"
    ],
    "B": [
      "wh",
      "y"
    ],
    "C": [
      "m",
      "s",
      "sh",
      "f",
      "p",
      "t",
      "k",
      "b",
      "d",
      "g",
      "w"
    ]
  },
  "221": {
    "level": 17,
    "A": [
      "wh",
      "y"
    ],
    "B": [
      "wh",
      "y"
    ],
    "C": [
      "m",
      "s",
      "sh",
      "f",
      "p",
      "t",
      "k",
      "b",
      "d",
      "g",
      "w"
    ]
  },
  "222": {
    "level": 18,
    "A": [
      "or",
      "x"
    ],
    "B": [
      "or",
      "x"
    ],
    "C": [
      "b",
      "d",
      "g",
      "w",
      "th(the)",
      "y",
      "qu"
    ]
  },
  "223": {
    "level": 18,
    "A": [
      "or",
      "x"
    ],
    "B": [
      "or",
      "x"
    ],
    "C": [
      "b",
      "d",
      "g",
      "w",
      "th(the)",
      "y",
      "qu"
    ]
  },
  "224": {
    "level": 19,
    "A": [
      "qu",
      "ng"
    ],
    "B": [
      "qu",
      "ng"
    ],
    "C": [
      "th(the)",
      "y",
      "qu",
      "ng",
      "x"
    ]
  },
  "225": {
    "level": 19,
    "A": [
      "qu",
      "ng"
    ],
    "B": [
      "qu",
      "ng"
    ],
    "C": [
      "th(the)",
      "y",
      "qu",
      "ng",
      "x"
    ]
  },
  "226": {
    "level": 20,
    "A": [
      "u_e"
    ],
    "B": [
      "u_e"
    ],
    "C": [
      "ng",
      "x"
    ]
  },
  "227": {
    "level": 20,
    "A": [
      "u_e"
    ],
    "B": [
      "u_e"
    ],
    "C": [
      "ng",
      "x"
    ]
  },
  "228": {
    "level": 21,
    "A": [
      "Review"
    ],
    "B": [
      "Review"
    ],
    "C": [
      "m",
      "s",
      "sh",
      "f",
      "p",
      "t",
      "k",
      "v",
      "w",
      "ch"
    ]
  },
  "229": {
    "level": 22,
    "A": [
      "Review"
    ],
    "B": [
      "Review"
    ],
    "C": [
      "m",
      "s",
      "sh",
      "f",
      "p",
      "t",
      "k",
      "v",
      "ch"
    ]
  },
  "230": {
    "level": 23,
    "A": [
      "Review"
    ],
    "B": [
      "Review"
    ],
    "C": [
      "h",
      "n",
      "r",
      "j",
      "th",
      "z",
      "l",
      "y",
      "qu"
    ]
  },
  "231": {
    "level": 24,
    "A": [
      "Review"
    ],
    "B": [
      "Review"
    ],
    "C": [
      "n",
      "th",
      "l",
      "x",
      "ng",
      "b",
      "d",
      "g"
    ]
  },
  "232": {
    "level": 8,
    "A": [
      "A",
      "B",
      "C",
      "D"
    ],
    "B": [
      "A",
      "B",
      "C",
      "D"
    ],
    "C": [
      "A",
      "B",
      "C",
      "D"
    ]
  },
  "233": {
    "level": 9,
    "A": [
      "E",
      "F",
      "G"
    ],
    "B": [
      "E",
      "F",
      "G"
    ],
    "C": [
      "E",
      "F",
      "G"
    ]
  },
  "234": {
    "level": 10,
    "A": [
      "H",
      "I",
      "J",
      "K"
    ],
    "B": [
      "H",
      "I",
      "J",
      "K"
    ],
    "C": [
      "H",
      "I",
      "J",
      "K"
    ]
  },
  "235": {
    "level": 11,
    "A": [
      "L",
      "M",
      "N",
      "O",
      "P"
    ],
    "B": [
      "L",
      "M",
      "N",
      "O",
      "P"
    ],
    "C": [
      "L",
      "M",
      "N",
      "O",
      "P"
    ]
  },
  "236": {
    "level": 12,
    "A": [
      "Q",
      "R",
      "S",
      "T"
    ],
    "B": [
      "Q",
      "R",
      "S",
      "T"
    ],
    "C": [
      "Q",
      "R",
      "S",
      "T"
    ]
  },
  "237": {
    "level": 13,
    "A": [
      "U",
      "V"
    ],
    "B": [
      "U",
      "V"
    ],
    "C": [
      "U",
      "V"
    ]
  },
  "238": {
    "level": 14,
    "A": [
      "W",
      "X",
      "Y",
      "Z"
    ],
    "B": [
      "W",
      "X",
      "Y",
      "Z"
    ],
    "C": [
      "W",
      "X",
      "Y",
      "Z"
    ]
  },
  "239": {
    "level": 11,
    "A": [
      "_u_",
      "j"
    ],
    "B": [
      "_o_",
      "_a_",
      "a_e",
      "o_e"
    ],
    "C": [
      "_o_",
      "_a_",
      "a_e",
      "o_e"
    ]
  },
  "240": {
    "level": 12,
    "A": [
      "v",
      "z"
    ],
    "B": [
      "_o_",
      "_a_",
      "a_e",
      "o_e",
      "ow"
    ],
    "C": [
      "_o_",
      "_a_",
      "a_e",
      "o_e",
      "ow"
    ]
  },
  "241": {
    "level": 13,
    "A": [
      "ar",
      "l"
    ],
    "B": [
      "_o_",
      "_a_",
      "a_e"
    ],
    "C": [
      "_o_",
      "_a_",
      "a_e"
    ]
  },
  "242": {
    "level": 14,
    "A": [
      "_i_",
      "th(the)"
    ],
    "B": [
      "_o_",
      "_a_",
      "_u_"
    ],
    "C": [
      "_o_",
      "_a_",
      "_u_"
    ]
  },
  "243": {
    "level": 15,
    "A": [
      "_e_",
      "oo(book)"
    ],
    "B": [
      "_o_",
      "_a_",
      "_u_"
    ],
    "C": [
      "_o_",
      "_a_",
      "_u_"
    ]
  },
  "244": {
    "level": 16,
    "A": [
      "er",
      "ur",
      "ir",
      "w"
    ],
    "B": [
      "i_e",
      "_i_"
    ],
    "C": [
      "i_e",
      "_i_"
    ]
  },
  "245": {
    "level": 17,
    "A": [
      "wh",
      "y"
    ],
    "B": [
      "i_e",
      "_e_"
    ],
    "C": [
      "i_e",
      "_e_"
    ]
  },
  "246": {
    "level": 18,
    "A": [
      "or",
      "x"
    ],
    "B": [
      "er",
      "ar",
      "or"
    ],
    "C": [
      "er",
      "ar",
      "or"
    ]
  },
  "247": {
    "level": 19,
    "A": [
      "qu",
      "ng"
    ],
    "B": [
      "i_e",
      "_i_",
      "ee",
      "e"
    ],
    "C": [
      "i_e",
      "_i_",
      "ee",
      "e"
    ]
  },
  "248": {
    "level": 20,
    "A": [
      "u_e"
    ],
    "B": [
      "_i_",
      "_e_",
      "_o_",
      "_a_",
      "_u_"
    ],
    "C": [
      "_i_",
      "_e_",
      "_o_",
      "_a_",
      "_u_"
    ]
  },
  "249": {
    "level": 21,
    "A": [
      "Review"
    ],
    "B": [
      "_i_",
      "_e_",
      "_o_",
      "_a_",
      "_u_"
    ],
    "C": [
      "_i_",
      "_e_",
      "_o_",
      "_a_",
      "_u_"
    ]
  },
  "250": {
    "level": 22,
    "A": [
      "Review"
    ],
    "B": [
      "_i_",
      "_e_",
      "_o_",
      "_a_",
      "_u_"
    ],
    "C": [
      "_i_",
      "_e_",
      "_o_",
      "_a_",
      "_u_"
    ]
  },
  "251": {
    "level": 23,
    "A": [
      "Review"
    ],
    "B": [
      "a_e",
      "ee",
      "i_e",
      "o_e",
      "u_e"
    ],
    "C": [
      "a_e",
      "ee",
      "i_e",
      "o_e",
      "u_e"
    ]
  },
  "252": {
    "level": 24,
    "A": [
      "Review"
    ],
    "B": [
      "a_e",
      "ee",
      "i_e",
      "o_e",
      "u_e",
      "_a_",
      "_o_",
      "_i_",
      "_e_",
      "_u_"
    ],
    "C": [
      "a_e",
      "ee",
      "i_e",
      "o_e",
      "u_e",
      "_a_",
      "_o_",
      "_i_",
      "_e_",
      "_u_"
    ]
  },
  "254": {
    "level": 1,
    "A": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "B": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "C": [
      "m",
      "s",
      "oo",
      "ee"
    ]
  },
  "255": {
    "level": 1,
    "A": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "B": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "C": [
      "m",
      "s",
      "oo",
      "ee"
    ]
  },
  "256": {
    "level": 1,
    "A": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "B": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "C": [
      "m",
      "s",
      "oo",
      "ee"
    ]
  },
  "257": {
    "level": 1,
    "A": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "B": [
      "m",
      "s",
      "oo",
      "ee"
    ],
    "C": [
      "m",
      "s",
      "oo",
      "ee"
    ]
  },
  "260": {
    "level": 23,
    "A": [
      "Review blending three sounds",
      "Blend CVC words"
    ],
    "B": [
      "Review blending three sounds",
      "Blend CVC words"
    ],
    "C": [
      "Review blending three sounds",
      "Blend CVC words"
    ]
  },
  "261": {
    "level": 24,
    "A": [
      "Review blending three sounds",
      "Blend CVC words"
    ],
    "B": [
      "Review blending three sounds",
      "Blend CVC words"
    ],
    "C": [
      "Review blending three sounds",
      "Blend CVC words"
    ]
  },
  "5088": {
    "level": 2,
    "A": [
      "sh",
      "aw",
      "f"
    ],
    "B": [
      "sh",
      "aw",
      "f"
    ],
    "C": [
      "sh",
      "aw",
      "f"
    ]
  },
  "5089": {
    "level": 3,
    "A": [
      "oy",
      "p",
      "t"
    ],
    "B": [
      "oy",
      "p",
      "t"
    ],
    "C": [
      "oy",
      "p",
      "t"
    ]
  },
  "5090": {
    "level": 15,
    "A": [
      "Review Lower Case"
    ],
    "B": [
      "Review Lower Case"
    ],
    "C": [
      "Review Lower Case"
    ]
  },
  "5091": {
    "level": 16,
    "A": [
      "Review Upper Case"
    ],
    "B": [
      "Review Upper Case"
    ],
    "C": [
      "Review Upper Case"
    ]
  },
  "5092": {
    "level": 17,
    "A": [
      "Review Lower Case"
    ],
    "B": [
      "Review Lower Case"
    ],
    "C": [
      "Review Lower Case"
    ]
  },
  "5093": {
    "level": 18,
    "A": [
      "Review Upper Case"
    ],
    "B": [
      "Review Upper Case"
    ],
    "C": [
      "Review Upper Case"
    ]
  },
  "5094": {
    "level": 19,
    "A": [
      "Review Lower Case"
    ],
    "B": [
      "Review Lower Case"
    ],
    "C": [
      "Review Lower Case"
    ]
  },
  "5095": {
    "level": 20,
    "A": [
      "Review Upper Case"
    ],
    "B": [
      "Review Upper Case"
    ],
    "C": [
      "Review Upper Case"
    ]
  },
  "5096": {
    "level": 21,
    "A": [
      "Review Upper Case"
    ],
    "B": [
      "Review Upper Case"
    ],
    "C": [
      "Review Upper Case"
    ]
  },
  "5097": {
    "level": 22,
    "A": [
      "Review Lower Case"
    ],
    "B": [
      "Review Lower Case"
    ],
    "C": [
      "Review Lower Case"
    ]
  },
  "5098": {
    "level": 23,
    "A": [
      "Review Upper Case"
    ],
    "B": [
      "Review Upper Case"
    ],
    "C": [
      "Review Upper Case"
    ]
  },
  "5099": {
    "level": 24,
    "A": [
      "Review Lower Case"
    ],
    "B": [
      "Review Lower Case"
    ],
    "C": [
      "Review Lower Case"
    ]
  },
  "5100": {
    "level": 24,
    "A": [
      "Review Lower Case"
    ],
    "B": [
      "Review Lower Case"
    ],
    "C": [
      "Review Lower Case"
    ]
  }
}

# a full list of all the acitivity level ids that correspond to phonological skills
phonological_als = [20, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121,
                    122, 123, 124, 125, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222,
                    223, 224, 225, 226, 227, 228, 229, 230, 231, 96, 97, 98, 99, 100, 101, 102, 232, 233, 234, 235, 236,
                    237, 238, 5090, 5091, 5092, 5093, 5094, 5095, 5096, 5097, 5098, 5099, 5100, 60, 61, 62, 63, 64, 65,
                    66, 67, 68, 69, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 255, 257, 41,
                    42, 43, 44, 45, 46, 47, 49, 50, 52, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 260,
                    261, 88, 89, 90, 91, 92, 93, 94, 95, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250,
                    251, 252, 70, 71, 72, 73, 74, 75, 76, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137,
                    138, 139, 254, 256, 5088, 5089, 53, 54, 55, 56, 57, 58, 59, 140, 141, 142, 143, 144, 145, 146, 147,
                    148, 149, 150, 151, 152, 153]

# a full list of all of the activity level ids that correspond to comprehension skills
comprehension_als = [3001, 3013, 3014, 3015, 3016, 3017, 3018, 3019, 3020, 3012, 3011, 3010, 3002, 3003, 3004, 3005,
                     3006, 3007, 3008, 3009, 3021, 3022, 3034, 3035, 3033, 3032, 3031, 3023, 3024, 3025, 3026, 3027,
                     3028, 3029, 3030, 2044, 2056, 2057, 2058, 2059, 2060, 2061, 2062, 2063, 2055, 2054, 2053, 2045,
                     2046, 2047, 2048, 2049, 2050, 2051, 2052, 2064, 2065, 2077, 2078, 2079, 2080, 2081, 2082, 2083,
                     2084, 2076, 2075, 2074, 2066, 2067, 2068, 2069, 2070, 2071, 2072, 2073, 2085, 2043, 2001, 2013,
                     2014, 2015, 2016, 2017, 2018, 2019, 2020, 2012, 2011, 2010, 2002, 2003, 2004, 2005, 2006, 2007,
                     2008, 2009, 2021, 2022, 2034, 2035, 2036, 2037, 2038, 2039, 2040, 2041, 2033, 2032, 2031, 2023,
                     2024, 2025, 2026, 2027, 2028, 2029, 2030, 2042, 5044, 5056, 5057, 5058, 5059, 5060, 5061, 5062,
                     5063, 5055, 5054, 5053, 5045, 5046, 5047, 5048, 5049, 5050, 5051, 5052, 5064, 5065, 5077, 5078,
                     5079, 5080, 5081, 5082, 5083, 5084, 5076, 5075, 5074, 5066, 5067, 5068, 5069, 5070, 5071, 5072,
                     5073, 5085, 5043, 5036, 5037, 5038, 5039, 5040, 5041, 5042]

# a mapping of which activity levels belong to each book
book_mapping = {1: [2001, 3001],
                2: [2002, 3002],
                3: [2003, 3003],
                4: [2004, 3004],
                5: [2005, 3005],
                6: [2006, 3006],
                7: [2007, 3007],
                8: [2008, 3008],
                9: [2009, 3009],
                10: [2010, 3010],
                11: [2011, 3011],
                12: [2012, 3012],
                13: [2013, 3013],
                14: [2014, 3014],
                15: [2015, 3015],
                16: [2016, 3016],
                17: [2017, 3017],
                18: [2018, 3018],
                19: [2019, 3019],
                20: [2020, 3020],
                21: [2021, 3021],
                22: [2022, 3022],
                23: [2023, 3023],
                24: [2024, 3024],
                25: [2025, 3025],
                26: [2026, 3026],
                27: [2027, 3027],
                28: [2028, 3028],
                29: [2029, 3029],
                30: [2030, 3030],
                31: [2031, 3031],
                32: [2032, 3032],
                33: [2033, 3033],
                34: [2034, 3034],
                35: [2035, 3035],
                36: [5036, 2036],
                37: [5037, 2037],
                38: [5038, 2038],
                39: [5039, 2039],
                40: [5040, 2040],
                41: [5041, 2041],
                42: [5042, 2042],
                43: [5043, 2043],
                44: [5044, 2044],
                45: [5045, 2045],
                46: [5046, 2046],
                47: [5047, 2047],
                48: [5048, 2048],
                49: [5049, 2049],
                50: [5050, 2050],
                51: [5051, 2051],
                52: [5052, 2052],
                53: [5053, 2053],
                54: [5054, 2054],
                55: [5055, 2055],
                56: [5056, 2056],
                57: [5057, 2057],
                58: [5058, 2058],
                59: [5059, 2059],
                60: [5060, 2060],
                61: [5061, 2061],
                62: [5062, 2062],
                63: [5063, 2063],
                64: [5064, 2064],
                65: [5065, 2065],
                66: [5066, 2066],
                67: [5067, 2067],
                68: [5068, 2068],
                69: [5069, 2069],
                70: [5070, 2070],
                71: [5071, 2071],
                72: [5072, 2072],
                73: [5073, 2073],
                74: [5074, 2074],
                75: [5075, 2075],
                76: [5076, 2076],
                77: [5077, 2077],
                78: [5078, 2078],
                79: [5079, 2079],
                80: [5080, 2080],
                81: [5081, 2081],
                82: [5082, 2082],
                83: [5083, 2083],
                84: [5084, 2084],
                85: [5085, 5086, 5087, 2085]}
