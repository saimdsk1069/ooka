from django.core.exceptions import PermissionDenied
from django.test import TestCase, mock
from digitalplatform.models import Organization, Section, Teacher
from reporting.views import ReportView
from sdm_authentication.utils import jwt_decode

DISTRICT_ADMIN_JWT = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJmb28iOiJiYXIiLCJvcmlnX2lhdCI6MTUxMjY4NDI2NCwiZ2FtZVVzZXJJZCI6NjksImRwUm9sZSI6ImRpc3RyaWN0QWRtaW4iLCJkaXN0cmljdElkIjozMzE3MDM1LCJkcElkIjozMzQ5MzA1fQ.ArEfFc0aut5O_5LPmk9rXW4kSWbRboOrft1Uejvfs0U"
SCHOOL_ADMIN_JWT = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJmb28iOiJiYXIiLCJvcmlnX2lhdCI6MTUxMjY4NDI2NCwiZ2FtZVVzZXJJZCI6NjksImRwUm9sZSI6InNjaG9vbEFkbWluIiwic2Nob29sSWQiOjMzMTcwMzQsImRwSWQiOjMzNDkzMDV9.AbIntHaKB2BpuoCefwEcsb5rVY0AUtPsWHa_c-VS2rw"
TEACHER_JWT = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJmb28iOiJiYXIiLCJvcmlnX2lhdCI6MTUxMjY4NDI2NCwiZ2FtZVVzZXJJZCI6NjksImRwUm9sZSI6InRlYWNoZXIiLCJzY2hvb2xJZCI6MzMxNzAzNCwiZHBJZCI6MzM0OTMwNX0.Tn6ykbiA6nXsvh2FKja6IsukYO-ZLePhJXaPG2MwLZ4"


class AccessControlTestCase(TestCase):

    @mock.patch('reporting.views.Organization.objects.get', mock.Mock(return_value=Organization(id=3317035)))
    @mock.patch('reporting.views.Organization.objects.filter_by_staff_and_parent')
    def test_get_district_data(self, MockOrgFilter):
        report_view = ReportView()
        report_view.get_district_data(3317035, jwt_decode(DISTRICT_ADMIN_JWT))
        self.assertEqual(report_view.district.id, 3317035)
        self.assertEqual(report_view.district, report_view.filter_record)

        MockOrgFilter.return_value = [Organization(id=3317035)]
        with self.assertRaises(PermissionDenied):
            report_view.get_district_data(3317036, jwt_decode(DISTRICT_ADMIN_JWT))

        with self.assertRaises(PermissionDenied):
            report_view.get_district_data(3317035, jwt_decode(SCHOOL_ADMIN_JWT))

        with self.assertRaises(PermissionDenied):
            report_view.get_district_data(3317035, jwt_decode(TEACHER_JWT))

    @mock.patch('reporting.views.Organization.objects.get')
    @mock.patch('reporting.views.Organization.objects.filter_by_staff_and_parent')
    def test_get_school_data(self, MockOrgFilter, MockOrgGet):
        report_view = ReportView()
        # By not throwing an error, this validates that permission is granted.
        school = Organization(id=3317034)
        report_view.district = Organization(id=99, schools=[school])
        MockOrgGet.return_value = Organization(id=99, schools=[school])
        MockOrgFilter.return_value = [school]
        report_view.get_school_data(3317034, jwt_decode(DISTRICT_ADMIN_JWT))
        self.assertEqual(report_view.school, school)
        self.assertEqual(report_view.school, report_view.filter_record)
        report_view.school = None
        MockOrgGet.return_value = school
        report_view.get_school_data(3317034, jwt_decode(SCHOOL_ADMIN_JWT))
        self.assertEqual(report_view.school, school)

        with self.assertRaises(PermissionDenied):
            report_view.get_district_data(3317036, jwt_decode(DISTRICT_ADMIN_JWT))

        with self.assertRaises(PermissionDenied):
            report_view.get_district_data(3317035, jwt_decode(SCHOOL_ADMIN_JWT))

        with self.assertRaises(PermissionDenied):
            report_view.get_district_data(3317035, jwt_decode(TEACHER_JWT))

    @mock.patch('reporting.views.Section.objects.filter_by_staff')
    @mock.patch('reporting.views.Teacher.objects.get')
    @mock.patch('reporting.views.Organization.objects.filter_by_staff_and_parent')
    @mock.patch('reporting.views.Section.objects.get')
    def test_get_section_data(self, MockSectionGet, MockOrgFilter, TeacherGetMock, MockSectionFilter):
        section = Section(id=168741, organizationId=3317034)
        MockSectionGet.return_value = section
        MockOrgFilter.return_value = [Organization(id=3317034)]
        TeacherGetMock.return_value = Teacher(id=1)
        MockSectionFilter.return_value = [section]
        report_view = ReportView()

        report_view.get_section_data(168741, jwt_decode(DISTRICT_ADMIN_JWT))
        self.assertEqual(report_view.section, section)
        self.assertEqual(report_view.section, report_view.filter_record)

        report_view.get_section_data(168741, jwt_decode(SCHOOL_ADMIN_JWT))
        self.assertEqual(report_view.section, section)

        report_view.get_section_data(168741, jwt_decode(TEACHER_JWT))
        self.assertEqual(report_view.section, section)

        with self.assertRaises(PermissionDenied):
            report_view.get_district_data(168749, jwt_decode(DISTRICT_ADMIN_JWT))

        with self.assertRaises(PermissionDenied):
            report_view.get_district_data(168749, jwt_decode(SCHOOL_ADMIN_JWT))

        with self.assertRaises(PermissionDenied):
            report_view.get_district_data(168749, jwt_decode(SCHOOL_ADMIN_JWT))
