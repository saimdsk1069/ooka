import datetime
import time
from django.test import mock, TestCase
from ookadogsled.elasticsearch_client import es, es_index_name
from digitalplatform.models import Organization, Section, Student, Teacher
from gameplay.models import Score, UserBookProgress
from ..views_overall_performance import OverallPerformanceAPI

DISTRICT_ADMIN_JWT = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJmb28iOiJiYXIiLCJvcmlnX2lhdCI6MTUxMjY4NDI2NCwiZ2FtZVVzZXJJZCI6NjksImRwUm9sZSI6ImRpc3RyaWN0QWRtaW4iLCJkaXN0cmljdElkIjozMzE3MDM1LCJkcElkIjozMzQ5MzA1fQ.ArEfFc0aut5O_5LPmk9rXW4kSWbRboOrft1Uejvfs0U"
SCHOOL_ADMIN_JWT = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJmb28iOiJiYXIiLCJvcmlnX2lhdCI6MTUxMjY4NDI2NCwiZ2FtZVVzZXJJZCI6NjksImRwUm9sZSI6InNjaG9vbEFkbWluIiwic2Nob29sSWQiOjMzMTcwMzQsImRwSWQiOjMzNDkzMDV9.AbIntHaKB2BpuoCefwEcsb5rVY0AUtPsWHa_c-VS2rw"
TEACHER_JWT = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJmb28iOiJiYXIiLCJvcmlnX2lhdCI6MTUxMjY4NDI2NCwiZ2FtZVVzZXJJZCI6NjksImRwUm9sZSI6InRlYWNoZXIiLCJzY2hvb2xJZCI6MzMxNzAzNCwiZHBJZCI6MzM0OTMwNX0.Tn6ykbiA6nXsvh2FKja6IsukYO-ZLePhJXaPG2MwLZ4"

ES_SCORES = [
    # auditory: 2/3 = practicing
    {'dp_id': 10, 'skill_type': 'phonological', 'skill_label': 'auditory', 'score': False, 'created': 1521457982},
    {'dp_id': 10, 'skill_type': 'phonological', 'skill_label': 'auditory', 'score': True, 'created': 1521457982},
    {'dp_id': 10, 'skill_type': 'phonological', 'skill_label': 'auditory', 'score': True, 'created': 1521457982},
    # correspondence 2/4 = learning
    {'dp_id': 10, 'skill_type': 'phonological', 'skill_label': 'correspondence', 'score': False, 'created': 1521457982},
    {'dp_id': 10, 'skill_type': 'phonological', 'skill_label': 'correspondence', 'score': False, 'created': 1521457982},
    {'dp_id': 10, 'skill_type': 'phonological', 'skill_label': 'correspondence', 'score': True, 'created': 1521457982},
    {'dp_id': 10, 'skill_type': 'phonological', 'skill_label': 'correspondence', 'score': True, 'created': 1521457982},
    # consonants 4/5 = proficient
    {'dp_id': 10, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 10, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 10, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': False, 'created': 1521457982},
    {'dp_id': 10, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 10, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    # One other user 5/6
    {'dp_id': 11, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 11, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 11, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': False, 'created': 1521457982},
    {'dp_id': 11, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 11, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 11, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},

    {'dp_id': 12, 'skill_type': 'comprehension', 'skill_label': 'sight', 'score': False, 'created': 1521457982},
    {'dp_id': 12, 'skill_type': 'comprehension', 'skill_label': 'sight', 'score': True, 'created': 1521457982},
    {'dp_id': 12, 'skill_type': 'comprehension', 'skill_label': 'sight', 'score': False, 'created': 1521457982},
    {'dp_id': 12, 'skill_type': 'comprehension', 'skill_label': 'sight', 'score': True, 'created': 1521457982},
    {'dp_id': 12, 'skill_type': 'comprehension', 'skill_label': 'sight', 'score': True, 'created': 1521457982},
    {'dp_id': 12, 'skill_type': 'comprehension', 'skill_label': 'sight', 'score': True, 'created': 1521457982}
]

ES_BOOK_PROGRESS_DOCS = [
    {'dp_id': 10, 'book_id': 1, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457932},
    {'dp_id': 10, 'book_id': 2, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457952},
    {'dp_id': 10, 'book_id': 3, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457992},
    {'dp_id': 11, 'book_id': 10, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457932},
    {'dp_id': 11, 'book_id': 12, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457932},
    {'dp_id': 12, 'book_id': 22, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457932},
    {'dp_id': 12, 'book_id': 26, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457932},
]


class MockResponse:

    def __init__(self, status=200, content=""):
        self.status_code = status
        self.content = content


students_list = [Student(id=3), Student(id=4), Student(id=5)]
ANTOICH_UNIFIED_DISTRICT = Organization(id=3317035, name="ANTIOCH UNIFIED SCHOOL DIST")

ANTOICH_MIDDLE_SCHOOL = Organization(id=3317034, name="ANTIOCH MIDDLE SCHOOL",
                                     sections=[Section(id=s) for s in [155528, 155611, 155612]],
                                     students=students_list
                                     )


class OverallPerformanceAPITestCase(TestCase):

    def setUp(self):
        es.indices.put_template(Score.es_score_template_name, Score.es_score_template)
        for score in ES_SCORES:
            es.index(index=es_index_name("score", datetime.datetime.now()), doc_type="default", body=score)

        es.indices.put_template(UserBookProgress.es_template_name, UserBookProgress.es_template)
        for book in ES_BOOK_PROGRESS_DOCS:
            es.index(index=es_index_name("book_progress"), doc_type="default", body=book)

        # Wait for the search index to catch up else bad things happen
        time.sleep(2)

    def tearDown(self):
        es.indices.delete(index=es_index_name("book_progress"))
        es.indices.delete(index='%s*' % es_index_name("score"))

    @mock.patch('reporting.views_overall_performance.OverallPerformanceAPI.student_ids_groups')
    def test_overall_performance_get_data(self, mock_student_ids_groups):
        view = OverallPerformanceAPI()
        view.query_param = 'districtId'

        mock_student_ids_groups.return_value = [
            {'id': 99, 'name': 'Test parent object', 'student_ids': [10, 11, 12]},
            {'id': 21, 'name': 'Test child object 1', 'student_ids': [10, 11]},
            {'id': 22, 'name': 'Test child object 2', 'student_ids': [12, 999]}
        ]
        view.filter_record = Organization(id=99, name='Something parent object')
        data = view.get_data()

        # we should get three cohorts
        self.assertEqual(len(data['cohorts']), 3)

        # the first cohort contains students 10, 11, 12
        self.assertEqual(data['cohorts'][0]['auditory'], 2./3)
        self.assertEqual(data['cohorts'][0]['alphabet'], 0)
        self.assertEqual(data['cohorts'][0]['correspondence'], 2./4)
        self.assertEqual(data['cohorts'][0]['consonants'], ((4/5) + (5/6))/2) # this is a combination of two avgs
        self.assertEqual(data['cohorts'][0]['vowels'], 0)
        self.assertEqual(data['cohorts'][0]['syllables'], 0)
        self.assertEqual(data['cohorts'][0]['blending'], 0)
        self.assertEqual(data['cohorts'][0]['concept'], 0)
        self.assertEqual(data['cohorts'][0]['sight'], 4/6)
        self.assertEqual(data['cohorts'][0]['text'], 0)
        self.assertEqual(data['cohorts'][0]['recallPictureText'], 0)
        self.assertEqual(data['cohorts'][0]['sequencingPictures'], 0)
        self.assertEqual(data['cohorts'][0]['sequencingText'], 0)

        # second cohort almost identical, but doesnt have 12
        self.assertEqual(data['cohorts'][1]['auditory'], 2./3)
        self.assertEqual(data['cohorts'][1]['alphabet'], 0)
        self.assertEqual(data['cohorts'][1]['correspondence'], 2./4)
        self.assertEqual(data['cohorts'][1]['consonants'], ((4/5) + (5/6))/2) # this is a combination of two avgs
        self.assertEqual(data['cohorts'][1]['vowels'], 0)
        self.assertEqual(data['cohorts'][1]['syllables'], 0)
        self.assertEqual(data['cohorts'][1]['blending'], 0)
        self.assertEqual(data['cohorts'][1]['concept'], 0)
        self.assertEqual(data['cohorts'][1]['sight'], 0)
        self.assertEqual(data['cohorts'][1]['text'], 0)
        self.assertEqual(data['cohorts'][1]['recallPictureText'], 0)
        self.assertEqual(data['cohorts'][1]['sequencingPictures'], 0)
        self.assertEqual(data['cohorts'][1]['sequencingText'], 0)

        # has only scores for 12
        self.assertEqual(data['cohorts'][2]['auditory'], 0)
        self.assertEqual(data['cohorts'][2]['alphabet'], 0)
        self.assertEqual(data['cohorts'][2]['correspondence'], 0)
        self.assertEqual(data['cohorts'][2]['consonants'], 0)
        self.assertEqual(data['cohorts'][2]['vowels'], 0)
        self.assertEqual(data['cohorts'][2]['syllables'], 0)
        self.assertEqual(data['cohorts'][2]['blending'], 0)
        self.assertEqual(data['cohorts'][2]['concept'], 0)
        self.assertEqual(data['cohorts'][2]['sight'], 4/6)
        self.assertEqual(data['cohorts'][2]['text'], 0)
        self.assertEqual(data['cohorts'][2]['recallPictureText'], 0)
        self.assertEqual(data['cohorts'][2]['sequencingPictures'], 0)
        self.assertEqual(data['cohorts'][2]['sequencingText'], 0)
