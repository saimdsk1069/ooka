import datetime
import time
from django.shortcuts import reverse
from django.test import mock, TestCase
from ookadogsled.elasticsearch_client import es, es_index_name
from digitalplatform.models import Organization, Section, Student, Teacher
from gameplay.models import Score, UserBookProgress
from ..views import ElasticSearchReportView, ReportNavMetricsAPI


DISTRICT_ADMIN_JWT = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJmb28iOiJiYXIiLCJvcmlnX2lhdCI6MTUxMjY4NDI2NCwiZ2FtZVVzZXJJZCI6NjksImRwUm9sZSI6ImRpc3RyaWN0QWRtaW4iLCJkaXN0cmljdElkIjozMzE3MDM1LCJkcElkIjozMzQ5MzA1fQ.ArEfFc0aut5O_5LPmk9rXW4kSWbRboOrft1Uejvfs0U"
SCHOOL_ADMIN_JWT = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJmb28iOiJiYXIiLCJvcmlnX2lhdCI6MTUxMjY4NDI2NCwiZ2FtZVVzZXJJZCI6NjksImRwUm9sZSI6InNjaG9vbEFkbWluIiwic2Nob29sSWQiOjMzMTcwMzQsImRwSWQiOjMzNDkzMDV9.AbIntHaKB2BpuoCefwEcsb5rVY0AUtPsWHa_c-VS2rw"
TEACHER_JWT = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJmb28iOiJiYXIiLCJvcmlnX2lhdCI6MTUxMjY4NDI2NCwiZ2FtZVVzZXJJZCI6NjksImRwUm9sZSI6InRlYWNoZXIiLCJzY2hvb2xJZCI6MzMxNzAzNCwiZHBJZCI6MzM0OTMwNX0.Tn6ykbiA6nXsvh2FKja6IsukYO-ZLePhJXaPG2MwLZ4"

ES_SCORES = [
    # One record for one student session- should yield time played 0 performance 100%
    {'session_key': 'some-uuid1', 'dp_id': 10, 'skill_type': 'comprehension', 'gameplay_location': 'out', 'score': True, 'activity_level_level_number': 3, 'created': 1521457932},
    # One student one session - should yield time played 100, performance 50%
    {'session_key': 'some-uuid2', 'dp_id': 11, 'skill_type': 'comprehension', 'gameplay_location': 'in', 'score': True, 'activity_level_level_number': 6, 'created': 1521457832},
    {'session_key': 'some-uuid2', 'dp_id': 11, 'skill_type': 'comprehension', 'gameplay_location': 'in', 'score': False, 'activity_level_level_number': 7, 'created': 1521457932},
    # One student two sessions - 50s, 550s
    {'session_key': 'some-uuid3', 'dp_id': 12, 'skill_type': 'comprehension', 'gameplay_location': 'in', 'score': True, 'activity_level_level_number': 9, 'created': 1521458000},
    {'session_key': 'some-uuid3', 'dp_id': 12, 'skill_type': 'comprehension', 'gameplay_location': 'in', 'score': True, 'activity_level_level_number': 9, 'created': 1521458050},
    {'session_key': 'some-uuid4', 'dp_id': 12, 'skill_type': 'phonological', 'gameplay_location': 'out', 'score': False, 'activity_level_level_number': 10, 'created': 1521459000},
    {'session_key': 'some-uuid4', 'dp_id': 12, 'skill_type': 'phonological', 'gameplay_location': 'out', 'score': False, 'activity_level_level_number': 11, 'created': 1521459500},
    {'session_key': 'some-uuid4', 'dp_id': 12, 'skill_type': 'phonological', 'gameplay_location': 'out', 'score': True, 'activity_level_level_number': 11, 'created': 1521459500},

    # Two more students not usually queried
    {'session_key': 'some-uuid5', 'dp_id': 13, 'skill_type': 'comprehension', 'gameplay_location': '', 'score': True, 'activity_level_level_number': 15, 'created': 1521457932},
    {'session_key': 'some-uuid5', 'dp_id': 13, 'skill_type': 'comprehension', 'gameplay_location': '', 'score': True, 'activity_level_level_number': 16, 'created': 1521457962},
    {'session_key': 'some-uuid6', 'dp_id': 14, 'skill_type': 'comprehension', 'gameplay_location': '', 'score': True, 'activity_level_level_number': 17, 'created': 1521457932},
    {'session_key': 'some-uuid6', 'dp_id': 14, 'skill_type': 'comprehension', 'gameplay_location': '', 'score': True, 'activity_level_level_number': 17, 'created': 1521457982},
]

ES_BOOK_PROGRESS_DOCS = [
    {'dp_id': 10, 'book_id': 1, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457932},
    {'dp_id': 10, 'book_id': 2, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457952},
    {'dp_id': 10, 'book_id': 3, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457992},
    {'dp_id': 11, 'book_id': 10, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457932},
    {'dp_id': 11, 'book_id': 12, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457932},
    {'dp_id': 12, 'book_id': 22, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457932},
    {'dp_id': 12, 'book_id': 26, 'times_read': 1, 'comprehension_state': 0, 'created': 1521457932},
]


class MockResponse:

    def __init__(self, status=200, content=""):
        self.status_code = status
        self.content = content


class BaseScoreTelemetryTestCase(TestCase):

    def setUp(self):
        es.indices.put_template(Score.es_score_template_name, Score.es_score_template)
        for score in ES_SCORES:
            es.index(index=es_index_name("score", datetime.datetime.now()), doc_type="default", body=score)

        es.indices.put_template(UserBookProgress.es_template_name, UserBookProgress.es_template)
        for book in ES_BOOK_PROGRESS_DOCS:
            es.index(index=es_index_name("book_progress"), doc_type="default", body=book)

        # Wait for the search index to catch up else bad things happen
        time.sleep(2)

    def tearDown(self):
        es.indices.delete(index=es_index_name("book_progress"))
        es.indices.delete(index='%s*' % es_index_name("score"))


class BaseReportViewTestCase(TestCase):

    @mock.patch('reporting.views.Teacher.objects.get', mock.Mock(return_value=Teacher(id=3317035)))
    @mock.patch('reporting.views.Organization.objects.get', mock.Mock(return_value=Organization(id=3317034)))
    @mock.patch('reporting.views.Section.objects.filter_by_staff', mock.Mock(return_value=[]))
    def test_get_query_param(self):
        self.client.defaults['HTTP_AUTHORIZATION'] = "Bearer %s" % TEACHER_JWT
        response = self.client.get("%s?teacherId=%d" % (reverse('web_bffs:reporting:time-played-table-nav'), 3349305))
        self.assertEqual(response.status_code, 200)


class ElasticSearchReportViewTestCase(TestCase):

    def test_student_ids_district(self):
        view = ElasticSearchReportView()
        view.dp_id = 123
        view.filter_type = 'district'
        students1 = Student(id=1, firstName='B', lastName='M'), Student(id=2, firstName='R', lastName='P')
        students2 = Student(id=3, firstName='B', lastName='M'), Student(id=4, firstName='R', lastName='P')
        view.district = Organization(
            id=123, name='Test District', orgType='district', schools=[
                Organization(id=70, name='Sch 70', orgType='school',
                             sections=[
                                 Section(id=1, students=students1)
                             ]),
                Organization(id=71, name='Sch 71', orgType='school',
                             sections=[
                                 Section(id=2, students=students2)
                             ])
            ]
        )
        student_ids = view.student_ids()
        self.assertEqual(student_ids['id'], 123)
        self.assertEqual(student_ids['name'], 'Test District')
        self.assertEqual(student_ids['student_ids'], [1, 2, 3, 4])

    def test_student_ids_school(self):
        view = ElasticSearchReportView()
        view.filter_type = 'school'
        students1 = Student(id=1, firstName='B', lastName='M'), Student(id=2, firstName='R', lastName='P')
        students2 = Student(id=3, firstName='B', lastName='M'), Student(id=4, firstName='R', lastName='P')
        view.school = Organization(
            id=123, name='Test School', orgType='school',
            sections=[
                Section(id=12, name='Test Section 12', students=students1),
                Section(id=13, name='Test Section 13', students=students2)
            ]
        )
        student_ids = view.student_ids()
        self.assertEqual(student_ids['id'], 123)
        self.assertEqual(student_ids['name'], 'Test School')
        self.assertEqual(student_ids['student_ids'], [1, 2, 3, 4])

    def test_student_ids_teacher(self):
        view = ElasticSearchReportView()
        view.filter_type = 'teacher'
        students1 = Student(id=5, firstName='B', lastName='M'), Student(id=6, firstName='R', lastName='P')
        students2 = Student(id=7, firstName='B', lastName='M'), Student(id=8, firstName='R', lastName='P')
        view.teacher = Teacher(id=123, firstName="Test", lastName="Teacher",
                               sections=[
                                   Section(id=1, name='Test Section 1', students=students1),
                                   Section(id=2, name='Test Section 2', students=students2)
                               ]
                               )
        student_ids = view.student_ids()
        self.assertEqual(student_ids['id'], 123)
        self.assertEqual(student_ids['name'], 'Test Teacher')
        self.assertEqual(student_ids['student_ids'], [5, 6, 7, 8])

    def test_student_ids_section(self):
        view = ElasticSearchReportView()
        view.filter_type = 'section'
        view.section = Section(id=123, name='Section Test',
                               students=[Student(id=1, firstName='B', lastName='M'), Student(id=2, firstName='R', lastName='P')]
                               )
        student_ids = view.student_ids()
        self.assertEqual(student_ids['id'], 123)
        self.assertEqual(student_ids['name'], 'Section Test')
        self.assertEqual(student_ids['student_ids'], [1, 2])

    def test_student_ids_student(self):
        view = ElasticSearchReportView()
        view.filter_type = 'student'
        section = Section(id=123, name='Section Test',
                          students=[Student(id=1, firstName='B', lastName='M'), Student(id=2, firstName='R', lastName='P')]
                          )
        view.student = Student(id=1, firstName='B', lastName='M', section=section)
        student_ids = view.student_ids()
        self.assertEqual(student_ids['id'], 1)
        self.assertEqual(student_ids['name'], 'B M')
        self.assertEqual(student_ids['student_ids'], [1, 2])

    def test_student_ids_groups_district(self):
        view = ElasticSearchReportView()
        view.dp_id = 123
        view.filter_type = 'district'
        students1 = Student(id=1, firstName='B', lastName='M'), Student(id=2, firstName='R', lastName='P')
        students2 = Student(id=3, firstName='B', lastName='M'), Student(id=4, firstName='R', lastName='P')
        view.district = Organization(
            id=123, name='Test District', orgType='district', schools=[
                Organization(id=70, name='Sch 70', orgType='school',
                             sections=[
                                 Section(id=1, students=students1)
                             ]),
                Organization(id=71, name='Sch 71', orgType='school',
                             sections=[
                                 Section(id=2, students=students2)
                             ])
            ]
        )
        student_ids_groups = view.student_ids_groups()
        self.assertEqual(student_ids_groups[0]['id'], 123)
        self.assertEqual(student_ids_groups[0]['name'], 'Test District')
        self.assertEqual(student_ids_groups[0]['student_ids'], [1, 2, 3, 4])
        self.assertEqual(student_ids_groups[1]['id'], 70)
        self.assertEqual(student_ids_groups[1]['name'], 'Sch 70')
        self.assertEqual(student_ids_groups[1]['student_ids'], [1, 2])
        self.assertEqual(student_ids_groups[2]['id'], 71)
        self.assertEqual(student_ids_groups[2]['name'], 'Sch 71')
        self.assertEqual(student_ids_groups[2]['student_ids'], [3, 4])

    def test_student_ids_groups_school(self):
        view = ElasticSearchReportView()
        view.filter_type = 'school'
        students1 = Student(id=1, firstName='B', lastName='M'), Student(id=2, firstName='R', lastName='P')
        students2 = Student(id=3, firstName='B', lastName='M'), Student(id=4, firstName='R', lastName='P')
        view.school = Organization(
            id=123, name='Test School', orgType='school',
            sections=[
                Section(id=12, name='Test Section 12', students=students1),
                Section(id=13, name='Test Section 13', students=students2)
            ]
        )
        student_ids_groups = view.student_ids_groups()
        self.assertEqual(student_ids_groups[0]['id'], 123)
        self.assertEqual(student_ids_groups[0]['name'], 'Test School')
        self.assertEqual(student_ids_groups[0]['student_ids'], [1, 2, 3, 4])
        self.assertEqual(student_ids_groups[1]['id'], 12)
        self.assertEqual(student_ids_groups[1]['name'], 'Test Section 12')
        self.assertEqual(student_ids_groups[1]['student_ids'], [1, 2])
        self.assertEqual(student_ids_groups[2]['id'], 13)
        self.assertEqual(student_ids_groups[2]['name'], 'Test Section 13')
        self.assertEqual(student_ids_groups[2]['student_ids'], [3, 4])

    def test_student_ids_groups_teacher(self):
        view = ElasticSearchReportView()
        view.filter_type = 'teacher'
        students1 = Student(id=5, firstName='B', lastName='M'), Student(id=6, firstName='R', lastName='P')
        students2 = Student(id=7, firstName='B', lastName='M'), Student(id=8, firstName='R', lastName='P')
        view.teacher = Teacher(id=123, firstName="Test", lastName="Teacher",
                               sections=[
                                   Section(id=1, name='Test Section 1', students=students1),
                                   Section(id=2, name='Test Section 2', students=students2)
                               ]
                               )
        student_ids_groups = view.student_ids_groups()
        self.assertEqual(student_ids_groups[0]['id'], 123)
        self.assertEqual(student_ids_groups[0]['name'], 'Test Teacher')
        self.assertEqual(student_ids_groups[0]['student_ids'], [5, 6, 7, 8])
        self.assertEqual(student_ids_groups[1]['id'], 1)
        self.assertEqual(student_ids_groups[1]['name'], 'Test Section 1')
        self.assertEqual(student_ids_groups[1]['student_ids'], [5, 6])
        self.assertEqual(student_ids_groups[2]['id'], 2)
        self.assertEqual(student_ids_groups[2]['name'], 'Test Section 2')
        self.assertEqual(student_ids_groups[2]['student_ids'], [7, 8])

    def test_student_ids_groups_section(self):
        view = ElasticSearchReportView()
        view.filter_type = 'section'
        view.section = Section(id=123, name='Section Test',
                               students=[Student(id=1, firstName='B', lastName='M'), Student(id=2, firstName='R', lastName='P')]
                               )
        student_ids_groups = view.student_ids_groups()
        self.assertEqual(student_ids_groups[0]['id'], 123)
        self.assertEqual(student_ids_groups[0]['name'], 'Section Test')
        self.assertEqual(student_ids_groups[0]['student_ids'], [1, 2])
        self.assertEqual(student_ids_groups[1]['id'], 1)
        self.assertEqual(student_ids_groups[1]['name'], 'B M')
        self.assertEqual(student_ids_groups[1]['student_ids'], [1])
        self.assertEqual(student_ids_groups[2]['id'], 2)
        self.assertEqual(student_ids_groups[2]['name'], 'R P')
        self.assertEqual(student_ids_groups[2]['student_ids'], [2])

    def test_student_ids_grades_groups_district(self):
        view = ElasticSearchReportView()
        view.dp_id = 123
        view.filter_type = 'district'
        students1 = Student(id=1, firstName='B', lastName='M', grade='K'), Student(id=2, firstName='R', lastName='P', grade='K')
        students2 = Student(id=3, firstName='B', lastName='M', grade='1'), Student(id=4, firstName='R', lastName='P', grade='1')
        view.district = Organization(
            id=123, name='Test District', orgType='district', schools=[
                Organization(id=70, name='Sch 70', orgType='school', students=students1),
                Organization(id=71, name='Sch 71', orgType='school', students=students2)
            ]
        )
        student_ids_grades_groups = view.student_ids_grades_groups()
        self.assertEqual(student_ids_grades_groups[0]['grade'], 'K')
        self.assertEqual(student_ids_grades_groups[0]['name'], 'Kindergarten')
        self.assertEqual(student_ids_grades_groups[0]['student_ids'], [1, 2])
        self.assertEqual(student_ids_grades_groups[1]['grade'], '1')
        self.assertEqual(student_ids_grades_groups[1]['name'], 'First Grade')
        self.assertEqual(student_ids_grades_groups[1]['student_ids'], [3, 4])


class ReportNavMetricsTestCase(TestCase):

    def setUp(self):
        es.indices.put_template(Score.es_score_template_name, Score.es_score_template)
        for score in ES_SCORES:
            es.index(index=es_index_name("score", datetime.datetime.now()), doc_type="default", body=score)

        es.indices.put_template(UserBookProgress.es_template_name, UserBookProgress.es_template)
        for book in ES_BOOK_PROGRESS_DOCS:
            es.index(index=es_index_name("book_progress"), doc_type="default", body=book)

        # Wait for the search index to catch up else bad things happen
        time.sleep(2)

    def tearDown(self):
        es.indices.delete(index=es_index_name("book_progress"))
        es.indices.delete(index='%s*' % es_index_name("score"))

    @mock.patch('reporting.views.ReportNavMetricsAPI.student_ids')
    def test_get_data(self, mock_student_ids):
        view = ReportNavMetricsAPI()
        view.query_param = 'districtId'
        mock_student_ids.return_value = {'id': 98765, 'name': 'Test parent record', 'student_ids': [10, 11, 12]}
        view.filter_record = Organization(id=99, name='Something parent object')
        data = view.get_data()

        expected_comp = int(4/5 * 100)
        expected_phon = int(1/3 * 100)
        expected_avg = int((expected_phon+expected_comp)/2)
        # pretty simple to test, just check that all of the numbers match up in cohortSummary
        self.assertEqual(data['cohortSummary']['time_played'], str(int(round(650/60))))
        self.assertEqual(data['cohortSummary']['comprehension'], expected_comp)
        self.assertEqual(data['cohortSummary']['phonological'], expected_phon)
        self.assertEqual(data['cohortSummary']['overallAvg'], expected_avg)

    @mock.patch('reporting.views.ReportNavMetricsAPI.student_ids')
    def test_get_data_time_formatting(self, mock_student_ids):
        # insert a really long session to test the formatting of many minutes
        session_start = {'session_key': 'some-uuid5', 'dp_id': 11, 'skill_type': 'phonological', 'gameplay_location': 'out', 'score': False, 'activity_level_level_number': 13, 'created': 1421459000}
        session_end = {'session_key': 'some-uuid5', 'dp_id': 11, 'skill_type': 'phonological', 'gameplay_location': 'out', 'score': False, 'activity_level_level_number': 13, 'created': 1521459000}
        es.index(index=es_index_name("score", datetime.datetime.now()), doc_type="default", body=session_start)
        es.index(index=es_index_name("score", datetime.datetime.now()), doc_type="default", body=session_end)
        time.sleep(2)

        view = ReportNavMetricsAPI()
        view.query_param = 'districtId'
        mock_student_ids.return_value = {'id': 98765, 'name': 'Test parent record', 'student_ids': [10, 11, 12]}
        view.filter_record = Organization(id=99, name='Something parent object')
        data = view.get_data()

        expected_comp = int(4/5 * 100)
        expected_phon = int(1/5 * 100)
        expected_avg = int((expected_phon+expected_comp)/2)
        # pretty simple to test, just check that all of the numbers match up in cohortSummary
        self.assertEqual(data['cohortSummary']['time_played'], "1666K")  # 1521459000 - 1421459000 = 1666 Minutes
        self.assertEqual(data['cohortSummary']['comprehension'], expected_comp)
        self.assertEqual(data['cohortSummary']['phonological'], expected_phon)
        self.assertEqual(data['cohortSummary']['overallAvg'], expected_avg)

    @mock.patch('reporting.views.ReportNavMetricsAPI.student_ids')
    def test_get_data_empty_state(self, mock_student_ids):
        view = ReportNavMetricsAPI()
        view.query_param = 'districtId'
        mock_student_ids.return_value = {'id': 98765, 'name': 'Test parent record', 'student_ids': [18, 19, 20]}
        view.filter_record = Organization(id=99, name='Something parent object')
        data = view.get_data()

        # everything should just have zeroes since these student don't have any data
        self.assertEqual(data['cohortSummary']['time_played'], str(0))
        self.assertEqual(data['cohortSummary']['comprehension'], 0)
        self.assertEqual(data['cohortSummary']['phonological'], 0)
        self.assertEqual(data['cohortSummary']['overallAvg'], 0)


