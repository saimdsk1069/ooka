from django.test import mock, TestCase
from digitalplatform.models import Organization
from ..views_overview import OverviewScoreTimeTableNavView
from .test_views import BaseScoreTelemetryTestCase


class OverviewViewsTestCase(BaseScoreTelemetryTestCase):

    @mock.patch('reporting.views_time_played.BaseTableNavElasticSearchReportView.student_ids_groups')
    def test_overview_average_score_time_table_nav_get_data(self, mock_student_ids_groups):
        """
        O1 - Overview table nav: average time played, average score
        """
        view = OverviewScoreTimeTableNavView()
        view.query_param = 'districtId'
        mock_student_ids_groups.return_value = [
            {'id': 99, 'name': 'Test parent object', 'student_ids': [10, 11, 12]},
            {'id': 21, 'name': 'Test child object 1', 'student_ids': [10, 11]},
            {'id': 22, 'name': 'Test child object 2', 'student_ids': [12, 999]}
        ]
        view.filter_record = Organization(id=99, name="Test Org")
        data = view.get_data()
        self.assertEqual(data['table']['tableTitle'], 'Schools')
        self.assertEqual(data['table']['metricTitle'], 'Overview')
        self.assertEqual(data['table']['cohortTitle'], 'Test Org')
        self.assertEqual(data['table']['cohortType'], 'schoolsGroup')
        self.assertEqual(data['table']['columns'][0]['name'], 'School')
        self.assertEqual(len(data['table']['rows']), 3)
        self.assertEqual(data['table']['rows'][0]['id'], 99)
        self.assertEqual(data['table']['rows'][0]['name'], 'Test parent object')
        self.assertEqual(data['table']['rows'][0]['score'], 4 / 7)
        self.assertEqual(data['table']['rows'][0]['time'], round(650 / 60 / 3))
        self.assertEqual(data['table']['rows'][1]['score'], 2 / 3)
        self.assertEqual(data['table']['rows'][1]['time'], round(100 / 60 / 2))

        # @TODO replace with real data if this endpoint really needs it
        # self.assertEqual(data['table']['cohortSummary']['overview'], 'Full District')
        # self.assertEqual(content['table']['cohortSummary']['numberOfStudents'], '725')
        # self.assertEqual(content['table']['cohortSummary']['timePlayed'], '1298')
        # self.assertEqual(content['table']['cohortSummary']['booksRead'], '1592')
        # self.assertEqual(content['table']['cohortSummary']['phonological'], '74%')
        # self.assertEqual(content['table']['cohortSummary']['comprehension'], '83%')


class PerformanceOverviewAPITestCase(TestCase):

    def setUp(self):
        unlock_type = UnlockType.objects.create(type='type')

        # these tests are tricky to setup. Populate book, activitylevel and activity with fixtures from
        # legacy data.
        with open('./reporting/tests/fixtures/book_fixture.json') as book_file:
            book_data = json.load(book_file)
            for book in book_data['books']:
                fields = book['fields']
                Book.objects.create(id=book['pk'], name=fields['bookname'], active=True, sound_path='/dev/null',
                                    book_level=fields['booklevel'], readable_name=fields['readablename'])

        with open('./reporting/tests/fixtures/activity_fixture.json') as activity_file:
            activity_data = json.load(activity_file)
            for activity in activity_data['activities']:
                fields = activity['fields']
                Activity.objects.create(id=activity['pk'], name=fields['activityname'], is_score_based=True,
                                        active=True, max_level=fields['maxlevel'])

        with open('./reporting/tests/fixtures/activity_level_fixture.json') as activitylevel_file:
            activitylevel_data = json.load(activitylevel_file)
            for activitylevel in activitylevel_data['activitylevels']:
                fields = activitylevel['fields']
                ActivityLevel.objects.create(pk=activitylevel['pk'], activity_id=fields['activity'],
                                             level_number=fields['levelnumber'], unlock_type=unlock_type,
                                             question_type=1)

    @mock.patch('elasticsearch.Elasticsearch.search', mock.Mock(return_value=es_student_result_mock))
    def test_get_overview_performance(self):
        # first simple test, the user doesnt have gameplay recorded, so this should be full of zeroes
        performance_overview = PerformanceOverviewAPI.get_performance_overview(
            Student(id=3349306, firstName="Brent", lastName="Mitton"),
            'gameusers'
        )

        labels = {**PerformanceOverviewAPI._get_comprehension_labels,
                  **PerformanceOverviewAPI._get_phonological_labels}

        for skill in labels:
            self.assertEqual(0, performance_overview[0][skill])

        # now give the user some gameplay and do validations to make sure that the results are only on recent gameplay
        game_user = GameUser.objects.create(dp_id="3349306", dp_role="student")

        for i in range(1, 26):
            UserBookProgress.objects.create(game_user=game_user, book_id=i)

        performance_overview = PerformanceOverviewAPI.get_performance_overview(
            [Student(id=3349306, firstName="Brent", lastName="Mitton")], 'gameusers'
        )

        # since the user has reached book 25, we should see results for books 20-25. During those books the skills
        # that are practiced are concept of word and recall with picture support
        self.assertNotEqual(0, performance_overview[0]['concept'])
        self.assertNotEqual(0, performance_overview[0]['recallPictureText'])

    def test_get_user_recent_gameplay(self):
        game_user1 = GameUser.objects.create(dp_id="12", dp_role="student")
        game_user2 = GameUser.objects.create(dp_id="13", dp_role="student")

        user_level_progress = [20, 41, 42, 43, 44, 45, 46, 47, 49, 50, 52, 53, 54, 55, 56, 57, 58, 59, 61, 62, 63, 64,
                               65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 88,
                               89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108,
                               109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126,
                               127, 128, 129, 130, 131, 132, 133, 134, 140, 141, 142, 143, 144, 145, 146, 147, 154, 168,
                               169, 170, 171, 172, 173, 174, 181, 182, 183, 184, 185, 186, 187, 188, 189, 195, 196, 197,
                               198, 199, 200, 201, 202, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219,
                               220, 221, 222, 223, 224, 225, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243,
                               244, 245, 246, 254, 255, 256, 257, 258, 5088, 5089, 5090, 5091, 5092, 5093, 5094, 5095,
                               5096, 5097, 5098, 5099, 5100]

        # give the game users some progress
        for al in user_level_progress:
            UserActivityLevelProgress.objects.create(activity_level_id=al, game_user=game_user1)

        for i in range(1, 26):
            UserBookProgress.objects.create(game_user=game_user1, book_id=i)

        als = PerformanceOverviewAPI.get_user_recent_gameplay([game_user1.dp_id, game_user2.dp_id])

        # we should have the users most recent activities for auditory
        expected_auditory = [222, 223, 224, 225]
        for e in expected_auditory:
            self.assertIn(e, als['12'])

        expected_recallPictureText = [2025, 2024, 2023, 2022, 2021]
        for e in expected_recallPictureText:
            self.assertIn(e, als['12'])

    def test_get_skill_querysets(self):
        # create some user level progress for multiple users
        game_user1 = GameUser.objects.create(dp_id="12", dp_role="student")
        game_user2 = GameUser.objects.create(dp_id="13", dp_role="student")

        user_level_progress = [20, 41, 42, 43, 44, 45, 46, 47, 49, 50, 52, 53, 54, 55, 56, 57, 58, 59, 61, 62, 63, 64,
                               65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 88,
                               89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108,
                               109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126,
                               127, 128, 129, 130, 131, 132, 133, 134, 140, 141, 142, 143, 144, 145, 146, 147, 154, 168,
                               169, 170, 171, 172, 173, 174, 181, 182, 183, 184, 185, 186, 187, 188, 189, 195, 196, 197,
                               198, 199, 200, 201, 202, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219,
                               220, 221, 222, 223, 224, 225, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243,
                               244, 245, 246, 254, 255, 256, 257, 258, 5088, 5089, 5090, 5091, 5092, 5093, 5094, 5095,
                               5096, 5097, 5098, 5099, 5100]

        # give the game users some progress
        for al in user_level_progress:
            UserActivityLevelProgress.objects.create(activity_level_id=al, game_user=game_user1)
            UserActivityLevelProgress.objects.create(activity_level_id=al, game_user=game_user2)

        # get the queryset containing data for these users (in this test we can use .all())
        result = PerformanceOverviewAPI._get_skill_querysets(UserActivityLevelProgress.objects.all())

        # make sure that all ulp objects have been sorted into the subquerysets correctly
        for ulp in result['auditory']:
            self.assertIn(ulp.activity_level.id, skill_reverse_mapping['auditory'])
        for ulp in result['correspondence']:
            self.assertIn(ulp.activity_level.id, skill_reverse_mapping['correspondence'])
        for ulp in result['consonants']:
            self.assertIn(ulp.activity_level.id, skill_reverse_mapping['consonants'])
        for ulp in result['alphabet']:
            self.assertIn(ulp.activity_level.id, skill_reverse_mapping['alphabet'])
        for ulp in result['vowels']:
            self.assertIn(ulp.activity_level.id, skill_reverse_mapping['vowels'])
        for ulp in result['syllables']:
            self.assertIn(ulp.activity_level.id, skill_reverse_mapping['syllables'])
        for ulp in result['blending']:
            self.assertIn(ulp.activity_level.id, skill_reverse_mapping['blending'])

    def test_get_user_skill_levels(self):
        # create some user level progress for multiple users
        game_user1 = GameUser.objects.create(dp_id="12", dp_role="student")
        game_user2 = GameUser.objects.create(dp_id="13", dp_role="student")

        user_level_progress1 = [20, 41, 42, 43, 44, 45, 46, 47, 49, 50, 52, 53, 54, 55, 56, 57, 58, 59, 61, 62, 63, 64,
                               65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 88,
                               89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108,
                               109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126,
                               127, 128, 129, 130, 131, 132, 133, 134, 140, 141, 142, 143, 144, 145, 146, 147, 154, 168,
                               169, 170, 171, 172, 173, 174, 181, 182, 183, 184, 185, 186, 187, 188, 189, 195, 196, 197,
                               198, 199, 200, 201, 202, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219,
                               220, 221, 222, 223, 224, 225, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243,
                               244, 245, 246, 254, 255, 256, 257, 258, 5088, 5089, 5090, 5091, 5092, 5093, 5094, 5095,
                               5096, 5097, 5098, 5099, 5100]

        user_level_progress2 = [20, 41, 42, 43, 44, 45, 46, 47, 49, 50, 52, 53, 54, 55, 56, 57, 58, 59, 61, 62, 63, 64,
                               65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 88,
                               89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108,
                               109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126,
                               127, 128, 129, 130, 131, 132, 133, 134, 140, 141, 142, 143, 144, 145, 146, 147, 154, 168,
                               169, 170, 171, 172, 173, 174, 181, 182, 183, 184, 185, 186, 187, 188, 189, 195, 196, 197,
                               198, 199, 200, 201, 202, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219]

        # give the game users some progres
        for al in user_level_progress1:
            UserActivityLevelProgress.objects.create(activity_level_id=al, game_user=game_user1)
        for al in user_level_progress2:
            UserActivityLevelProgress.objects.create(activity_level_id=al, game_user=game_user2)

        user_ids = [12, 13]
        skill_querysets = PerformanceOverviewAPI._get_skill_querysets(UserActivityLevelProgress.objects.all())

        results = PerformanceOverviewAPI._get_user_skill_levels(user_ids, skill_querysets)

        # TODO: This could be tests a lot more thoroughly
        # do a smattering of random validations
        self.assertIn(19, results['12']['auditory'])  # user 1 on level 19 auditory
        self.assertEqual(set([224, 225]), set(results['12']['auditory'][19]))  # level 19 auditory has correct levels
        self.assertNotIn(19, results['13']['auditory'])  # user 1 not on level 19 auditory
        self.assertIn(15, results['13']['consonants'])  # user 2 on level 15 consonants

    def test_get_recent_skill_als(self):
        # create some user level progress for multiple users
        game_user1 = GameUser.objects.create(dp_id="12", dp_role="student")
        game_user2 = GameUser.objects.create(dp_id="13", dp_role="student")

        user_level_progress1 = [20, 41, 42, 43, 44, 45, 46, 47, 49, 50, 52, 53, 54, 55, 56, 57, 58, 59, 61, 62, 63, 64,
                               65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 88,
                               89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108,
                               109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126,
                               127, 128, 129, 130, 131, 132, 133, 134, 140, 141, 142, 143, 144, 145, 146, 147, 154, 168,
                               169, 170, 171, 172, 173, 174, 181, 182, 183, 184, 185, 186, 187, 188, 189, 195, 196, 197,
                               198, 199, 200, 201, 202, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219,
                               220, 221, 222, 223, 224, 225, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243,
                               244, 245, 246, 254, 255, 256, 257, 258, 5088, 5089, 5090, 5091, 5092, 5093, 5094, 5095,
                               5096, 5097, 5098, 5099, 5100]

        user_level_progress2 = [20, 41, 42, 43, 44, 45, 46, 47, 49, 50, 52, 53, 54, 55, 56, 57, 58, 59, 61, 62, 63, 64,
                               65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 88,
                               89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108,
                               109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126,
                               127, 128, 129, 130, 131, 132, 133, 134, 140, 141, 142, 143, 144, 145, 146, 147, 154, 168,
                               169, 170, 171, 172, 173, 174, 181, 182, 183, 184, 185, 186, 187, 188, 189, 195, 196, 197,
                               198, 199, 200, 201, 202, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219]

        # give the game users some progres
        for al in user_level_progress1:
            UserActivityLevelProgress.objects.create(activity_level_id=al, game_user=game_user1)
        for al in user_level_progress2:
            UserActivityLevelProgress.objects.create(activity_level_id=al, game_user=game_user2)

        user_ids = [12, 13]
        skill_querysets = PerformanceOverviewAPI._get_skill_querysets(UserActivityLevelProgress.objects.all())

        user_skill_levels = PerformanceOverviewAPI._get_user_skill_levels(user_ids, skill_querysets)

        results = PerformanceOverviewAPI._get_recent_skill_als(user_skill_levels)

        # user 1 is on level 19 correspondence, so we should return the activitylevels for level 19 and
        # 18 correspondence
        # TODO: More validations
        self.assertEqual(set([134, 224, 225, 133, 222, 223, 246]), set(results['12']['correspondence']))

    def test_get_most_recent_books(self):
        game_user1 = GameUser.objects.create(dp_id="12", dp_role="student")
        game_user2 = GameUser.objects.create(dp_id="13", dp_role="student")

        for i in range(1, 26):
            UserBookProgress.objects.create(game_user=game_user1, book_id=i)
        for j in range(1, 15):
            UserBookProgress.objects.create(game_user=game_user2, book_id=j)

        results = PerformanceOverviewAPI._get_most_recent_book_als([12, 13], UserBookProgress.objects.all())

        self.assertEqual(set([2025, 2024, 2023, 2022, 2021, 3025, 3024, 3023, 3022, 3021]), set(results['12']))
        self.assertEqual(set([2014, 2013, 2012, 2011, 2010, 3014, 3013, 3012, 3011, 3010]), set(results['13']))

    def test_overview_run_time(self):
        # TODO: Just an idea for a test. Make sure that this endpoint is performant on a bunch of users with
        # TODO: a bunch of progress. 50 is a realistic upper bound on # of users
        pass


class SnapshotAPITestCase(BaseScoreTelemetryTestCase):

    @mock.patch('reporting.views.Organization.objects.filter_by_staff_and_parent')
    def test_snapshot_infographic_by_district(self, SchoolMock1):
        """
        Infographic snapshot, for one district
        """
        SchoolMock1.return_value = [
            Organization(id=3317035, name='ANTIOCH UNIFIED SCH', orgType='school', teachers=[]),
            Organization(id=2, name='Other School', orgType='school', teachers=[]),
        ]

        view = SnapshotInfographicAPI()
        test_district = ANTOICH_UNIFIED_DISTRICT
        test_district.teachers = [
            Teacher(id=1234, firstName='Teacher', lastName='1'),
            Teacher(id=55555, firstName='Teacher', lastName='2'),
            Teacher(id=666666, firstName='Teacher', lastName='3')
        ]
        test_district.sections = [
            Section(id=1),
            Section(id=2),
            Section(id=3)
        ]
        test_district.students = [
            Student(id=1, grade='K'),
            Student(id=2, grade='1'),
            Student(id=3, grade='1'),
            Student(id=4, grade='2'),
            Student(id=5, grade='2'),
            Student(id=6, grade='2')
        ]
        view.district = test_district
        view.district.orgType = 'district'
        content = view.get_data(query_param='districtId', value=view.district.id)

        self.assertEqual(content['table']['cohort'], "ANTIOCH UNIFIED SCHOOL DIST")
        self.assertEqual(content['table']['cohortTitle'], "ANTIOCH UNIFIED SCHOOL DIST")
        self.assertEqual(content['table']['cohortType'], 'schoolsGroup')
        self.assertEqual(len(content['table']['columns']), 4)
        self.assertIn('pie', content['table'])
        self.assertEqual(content['table']['pie']['K'], 1)
        self.assertEqual(content['table']['pie']['1'], 2)
        self.assertEqual(content['table']['pie']['2'], 3)
        self.assertEqual(content['table']['rows'][0]['schools'], 2)
        self.assertEqual(content['table']['rows'][0]['teachers'], 3)
        self.assertEqual(content['table']['rows'][0]['classes'], 18)
        self.assertEqual(content['table']['rows'][0]['students'], 6)
        self.assertEqual(content['table']['sortOrder'], 'asc')
        self.assertEqual(content['table']['sortType'], 'alphabetical')

    def test_snapshot_infographic_by_school(self):
        """
        Infographic snapshot, for one school - Warning, slow! Hits DP once per section.
        """
        students = [
            Student(id=1, grade='K'),
            Student(id=2, grade='1'),
            Student(id=3, grade='1'),
            Student(id=4, grade='2'),
            Student(id=5, grade='2'),
            Student(id=6, grade='2')
        ]
        sections = [Section(id=s) for s in [155528, 155611, 155612]]
        teachers = [Teacher(), Teacher(), Teacher()]
        view = SnapshotInfographicAPI()
        view.school = Organization(id=3317034, name="ANTIOCH MIDDLE SCHOOL", sections=sections, teachers=teachers,
                                   students=students)
        content = view.get_data(query_param='schoolId', value=view.school.id)
        self.assertEqual(content['table']['cohort'], "ANTIOCH MIDDLE SCHOOL")
        self.assertEqual(content['table']['cohortTitle'], "ANTIOCH MIDDLE SCHOOL")
        self.assertEqual(content['table']['cohortType'], 'sections')
        self.assertEqual(len(content['table']['columns']), 3)
        self.assertIn('pie', content['table'])
        # @TODO Replace with actuals
        self.assertEqual(content['table']['pie']['K'], 1)
        self.assertEqual(content['table']['pie']['1'], 2)
        self.assertEqual(content['table']['pie']['2'], 3)
        self.assertNotIn('schools', content['table']['rows'][0])
        self.assertEqual(content['table']['rows'][0]['teachers'], 3)
        self.assertEqual(content['table']['rows'][0]['classes'], 3)
        self.assertEqual(content['table']['rows'][0]['students'], 6)
        self.assertEqual(content['table']['sortOrder'], 'asc')
        self.assertEqual(content['table']['sortType'], 'alphabetical')

    def test_snapshot_infographic_by_teacher(self):
        """
        Infographic snapshot, for one teacher
        """
        sections = [Section(id=1, name='TST1'), Section(id=2, name='TST2')]
        students = [
            Student(id=1, grade='K'),
            Student(id=2, grade='1'),
            Student(id=3, grade='1'),
            Student(id=4, grade='2'),
            Student(id=5, grade='2'),
            Student(id=6, grade='2')
        ]
        view = SnapshotInfographicAPI()
        view.teacher = Teacher(id=55, firstName='Ooka', lastName='Dev', organizationId=3317034, sections=sections,
                               students=students)
        content = view.get_data(query_param='teacherId', value=view.teacher.id)
        self.assertEqual(content['table']['cohort'], 'Ooka Dev')
        self.assertEqual(content['table']['cohortTitle'], 'Ooka Dev')
        self.assertEqual(content['table']['cohortType'], 'sections')
        self.assertEqual(len(content['table']['columns']), 2)
        self.assertIn('pie', content['table'])
        # @TODO Replace with actuals
        self.assertEqual(content['table']['pie']['K'], 1)
        self.assertEqual(content['table']['pie']['1'], 2)
        self.assertEqual(content['table']['pie']['2'], 3)
        self.assertNotIn('schools', content['table']['rows'][0])
        self.assertNotIn('teachers', content['table']['rows'][0])
        self.assertEqual(content['table']['rows'][0]['classes'], 2)
        self.assertEqual(content['table']['rows'][0]['students'], 6)
        self.assertEqual(content['table']['sortOrder'], 'asc')
        self.assertEqual(content['table']['sortType'], 'alphabetical')

    def test_snapshot_infographic_by_section(
            self):  # , TeacherMock, SectionMock, StudentsMock, OrgMock, TeacherMock2, SectionGet):
        """
        Infographic snapshot, for one section
        """
        view = SnapshotInfographicAPI()
        view.section = Section(id=155528, organizationId=3317034, name="Tuarez's Class")
        content = view.get_data(query_param='sectionId', value=view.section.id)
        self.assertEqual(content['table']['cohort'], "Tuarez's Class")
        self.assertEqual(content['table']['cohortTitle'], "Tuarez's Class")
        self.assertEqual(content['table']['cohortType'], 'students')
        self.assertEqual(len(content['table']['columns']), 5)
        self.assertEqual(len(content['table']['rows'][0]), 5)
        self.assertEqual(content['table']['rows'][0]['time'], 4.333333333333333)
        self.assertEqual(content['table']['rows'][0]['avgSessionsPerWeek'], 0.16666666666666666)
        self.assertEqual(content['table']['rows'][0]['avgSessionsLength'], 0.7222222222222222)
        # @TODO replace with actuals
        self.assertAlmostEqual(content['table']['rows'][0]['phonological'], ((10. + 40. + 30.) / (20. + 50. + 40.)))
        self.assertAlmostEqual(content['table']['rows'][0]['comprehension'], ((80. + 35.) / (100. + 40.)))
        self.assertEqual(content['table']['sortOrder'], 'asc')
        self.assertEqual(content['table']['sortType'], 'alphabetical')

    def test_snapshot_infographic_by_student(self):
        """
        Infographic snapshot, for one student
        """
        view = SnapshotInfographicAPI()
        view.student = Student(id=13, primaryOrgId=3317034, firstName='Brent', lastName='Mitton')
        content = view.get_data(query_param='studentId', value=view.student.id)
        self.assertEqual(content['table']['cohort'], "Brent Mitton")
        self.assertEqual(content['table']['cohortTitle'], "Brent Mitton")
        self.assertEqual(content['table']['cohortType'], 'student')
        self.assertEqual(len(content['table']['columns']), 5)
        self.assertEqual(len(content['table']['rows'][0]), 5)
        self.assertEqual(content['table']['rows'][0]['time'], 0.23333333333333334)
        self.assertEqual(content['table']['rows'][0]['avgSessionsPerWeek'], 0.027777777777777776)
        self.assertEqual(content['table']['rows'][0]['avgSessionsLength'], 0.23333333333333334)
        # @TODO replace with actuals
        self.assertAlmostEqual(content['table']['rows'][0]['phonological'], ((20. + 40. + 30.) / (80. + 55. + 40.)))
        self.assertAlmostEqual(content['table']['rows'][0]['comprehension'], ((90. + 10.) / (100. + 40.)))
        self.assertEqual(content['table']['sortOrder'], 'asc')
        self.assertEqual(content['table']['sortType'], 'alphabetical')
