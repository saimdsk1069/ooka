import datetime
import time
from django.test import mock, TestCase
from digitalplatform.models import Organization, Section, Student
from ookadogsled.elasticsearch_client import es, es_index_name
from gameplay.models import Score
from ..views_skill_performance import BaseSkillDistributionView, BaseSkillGradesScoresView, ComprehensionSkillDistributionView,\
    PhonologicalSkillDistributionView, ComprehensionSkillGradesScoresView, PhonologicalSkillScoresView,\
    PhonologicalProgressView


BASE_TELEMETRY = {
    "dp_id": 3, "timestamp": "2018-03-19 12:12:12 +0100", "timing": "100.1", "session_key": "something", "ip_address": "127.0.0.1"
}


ES_SCORES = [
    # auditory: 2/3 = practicing
    {'dp_id': 10, 'activity_level_level_number': 1, 'skill_type': 'phonological', 'skill_label': 'auditory', 'score': False, 'created': 1521457982},
    {'dp_id': 10, 'activity_level_level_number': 1, 'skill_type': 'phonological', 'skill_label': 'auditory', 'score': True, 'created': 1521457982},
    {'dp_id': 10, 'activity_level_level_number': 1, 'skill_type': 'phonological', 'skill_label': 'auditory', 'score': True, 'created': 1521457982},
    # correspondence 2/4 = learning
    {'dp_id': 10, 'activity_level_level_number': 2, 'skill_type': 'phonological', 'skill_label': 'correspondence', 'score': False, 'created': 1521457982},
    {'dp_id': 10, 'activity_level_level_number': 2, 'skill_type': 'phonological', 'skill_label': 'correspondence', 'score': False, 'created': 1521457982},
    {'dp_id': 10, 'activity_level_level_number': 2, 'skill_type': 'phonological', 'skill_label': 'correspondence', 'score': True, 'created': 1521457982},
    {'dp_id': 10, 'activity_level_level_number': 2, 'skill_type': 'phonological', 'skill_label': 'correspondence', 'score': True, 'created': 1521457982},
    # consonants 4/5 = proficient
    {'dp_id': 10, 'activity_level_level_number': 3, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 10, 'activity_level_level_number': 3, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 10, 'activity_level_level_number': 3, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': False, 'created': 1521457982},
    {'dp_id': 10, 'activity_level_level_number': 3, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 10, 'activity_level_level_number': 3, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    # One other user
    {'dp_id': 11, 'activity_level_level_number': 2, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 11, 'activity_level_level_number': 3, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 11, 'activity_level_level_number': 6, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': False, 'created': 1521457982},
    {'dp_id': 11, 'activity_level_level_number': 7, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 11, 'activity_level_level_number': 7, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982},
    {'dp_id': 11, 'activity_level_level_number': 7, 'skill_type': 'phonological', 'skill_label': 'consonants', 'score': True, 'created': 1521457982}
]

students_list = [Student(id=3), Student(id=4), Student(id=5)]
ANTOICH_UNIFIED_DISTRICT = Organization(id=3317035, name="ANTIOCH UNIFIED SCHOOL DIST")

ANTOICH_MIDDLE_SCHOOL = Organization(id=3317034, name="ANTIOCH MIDDLE SCHOOL",
                                     sections=[Section(id=s) for s in [155528, 155611, 155612]],
                                     students=students_list
                                     )


class BaseSkillsTestCase(TestCase):

    def setUp(self):
        es.indices.put_template(Score.es_score_template_name, Score.es_score_template)
        for score in ES_SCORES:
            es.index(index=es_index_name("score", datetime.datetime.now()), doc_type="default", body=score)
        # Wait for the search index to catch up else bad things happen
        time.sleep(2)

    def tearDown(self):
        es.indices.delete(index='%s*' % es_index_name("score"))
        time.sleep(1)


class SkillDistributionViewTestCase(BaseSkillsTestCase):

    def test_phonological_skills_for_student(self):
        view = BaseSkillDistributionView()
        results = view.skills_averages_for_student(10)
        self.assertEqual(results['alphabet'], 0.0)
        self.assertAlmostEqual(results['auditory'], 2/3, places=2)
        self.assertAlmostEqual(results['consonants'], 4/5, places=2)
        self.assertAlmostEqual(results['correspondence'], 1/2, places=2)

    def test_aggregate_by_phonological_skills(self):
        # Test the results from the ES query
        view = BaseSkillDistributionView()
        results = view.aggregate_skills_performance({'student_ids': [10, 11]})
        self.assertEqual(results['auditory']['learning'], 0)
        self.assertEqual(results['auditory']['practicing'], 1)
        self.assertEqual(results['auditory']['proficient'], 0)
        self.assertEqual(results['consonants']['learning'], 0)
        self.assertEqual(results['consonants']['practicing'], 0)
        self.assertEqual(results['consonants']['proficient'], 2)

    def test_get_phonological_students_skills_data(self):
        # Test the manipulation from of the ES results
        view = BaseSkillDistributionView()
        data = view.get_students_skills_data({'student_ids': [10]})
        self.assertEqual(data['auditory']['default']['learning'], 0)
        self.assertEqual(data['auditory']['default']['practicing'], 1)
        self.assertEqual(data['auditory']['default']['proficient'], 0)

    @mock.patch('reporting.views_time_played.BaseElasticSearchReportView.student_ids')
    def test_phonological_distribution_view_get_data(self, mock_student_ids):
        view = PhonologicalSkillDistributionView()
        view.query_param = 'districtId'
        mock_student_ids.return_value = {'id': 98765, 'name': 'Test parent record', 'student_ids': [10, 100]}
        view.filter_record = Organization(id=98765, name='Test parent object')
        data = view.get_data()
        self.assertEqual(len(data['gradeLabels']), 5)
        self.assertEqual(len(data['labels']), 7)
        self.assertEqual(data["labels"]["vowels"], "Identify Vowels")
        self.assertEqual(data['cohorts'][0]['cohortId'], 98765)
        self.assertEqual(data['cohorts'][0]['cohortType'], 'schoolsGroup')
        self.assertEqual(data['cohorts'][0]['name'], 'Test parent record')
        self.assertEqual(data['cohorts'][0]['phonologicalDistribution']['auditory']['default']['learning'], 0)
        self.assertEqual(data['cohorts'][0]['phonologicalDistribution']['auditory']['default']['practicing'], 1)
        self.assertEqual(data['cohorts'][0]['phonologicalDistribution']['auditory']['default']['proficient'], 0)
        # @TODO Re-enable tests once per-grade filtering is hooked up
        # self.assertEqual(data['cohorts'][0]['no-label']['auditory']['K']['learning'], 0)
        # self.assertEqual(data['cohorts'][0]['no-label']['auditory']['K']['practicing'], 1)
        # self.assertEqual(data['cohorts'][0]['no-label']['auditory']['K']['proficient'], 0)

    @mock.patch('reporting.views_time_played.BaseElasticSearchReportView.student_ids')
    def test_phonological_distribution_view_student(self, mock_student_ids):
        view = PhonologicalSkillDistributionView()
        view.query_param = 'studentId'
        mock_student_ids.return_value = {'id': 155528, 'name': 'Test section', 'student_ids': [10, 11, 12]}
        view.filter_record = Student(id=98765, firstName='Brent', lastName='Mitton')
        view.student = Student(id=10, section=Section(id=155528, students=[Student(id=10)]))
        data = view.get_data()
        self.assertEqual(len(data['labels']), 7)
        self.assertEqual(data['cohorts'][0]['cohortId'], view.student.id)
        self.assertEqual(data['cohorts'][0]['cohortType'], 'student')
        self.assertEqual(data['cohorts'][0]['name'], view.student.name)
        self.assertEqual(data['cohorts'][0]['phonologicalDistribution']['auditory']['learning'], 0)
        self.assertEqual(data['cohorts'][0]['phonologicalDistribution']['auditory']['practicing'], 1)
        self.assertEqual(data['cohorts'][0]['phonologicalDistribution']['auditory']['proficient'], 0)
        self.assertAlmostEqual(data['cohorts'][0]['phonologicalDistribution']['auditory']['position'], 2/3, places=2)
        self.assertAlmostEqual(data['cohorts'][0]['phonologicalDistribution']['consonants']['position'], 4/5, places=2)
        self.assertAlmostEqual(data['cohorts'][0]['phonologicalDistribution']['correspondence']['position'], 1/2, places=2)

    @mock.patch('reporting.views_time_played.BaseElasticSearchReportView.student_ids')
    def test_comprehension_distribution_view_get_data(self, mock_student_ids):
        view = ComprehensionSkillDistributionView()
        view.query_param = 'districtId'
        mock_student_ids.return_value = {'id': 98765, 'name': 'Test parent record', 'student_ids': [10, 100]}
        view.filter_record = Organization(id=98765, name='Test parent object')
        data = view.get_data()
        self.assertEqual(len(data['gradeLabels']), 5)
        self.assertEqual(len(data['labels']), 6)
        self.assertEqual(data["labels"]["concept"], "Concept of Word")
        self.assertEqual(data['cohorts'][0]['comprehensionDistribution']['concept']['default']['learning'], 0)
        self.assertEqual(data['cohorts'][0]['comprehensionDistribution']['concept']['default']['practicing'], 0)


class BaseSkillGradesScoresViewTestCase(BaseSkillsTestCase):

    @mock.patch('reporting.views_time_played.BaseElasticSearchReportView.student_ids_grades_groups')
    def test_district(self, mock_student_ids_grades_groups):
        view = BaseSkillGradesScoresView()
        view.query_param = 'districtId'
        view.skills_type = 'phonological'
        mock_student_ids_grades_groups.return_value = [
            {'grade': 'K', 'name': 'Kinder', 'student_ids': [10, 100]},
            {'grade': '1', 'name': 'Gr 1', 'student_ids': [11, 12]}
        ]
        view.filter_record = Organization(id=98765, name='Test parent object')
        data = view.get_data()
        self.assertEqual(len(data['labels']), 7)
        self.assertEqual(data['cohorts'][0]['cohortId'], 98765)
        self.assertEqual(data['cohorts'][0]['cohortType'], 'schoolsGroup')
        self.assertEqual(data['cohorts'][0]['name'], 'Test parent object')
        self.assertEqual(data['cohorts'][0]['no-label']['auditory']['default'], 33)
        self.assertEqual(data['cohorts'][0]['no-label']['auditory']['K'], 66)
        self.assertEqual(data['cohorts'][0]['no-label']['auditory']['1'], 0)

    @mock.patch('reporting.views_time_played.BaseElasticSearchReportView.student_ids_grades_groups')
    def test_comprehension_district(self, mock_student_ids_grades_groups):
        view = ComprehensionSkillGradesScoresView()
        view.query_param = 'districtId'
        mock_student_ids_grades_groups.return_value = [
            {'grade': 'K', 'name': 'Kinder', 'student_ids': [10, 100]},
            {'grade': '1', 'name': 'Gr 1', 'student_ids': [11, 12]}
        ]
        view.filter_record = Organization(id=98765, name='Test parent object')
        data = view.get_data()
        self.assertEqual(len(data['labels']), 6)
        self.assertEqual(data['cohorts'][0]['cohortId'], 98765)
        self.assertEqual(data['cohorts'][0]['cohortType'], 'schoolsGroup')
        self.assertEqual(data['cohorts'][0]['name'], 'Test parent object')
        self.assertEqual(data['cohorts'][0]['comprehensionScores']['concept']['default'], 0)
        self.assertEqual(data['cohorts'][0]['comprehensionScores']['concept']['K'], 0)
        self.assertEqual(data['cohorts'][0]['comprehensionScores']['concept']['1'], 0)

    @mock.patch('reporting.views_time_played.BaseElasticSearchReportView.student_ids_grades_groups')
    def test_phonological_district(self, mock_student_ids_grades_groups):
        view = PhonologicalSkillScoresView()
        view.query_param = 'districtId'
        mock_student_ids_grades_groups.return_value = [
            {'grade': 'K', 'name': 'Kinder', 'student_ids': [10, 100]},
            {'grade': '1', 'name': 'Gr 1', 'student_ids': [11, 12]}
        ]
        view.filter_record = Organization(id=98765, name='Test parent object')
        data = view.get_data()
        self.assertEqual(len(data['labels']), 7)
        self.assertEqual(data['cohorts'][0]['cohortId'], 98765)
        self.assertEqual(data['cohorts'][0]['cohortType'], 'schoolsGroup')
        self.assertEqual(data['cohorts'][0]['name'], 'Test parent object')
        self.assertEqual(data['cohorts'][0]['phonologicalScores']['correspondence']['default'], 25)
        self.assertEqual(data['cohorts'][0]['phonologicalScores']['correspondence']['K'], 50)
        self.assertEqual(data['cohorts'][0]['phonologicalScores']['correspondence']['1'], 0)

    @mock.patch('reporting.views_time_played.BaseElasticSearchReportView.student_ids_grades_groups')
    def test_phonological_district_empty_state(self, mock_student_ids_grades_groups):
        view = PhonologicalSkillScoresView()
        view.query_param = 'districtId'
        mock_student_ids_grades_groups.return_value = [
            {'grade': 'K', 'name': 'Kinder', 'student_ids': [8810, 7100]},
            {'grade': '1', 'name': 'Gr 1', 'student_ids': [6611, 5512]}
        ]
        view.filter_record = Organization(id=98765, name='Test parent object')
        data = view.get_data()
        self.assertEqual(len(data['labels']), 7)
        self.assertEqual(data['cohorts'][0]['cohortId'], 98765)
        self.assertEqual(data['cohorts'][0]['cohortType'], 'schoolsGroup')
        self.assertEqual(data['cohorts'][0]['name'], 'Test parent object')
        self.assertEqual(data['cohorts'][0]['phonologicalScores']['correspondence']['default'], 0)
        self.assertEqual(data['cohorts'][0]['phonologicalScores']['correspondence']['K'], 0)
        self.assertEqual(data['cohorts'][0]['phonologicalScores']['correspondence']['1'], 0)

    @mock.patch('reporting.views_time_played.BaseElasticSearchReportView.student_ids_grades_groups')
    def test_district_no_data(self, mock_student_ids_grades_groups):
        view = BaseSkillGradesScoresView()
        view.query_param = 'districtId'
        view.skills_type = 'phonological'
        mock_student_ids_grades_groups.return_value = [
            {'grade': 'K', 'name': 'Kinder', 'student_ids': [9999, 9998]},
            {'grade': '1', 'name': 'Gr 1', 'student_ids': [9874, 22436]}
        ]
        view.filter_record = Organization(id=98765, name='Test parent object')
        data = view.get_data()
        self.assertEqual(len(data['labels']), 7)
        self.assertEqual(data['cohorts'][0]['cohortId'], 98765)
        self.assertEqual(data['cohorts'][0]['cohortType'], 'schoolsGroup')
        self.assertEqual(data['cohorts'][0]['name'], 'Test parent object')
        self.assertEqual(data['cohorts'][0]['no-label']['auditory']['default'], 0)
        self.assertEqual(data['cohorts'][0]['no-label']['auditory']['K'], 0)
        self.assertEqual(data['cohorts'][0]['no-label']['auditory']['1'], 0)

        mock_student_ids_grades_groups.return_value = []
        view.filter_record = Organization(id=98765, name='Test parent object')
        data = view.get_data()
        self.assertEqual(len(data['labels']), 7)
        self.assertEqual(data['cohorts'][0]['cohortId'], 98765)
        self.assertEqual(data['cohorts'][0]['cohortType'], 'schoolsGroup')
        self.assertEqual(data['cohorts'][0]['name'], 'Test parent object')
        self.assertEqual(data['cohorts'][0]['no-label']['auditory']['default'], 0)


class PhonologicalProgressViewTestCase(BaseSkillsTestCase):

    @mock.patch('reporting.views_time_played.BaseElasticSearchReportView.student_ids')
    def test_no_data(self, mock_student_ids):
        view = PhonologicalProgressView()
        view.query_param = 'districtId'
        view.skills_type = 'phonological'
        mock_student_ids.return_value = {'id': '123', 'name': 'Test Parent Obk', 'student_ids': [9999, 9998]}
        view.filter_record = Organization(id=98765, name='Test parent object')

        aggregate = view.get_aggregate(mock_student_ids.return_value)
        self.assertEqual(aggregate, {})

        data = view.get_data()
        self.assertEqual(len(data['labels']), 7)
        self.assertNotIn('overall', data['metrics'])
        self.assertEqual(data['metrics']['auditory'], 0)
        # Not needed?
        # self.assertEqual(data['cohorts'][0]['cohortId'], 98765)
        self.assertEqual(data['cohorts'][0]['cohortType'], 'schoolsGroup')
        # self.assertEqual(data['cohorts'][0]['name'], 'Test parent object')
        self.assertEqual(data['cohorts'][0]['phonologicalProgress']['auditory']['default'], [])
        self.assertEqual(data['cohorts'][0]['phonologicalProgress']['consonants']['default'], [])

    @mock.patch('reporting.views_time_played.BaseElasticSearchReportView.student_ids')
    def test_district_data(self, mock_student_ids):
        view = PhonologicalProgressView()
        view.query_param = 'districtId'
        view.skills_type = 'phonological'
        mock_student_ids.return_value = {'id': '123', 'name': 'Test Parent Obk', 'student_ids': [10, 11, 12]}
        view.filter_record = Organization(id=98765, name='Test parent object')

        aggregate = view.get_aggregate(mock_student_ids.return_value)
        self.assertEqual(aggregate['auditory'][1]['average'], 2 / 3)
        self.assertEqual(aggregate['auditory'][1]['students_ct'], 1)
        self.assertEqual(aggregate['consonants'][6]['average'], 0)
        self.assertEqual(aggregate['consonants'][6]['students_ct'], 1)
        self.assertEqual(aggregate['consonants'][3]['students_ct'], 2)

        data = view.get_data()
        self.assertEqual(len(data['labels']), 7)
        self.assertEqual(data['metrics']['auditory'], round(2 / 3 * 100))
        # Not needed?
        # self.assertEqual(data['cohorts'][0]['cohortId'], 98765)
        # self.assertEqual(data['cohorts'][0]['cohortType'], 'schoolsGroup')
        # self.assertEqual(data['cohorts'][0]['name'], 'Test parent object')
        self.assertEqual(data['cohorts'][0]['phonologicalProgress']['auditory']['default'][0]['level'], 1)
        self.assertEqual(data['cohorts'][0]['phonologicalProgress']['auditory']['default'][0]['value'], round(2 / 3 * 100))
        self.assertEqual(data['cohorts'][0]['phonologicalProgress']['auditory']['default'][0]['callout']['completedBy'], 1)
        self.assertEqual(data['cohorts'][0]['phonologicalProgress']['consonants']['default'][0]['callout']['completedBy'], 2)
        self.assertEqual(data['cohorts'][0]['phonologicalProgress']['consonants']['default'][0]['value'], round(5 / 6 * 100))
        # self.assertEqual(data['cohorts'][0]['phonologicalProgress']['auditory']['default'][0]['callout']['skillsPracticed'], 'ee, aw')
