from django.test import mock
from digitalplatform.models import Organization
from ..views_skill_performance import ComprehensionTableView, PhonologicalTableView
from ..views_overview import OverviewScoreTimeTableNavView
from .test_views import BaseScoreTelemetryTestCase


class TableNavTestCase(BaseScoreTelemetryTestCase):

    @mock.patch('reporting.views_time_played.BaseTableNavElasticSearchReportView.student_ids_groups')
    def test_overview_table_nav_get_data_empty_state(self, mock_student_ids_groups):
        """
        O1 - Comprehension table nav: average time, average score - empty state
        """
        view = OverviewScoreTimeTableNavView()
        view.query_param = 'districtId'
        mock_student_ids_groups.return_value = [
            {'id': 99, 'name': 'Test parent object', 'student_ids': [50, 512]},
            {'id': 21, 'name': 'Test child object 1', 'student_ids': [610, 711]}
        ]
        view.filter_record = Organization(id=99, name='Something parent object')
        data = view.get_data()
        self.assertEqual(len(data['table']['rows']), 2)
        self.assertEqual(data['table']['rows'][0]['id'], 99)
        self.assertEqual(data['table']['rows'][0]['name'], 'Test parent object')
        self.assertEqual(data['table']['rows'][0]['score'], 0)
        self.assertEqual(data['table']['rows'][0]['time'], 0)
        self.assertEqual(data['table']['rows'][1]['score'], 0)
        self.assertEqual(data['table']['rows'][1]['time'], 0)

    @mock.patch('reporting.views_time_played.BaseTableNavElasticSearchReportView.student_ids_groups')
    def test_comprehension_table_nav_get_data(self, mock_student_ids_groups):
        """
        C1 - Comprehension table nav: book level, average score
        """
        view = ComprehensionTableView()
        view.query_param = 'districtId'
        mock_student_ids_groups.return_value = [
            {'id': 99, 'name': 'Test parent object', 'student_ids': [10, 11, 12]},
            {'id': 21, 'name': 'Test child object 1', 'student_ids': [10, 11]},
            {'id': 22, 'name': 'Test child object 2', 'student_ids': [12, 999]}
        ]
        view.filter_record = Organization(id=99, name='Something parent object')
        data = view.get_data()
        self.assertEqual(data['table']['tableTitle'], 'Schools')
        self.assertEqual(data['table']['metricTitle'], 'Overview')
        self.assertEqual(data['table']['cohortTitle'], 'Something parent object')
        self.assertEqual(data['table']['cohortType'], 'schoolsGroup')
        self.assertEqual(data['table']['columns'][0]['name'], 'School')
        self.assertEqual(len(data['table']['rows']), 3)
        self.assertEqual(data['table']['rows'][0]['id'], 99)
        self.assertEqual(data['table']['rows'][0]['name'], 'Test parent object')
        self.assertEqual(data['table']['rows'][0]['score'], 4 / 7)
        self.assertEqual(data['table']['rows'][0]['book'], '14/85')
        self.assertEqual(data['table']['rows'][1]['score'], 2 / 3)
        self.assertEqual(data['table']['rows'][1]['book'], '8/85')

    @mock.patch('reporting.views_time_played.BaseTableNavElasticSearchReportView.student_ids_groups')
    def test_phonological_table_nav_get_data(self, mock_student_ids_groups):
        """
        C1 - Phonological table nav: game level, average score
        """
        view = PhonologicalTableView()
        view.query_param = 'districtId'
        mock_student_ids_groups.return_value = [
            {'id': 99, 'name': 'Test parent object', 'student_ids': [10, 11, 12]},
            {'id': 21, 'name': 'Test child object 1', 'student_ids': [10, 11]},
            {'id': 22, 'name': 'Test child object 2', 'student_ids': [12, 999]}
        ]
        view.filter_record = Organization(id=99, name='Something parent object')
        data = view.get_data()
        self.assertEqual(data['table']['tableTitle'], 'Schools')
        self.assertEqual(data['table']['metricTitle'], 'Overview')
        self.assertEqual(data['table']['cohortTitle'], 'Something parent object')
        self.assertEqual(data['table']['cohortType'], 'schoolsGroup')
        self.assertEqual(data['table']['columns'][0]['name'], 'School')
        self.assertEqual(len(data['table']['rows']), 3)
        self.assertEqual(data['table']['rows'][0]['id'], 99)
        self.assertEqual(data['table']['rows'][0]['name'], 'Test parent object')
        self.assertEqual(data['table']['rows'][0]['score'], 5 / 8)
        self.assertEqual(data['table']['rows'][0]['level'], '6/24')
        self.assertEqual(data['table']['rows'][1]['score'], 2 / 3)
        self.assertEqual(data['table']['rows'][1]['level'], '4/24')
        self.assertEqual(data['table']['rows'][2]['level'], '10/24')

    @mock.patch('reporting.views_time_played.BaseTableNavElasticSearchReportView.student_ids_groups')
    def test_comprehension_table_nav_get_data(self, mock_student_ids_groups):
        """
        C1 - Comprehension table nav: book level, average score
        """
        view = ComprehensionTableView()
        view.query_param = 'districtId'
        mock_student_ids_groups.return_value = [
            {'id': 99, 'name': 'Test parent object', 'student_ids': [60, 61, 62]},
            {'id': 21, 'name': 'Test child object 1', 'student_ids': [44, 55]}
        ]
        view.filter_record = Organization(id=99, name='Something parent object')
        data = view.get_data()
        self.assertEqual(data['table']['tableTitle'], 'Schools')
        self.assertEqual(data['table']['metricTitle'], 'Overview')
        self.assertEqual(data['table']['cohortTitle'], 'Something parent object')
        self.assertEqual(data['table']['cohortType'], 'schoolsGroup')
        self.assertEqual(data['table']['columns'][0]['name'], 'School')
        self.assertEqual(len(data['table']['rows']), 2)
        self.assertEqual(data['table']['rows'][0]['id'], 99)
        self.assertEqual(data['table']['rows'][0]['name'], 'Test parent object')
        self.assertEqual(data['table']['rows'][0]['score'], 0)
        self.assertEqual(data['table']['rows'][0]['book'], '0/85')
        self.assertEqual(data['table']['rows'][1]['score'], 0)
        self.assertEqual(data['table']['rows'][1]['book'], '0/85')

    @mock.patch('reporting.views_time_played.BaseTableNavElasticSearchReportView.student_ids_groups')
    def test_phonological_table_nav_get_data_empty_state(self, mock_student_ids_groups):
        """
        C1 - Phonological table nav: empty state tests
        """
        view = PhonologicalTableView()
        view.query_param = 'districtId'
        mock_student_ids_groups.return_value = [
            {'id': 99, 'name': 'Test parent object', 'student_ids': [50, 51, 52]},
            {'id': 21, 'name': 'Test child object 1', 'student_ids': [50, 51]}
        ]
        view.filter_record = Organization(id=99, name='Something parent object')
        data = view.get_data()
        self.assertEqual(data['table']['tableTitle'], 'Schools')
        self.assertEqual(data['table']['metricTitle'], 'Overview')
        self.assertEqual(data['table']['cohortTitle'], 'Something parent object')
        self.assertEqual(data['table']['cohortType'], 'schoolsGroup')
        self.assertEqual(data['table']['columns'][0]['name'], 'School')
        self.assertEqual(len(data['table']['rows']), 2)
        self.assertEqual(data['table']['rows'][0]['id'], 99)
        self.assertEqual(data['table']['rows'][0]['name'], 'Test parent object')
        self.assertEqual(data['table']['rows'][0]['score'], 0)
        self.assertEqual(data['table']['rows'][0]['level'], '0/24')
        self.assertEqual(data['table']['rows'][1]['score'], 0)
        self.assertEqual(data['table']['rows'][1]['level'], '0/24')
