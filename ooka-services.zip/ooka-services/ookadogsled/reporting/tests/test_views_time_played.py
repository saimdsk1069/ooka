import json
from django.shortcuts import reverse
from django.test import mock
from digitalplatform.models import Organization, Teacher
from .test_views import BaseScoreTelemetryTestCase, TEACHER_JWT
from ..views_time_played import TimePlayedTableNavView, TimePlayedByLocationByPeriodView, TimePlayedByPeriodByGradeView


class TimePlayedAPITEstCase(BaseScoreTelemetryTestCase):

    # Stress test for querying massive amounts of data - will insert a billion records if you let it run!
    # @mock.patch('reporting.views_time_played.ElasticSearchReportView.student_ids_groups')
    # def test_mass_insert(self, mock_student_ids_groups):
    #     import datetime
    #     import time
    #     from ookadogsled.elasticsearch_client import es, es_index_name
    #     print("Starting to compile these events")
    #     all_events = []
    #     base_event = {
    #         '_index': es_index_name("score", datetime.datetime.now()),
    #         '_type': 'default',
    #         '_source': {}
    #     }
    #     for k in range(0, 50000):
    #         # print("Inserting T for user %d" % k)
    #         all_events.extend([
    #             {**base_event, **{'_source': {'session_key': 'session-%d-1' % k, 'dp_id': k, 'score': True, 'created': 1521458000}}},
    #             {**base_event, **{'_source': {'session_key': 'session-%d-1' % k, 'dp_id': k, 'score': True, 'created': 1521458010}}},
    #             {**base_event, **{'_source': {'session_key': 'session-%d-1' % k, 'dp_id': k, 'score': False, 'created': 1521458020}}},
    #             {**base_event, **{'_source': {'session_key': 'session-%d-1' % k, 'dp_id': k, 'score': False, 'created': 1521458030}}},
    #             {**base_event, **{'_source': {'session_key': 'session-%d-2' % k, 'dp_id': k, 'score': True, 'created': 1521458040}}},
    #             {**base_event, **{'_source': {'session_key': 'session-%d-2' % k, 'dp_id': k, 'score': False, 'created': 1521458050}}},
    #         ])
    #
    #     print("Starting insert process")
    #     start_time = time.time()
    #     for k in range(0, 3332):
    #         bulk(es, all_events)
    #         print("More", k)
    #     end_time = time.time()
    #     total_time = end_time - start_time
    #     print("50k x 6 took %d seconds" % total_time)
    #
    #     time.sleep(10)
    #     view = TimePlayedTableNavView()
    #     view.query_param = 'districtId'
    #     mock_student_ids_groups.return_value = [
    #         {'id': 99, 'name': 'All 10M students', 'student_ids': list(range(0, 50000))},
    #         {'id': 21, 'name': 'Test child object 1', 'student_ids': list(range(0, 10000))},
    #         {'id': 22, 'name': 'Test child object 2', 'student_ids': list(range(10000, 20000))},
    #         {'id': 23, 'name': 'Test child object 2', 'student_ids': list(range(20000, 30000))},
    #         {'id': 24, 'name': 'Test child object 2', 'student_ids': list(range(30000, 40000))},
    #         {'id': 25, 'name': 'Test child object 2', 'student_ids': list(range(40000, 50000))},
    #     ]
    #     view.filter_record = Organization(
    #     start_time = time.time()
    #     data = view.get_data()
    #     end_time = time.time()
    #     total_time = end_time - start_time
    #     print("Pulling the report for effectively 50k users in a district of 5 schools of 10k each took", total_time, "seconds")
    #     # self.assertEqual(data['table']['rows'][0]['avgTimePerStudent'], 40)
    #     self.assertEqual(data['table']['rows'][0]['time'], 50000 * 40)
    #     self.assertEqual(data['table']['rows'][1]['avgTimePerStudent'], 40)
    #     self.assertEqual(data['table']['rows'][1]['time'], 10000 * 40)

    @mock.patch('reporting.views_time_played.BaseElasticSearchReportView.student_ids_grades_groups')
    def test_time_played_by_period_by_grade_view(self, mock_student_ids_groups):
        """
        Usage by grade detail table, for one district
        """
        view = TimePlayedByPeriodByGradeView()
        view.query_param = 'districtId'
        mock_student_ids_groups.return_value = [
            {'grade': 'K', 'name': 'Kindergarten', 'student_ids': [10]},
            {'grade': '1', 'name': 'Grade 1', 'student_ids': [11, 12]}
        ]
        view.filter_record = Organization(id=99, name='Test parent object')
        data = view.get_data()
        self.assertEqual(len(data['SYTDLabels']), 10)
        self.assertEqual(len(data['last7DaysLabels']), 7)
        self.assertEqual(len(data['filters']), 2)
        self.assertEqual(data['filters'][0]['name'], 'Last 7 Days')
        self.assertEqual(data['cohorts'][0]['timePlayed']['SYTD']['Apr'], {})
        self.assertEqual(data['cohorts'][0]['timePlayed']['SYTD']['Mar'], {'First Grade': 11, 'Kindergarten': 0})
        self.assertEqual(data['cohorts'][0]['timePlayed']['last7days']['03-18-2018'], {'First Grade': 0, 'Kindergarten': 0})
        self.assertEqual(data['cohorts'][0]['timePlayed']['last7days']['03-19-2018'], {'First Grade': 11, 'Kindergarten': 0})

    @mock.patch('reporting.views_time_played.BaseTableNavElasticSearchReportView.student_ids_groups')
    def test_time_played_table_nav_view_get_data(self, mock_student_ids_groups):
        """
        T1 - Table nav time played, for one district, group by schools
        """
        view = TimePlayedTableNavView()
        view.query_param = 'districtId'
        mock_student_ids_groups.return_value = [
            {'id': 99, 'name': 'Test parent object', 'student_ids': [10, 11, 12]},
            {'id': 21, 'name': 'Test child object 1', 'student_ids': [10, 11]},
            {'id': 22, 'name': 'Test child object 2', 'student_ids': [12, 999]}
        ]
        view.filter_record = Organization(id=99, name='Test parent object')
        data = view.get_data()
        self.assertEqual(data['table']['cohortTitle'], 'Test parent object')
        self.assertEqual(data['table']['cohortType'], 'schoolsGroup')
        self.assertEqual(data['table']['columns'][0]['name'], 'School')
        self.assertEqual(len(data['table']['rows']), 3)
        self.assertEqual(data['table']['rows'][0]['id'], 99)
        self.assertEqual(data['table']['rows'][0]['name'], 'Test parent object')
        self.assertEqual(data['table']['rows'][0]['avgTimePerStudent'], round(650 / 3 / 60))
        self.assertEqual(data['table']['rows'][0]['time'], round(650 / 60))
        self.assertEqual(data['table']['rows'][1]['id'], 21)
        self.assertEqual(data['table']['rows'][1]['name'], 'Test child object 1')
        self.assertEqual(data['table']['rows'][1]['avgTimePerStudent'], round(100 / 2 / 60))
        self.assertEqual(data['table']['rows'][1]['time'], round(100 / 60))
        # Only one distinct student would have been found
        self.assertEqual(data['table']['rows'][2]['avgTimePerStudent'], round(550 / 60))
        self.assertEqual(data['table']['rows'][2]['time'], round(550 / 60))

    @mock.patch('reporting.views_time_played.BaseTableNavElasticSearchReportView.student_ids_groups')
    def test_time_played_table_nav_view_get_data_teacher(self, mock_student_ids_groups):
        """
        T1 - Table nav time played, for one district, group by schools
        """
        view = TimePlayedTableNavView()
        view.query_param = 'teacherId'
        mock_student_ids_groups.return_value = [
            {'id': 99, 'name': 'Test parent object', 'student_ids': [10, 11, 12]},
            {'id': 21, 'name': 'Test child object 1', 'student_ids': [10, 11]},
            {'id': 22, 'name': 'Test child object 2', 'student_ids': [12, 999]}
        ]
        view.filter_record = Organization(id=99, name='Test parent object')
        data = view.get_data()
        self.assertEqual(data['table']['cohortTitle'], 'Test parent object')
        self.assertEqual(data['table']['cohortType'], 'students')
        self.assertEqual(data['table']['columns'][0]['name'], 'Section')
        self.assertEqual(len(data['table']['rows']), 3)
        self.assertEqual(data['table']['rows'][0]['id'], 99)
        self.assertEqual(data['table']['rows'][0]['name'], 'Test parent object')
        self.assertEqual(data['table']['rows'][0]['avgTimePerStudent'], round(650 / 3 / 60))
        self.assertEqual(data['table']['rows'][0]['time'], round(650 / 60))
        self.assertEqual(data['table']['rows'][1]['id'], 21)
        self.assertEqual(data['table']['rows'][1]['name'], 'Test child object 1')
        self.assertEqual(data['table']['rows'][1]['avgTimePerStudent'], round(100 / 2 / 60))
        self.assertEqual(data['table']['rows'][1]['time'], round(100 / 60))
        # Only one distinct student would have been found
        self.assertEqual(data['table']['rows'][2]['avgTimePerStudent'], round(550 / 60))
        self.assertEqual(data['table']['rows'][2]['time'], round(550 / 60))

    @mock.patch('reporting.views.Teacher.objects.get', mock.Mock(return_value=Teacher(id=3317035, firstName='First', lastName='Last')))
    @mock.patch('reporting.views.Organization.objects.get', mock.Mock(return_value=Organization(id=3317034)))
    @mock.patch('reporting.views.Section.objects.filter_by_staff', mock.Mock(return_value=[]))
    def test_time_played_table_nav_results(self):
        # Test the empty state of the report
        self.client.defaults['HTTP_AUTHORIZATION'] = "Bearer %s" % TEACHER_JWT
        response = self.client.get("%s?teacherId=%d" % (reverse('web_bffs:reporting:time-played-table-nav'), 3349305))
        self.assertEqual(response.status_code, 200)
        response_data = json.loads(response.content)
        self.assertEqual(response_data['table']['rows'][0]['id'], 3317035)
        self.assertEqual(response_data['table']['rows'][0]['name'], 'First Last')
        self.assertEqual(response_data['table']['rows'][0]['time'], 0.0)
        self.assertEqual(response_data['table']['rows'][0]['avgTimePerStudent'], 0)

    @mock.patch('reporting.views_time_played.BaseElasticSearchReportView.student_ids')
    def test_time_played_by_location_by_period_get_data(self, mock_student_ids):
        """
        T2 - Time played by month by location
        """
        view = TimePlayedByLocationByPeriodView()
        view.query_param = 'districtId'
        mock_student_ids.return_value = {'id': 3317035, 'name': 'Test parent object', 'student_ids': [10, 11, 12]}
        view.filter_record = Organization(id=99, name='Test parent object')
        data = view.get_data()
        self.assertEqual(data['cohortTitle'], 'Test parent object')
        self.assertEqual(data['cohortType'], 'schoolsGroup')
        self.assertEqual(len(data['SYTDLabels']), 10)
        self.assertEqual(len(data['last7DaysLabels']), 7)
        self.assertEqual(len(data['filters']), 2)
        self.assertEqual(data['cohorts'][0]['cohortId'], 3317035)
        self.assertEqual(data['cohorts'][0]['cohortType'], 'schoolsGroup')
        self.assertEqual(data['cohorts'][0]['name'], 'Test parent object')
        self.assertEqual(data['cohorts'][0]['timePlayed']['SYTD']['Jan']['out'], 0)
        self.assertEqual(data['cohorts'][0]['timePlayed']['SYTD']['Feb']['in'], 0)
        self.assertAlmostEqual(data['cohorts'][0]['timePlayed']['SYTD']['Mar']['in'], 150 / 60, places=2)
        self.assertAlmostEqual(data['cohorts'][0]['timePlayed']['SYTD']['Mar']['out'], 500 / 60, places=2)
        self.assertAlmostEqual(data['cohorts'][0]['timePlayed']['last7days']['03-19-2018']['in'], round(2.5), places=2)
        self.assertAlmostEqual(data['cohorts'][0]['timePlayed']['last7days']['03-19-2018']['out'], round(8.33), places=2)
