from django.conf.urls import url
from django.views.generic import RedirectView
from . import views
from . import views_overview
from . import views_skill_performance
from . import views_time_played
from . import views_overall_performance


urlpatterns = [
    # Overview section
    # O1 - Left table nav
    url(r'^v1/overview/table-nav$', views_overview.OverviewScoreTimeTableNavView.as_view(), name="overview-table-nav"),
    # O2 - Infographic
    url(r'^v1/overview/infographic$', views.SnapshotInfographicAPI.as_view(), name="overview-infographic"),
    # O3 - Usage by Grade Level
    url(r'^v1/overview/grade-table$', views.TimePlayedGradeUsageTableAPI.as_view(), name="overview-grade-table"),

    # Time Played section
    # T1 - Left table nav
    url(r'^v1/time-played/table-nav$', views_time_played.TimePlayedTableNavView.as_view(), name="time-played-table-nav"),
    # T2 - Total Time Spent - in school vs at home, by either month or last 7 days
    url(r'^v1/time-played/period-location$', views_time_played.TimePlayedByLocationByPeriodView.as_view(), name="time-played-period-location"),
    # T3 - Total Time Spent - by grade by period
    url(r'^v1/time-played/period-grade$', views_time_played.TimePlayedByPeriodByGradeView.as_view(), name="time-played-period-grade"),

    # Overall 1
    url(r'^v1/overall-performance$', views_overall_performance.OverallPerformanceAPI.as_view(), name="overall-performance"),

    # Phonological
    # P1 - Left table nav
    url(r'^v1/phonological/table-nav$', views_skill_performance.PhonologicalTableView.as_view(), name="phonological-table-nav"),
    # P2 - Phonological scores
    url(r'^v1/phonological/scores$', views_skill_performance.PhonologicalSkillScoresView.as_view(), name="phonological-scores"),
    # P3 - Phonological Distribution view
    url(r'^v1/phonological/distribution$', views_skill_performance.PhonologicalSkillDistributionView.as_view(), name="phonological-distribution"),
    # P4
    url(r'^v1/phonological/progress$', views_skill_performance.PhonologicalProgressView.as_view(), name="phonological-progress"),

    # Comprehension
    # C1 - Left table nav
    url(r'^v1/comprehension/table-nav$', views_skill_performance.ComprehensionTableView.as_view(), name="comprehension-table-nav"),
    # C2 - Comprehension scores
    url(r'^v1/comprehension/scores$', views_skill_performance.ComprehensionSkillGradesScoresView.as_view(), name="comprehension-scores"),
    # C3 - Comprehension Distribution view
    url(r'^v1/comprehension/distribution$', views_skill_performance.ComprehensionSkillDistributionView.as_view(), name="comprehension-distribution"),
    # C4
    # url(r'^v1/comprehension/progress$', views_skill_performance.ComprehensionProgressView.as_view(), name="comprehension-progress"),

    # Report Nav
    url(r'^v1/metrics$', views.ReportNavMetricsAPI.as_view(), name="report-nav-metrics"),


    # Report Nav
    url(r'^v1/report-nav-metrics$', views.ReportNavMetricsAPI.as_view(), name="report-nav-metrics"),


    # Supporting old URLs
    url(r'^v1/overview/grade-table/usage$', RedirectView.as_view(pattern_name='web_bffs:reporting:overview-grade-table', permanent=True)),
    url(r'^v1/overview/performance$', RedirectView.as_view(pattern_name='web_bffs:reporting:overall-performance', permanent=True)),
    url(r'^v1/overview/time-played$', RedirectView.as_view(pattern_name='web_bffs:reporting:time-played-period-location', permanent=True)),
]
