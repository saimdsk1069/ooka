import copy
import datetime
import time
from collections import defaultdict
from django.core.exceptions import PermissionDenied
from django.http import HttpResponseBadRequest, JsonResponse
from django.utils.decorators import method_decorator
from django.views import View
from digitalplatform.models import BaseDPModel, Organization, Section, Student, Teacher
from gameplay.models import UserActivityLevelProgress, UserBookProgress, GameUser, AppliedIntervention
from ookadogsled.elasticsearch_client import es, es_index_name
from sdm_authentication.utils import require_valid_jwt
from .report_constants import *


class ReportView(View):
    """
    Superclass for all JSON report views.
    """
    http_method_names = ['get', 'options']
    required_params = ['districtId', 'schoolId', 'teacherId', 'sectionId', 'studentId']
    query_type_mapping = {
        "student": "dp_id", "section": "section_id", "school": "school_id", "district": "district_id", "teacher": "teacher_id"
    }
    dp_id = None
    grade_name_mapping = {
        'k': "Kindergarten",
        '1': "First Grade",
        '2': "Second Grade",
        '3': "Third Grade",
    }
    cohort_type_mapping = {
        "districtId": "schoolsGroup",
        "schoolId": "sections",
        "teacherId": "students",
        "sectionId": "students",
        "studentId": "student"
    }
    cohort_type_agg_mapping = {
        "districts": "schoolsGroup",
        "schools": "sections",
        "sections": "students",
        "students": "student",
        "student":"student",
        "gameusers": "student"
    }
    table_header_label_map = {
        "districtId": "School",
        "schoolId": "Section",
        "teacherId": "Section",
        "sectionId": "Student"
    }
    ordered_skills = {
        "phonological": [{
                'prop': 'auditory',
                'name': 'Auditory Recognition',
                'set': 'phonologicalSkills',
                'order': 1
            },
            {
                'prop': 'alphabet',
                'name': 'Alphabet Knowledge',
                'set': 'phonologicalSkills',
                'order': 2
            },
            {
                'prop': 'correspondence',
                'name': 'Letter Sound Corr.',
                'set': 'phonologicalSkills',
                'order': 3
            },
            {
                'prop': 'consonants',
                'name': 'Identify Consonants',
                'set': 'phonologicalSkills',
                'order': 4
            },
            {
                'prop': 'vowels',
                'name': 'Identify Vowels',
                'set': 'phonologicalSkills',
                'order': 5
            },
            {
                'prop': 'syllables',
                'name': 'Identify Syllables',
                'set': 'phonologicalSkills',
                'order': 6
            },
            {
                'prop': 'blending',
                'name': 'Blending',
                'set': 'phonologicalSkills',
                'order': 7
            }],
        "comprehension": [
            {
                'prop': 'concept',
                'name': 'Concept of Word',
                'set': 'comprehensionSkills',
                'order': 1
            },
            {
                'prop': 'sight',
                'name': 'Sight Vocabulary',
                'set': 'comprehensionSkills',
                'order': 2
            },
            {
                'prop': 'recallPictureText',
                'name': 'Recall: Pictures & Text',
                'set': 'comprehensionSkills',
                'order': 3
            },
            {
                'prop': 'text',
                'name': 'Recall: Text Only',
                'set': 'comprehensionSkills',
                'order': 4
            },
            {
                'prop': 'sequencingPictures',
                'name': 'Sequencing: Pictures & Text',
                'set': 'comprehensionSkills',
                'order': 5
            },
            {
                'prop': 'sequencingText',
                'name': 'Sequencing: Text Only',
                'set': 'comprehensionSkills',
                'order': 6
            }
        ]
    }
    district = None
    school = None
    teacher = None
    section = None
    student = None

    filter_type = None
    filter_record = None

    def dispatch(self, request, *args, **kwargs):
        # check to make sure that one of the required query parameters has been passed
        if not self._valid_query_params(request.GET):
            return HttpResponseBadRequest("Invalid query parameters")

        return super(ReportView, self).dispatch(request, *args, **kwargs)

    @method_decorator(require_valid_jwt)
    def get(self, request, jwt_payload, game_user_id):
        start_time = time.time()
        # now we want to figure out what we're querying on–
        query_args = self.get_query_parameter(request.GET)
        self.query_param = query_args[0]
        value = query_args[1]
        self.dp_id = jwt_payload['dpId']

        try:
            value = int(value)
        except ValueError:
            return JsonResponse({"error": "Bad request."}, status=400)

        try:
            if self.query_param == "districtId":
                # if we're querying on districtId we want to return information about the district and information
                # about all of the schools in that district
                self.get_district_data(value, jwt_payload)
            elif self.query_param == "schoolId":
                # if we're querying by schoolId we want to return information about the school and all the sections
                # in that school
                self.get_school_data(value, jwt_payload)
            elif self.query_param == "teacherId":
                self.get_teacher_data(value, jwt_payload)
            elif self.query_param == "sectionId":
                # if we're querying by section we want to return information about the section and all the students
                # in that section
                self.get_section_data(value, jwt_payload)
            elif self.query_param == "studentId":
                # if we're querying on a studentId, we just want to return information about a single student
                self.get_student_data(value, jwt_payload)
        except BaseDPModel.DoesNotExist:
            return JsonResponse({"error": "Record not found."}, status=404)
        except PermissionDenied:
            # any of the get_*_data methods will raise a permission error if it is determined that the user authed
            # by the jwt doesnt have appropriate access to what was requested
            return JsonResponse({"error": "Access denied."}, status=403)

        # query according to the view
        data = self.get_data()
        end_time = time.time()
        data['responseTime'] = end_time - start_time
        return JsonResponse(data)

    def get_student_data(self, requested_id, jwt):
        """
        Given a studentId this method will set a student attribute on the object if the user has the appropriate access.
        :param requested_id:  The ID of the student.
        :param jwt: The JWT containing auth information.
        """
        # Make an API call to learn more about the student
        self.student = Student.objects.get(requested_id)
        self.filter_record = self.student
        self.filter_type = 'student'

        if jwt.get('dpRole') == 'districtAdmin':
            # if we are district admin we need to make sure that the requested student belongs to a school they can access
            allowed_schools = Organization.objects.filter_by_staff_and_parent(jwt.get('dpId'), jwt.get('districtId'))
            for school in allowed_schools:
                if self.student.primaryOrgId == school.id:
                    return

        elif jwt.get('dpRole') == 'schoolAdmin':
            if self.student.primaryOrgId == jwt.get('schoolId'):
                return

        elif jwt.get('dpRole') == 'teacher':
            # get a list of all of the students this teacher can access
            teacher = Teacher.objects.get(jwt.get('dpId'))
            if self.student.id in teacher.students_by_id:
                return

        elif jwt.get('dpRole') == 'student':
            if self.student.id == jwt.get('dpId'):
                return

        raise PermissionDenied

    def get_teacher_data(self, requested_id, jwt):
        """
        Given a teacher id this method sets a teacher attribute on the object if the user has appropriate access
        :param requested_id: The ID of the teacher
        :param jwt: The JWT containing auth information.
        """
        # first we'll get a little bit of extra information about the section
        self.teacher = Teacher.objects.get(staff_id=requested_id)
        self.filter_record = self.teacher
        self.filter_type = 'teacher'

        if jwt.get('dpRole') in ['districtAdmin']:
            allowed_schools = Organization.objects.filter_by_staff_and_parent(jwt.get('dpId'), jwt.get('districtId'))
            for school in allowed_schools:
                if self.teacher.id in school.teachers_by_id:
                    return

        elif jwt.get('dpRole') == 'schoolAdmin':
            # @TODO Verify that the Teacher is within the same school - verify this with test
            if self.teacher.organizationId == jwt.get('schoolId'):
                return

        elif jwt.get('dpRole') == 'teacher':
            if jwt.get('dpId') == requested_id:
                return

        raise PermissionDenied

    def get_section_data(self, requested_id, jwt):
        """
        Given a section id this method sets a section attribute on the object for the requested section
        :param requested_id: The ID of the section
        :param jwt: The JWT containing auth information.
        """
        self.section = Section.objects.get(requested_id)
        self.filter_record = self.section
        self.filter_type = 'section'

        if jwt.get('dpRole') == 'districtAdmin':
            # if we are a district admin and we're trying to get a particular section we need to make sure that the
            # section is in a school that they have access to
            schools = Organization.objects.filter_by_staff_and_parent(jwt.get('dpId'), jwt.get('districtId'))
            # now check that the school that the section belongs to is in the districts list of schools
            for school in schools:
                if self.section.organizationId == school.id:
                    return

        elif jwt.get('dpRole') == 'schoolAdmin':
            if self.section.organizationId == jwt.get('schoolId'):
                return

        elif jwt.get('dpRole') == 'teacher':
            # first we want to get a list of all of the sections that the current teacher would have access to
            teacher = Teacher.objects.get(jwt.get('dpId'))
            if requested_id in teacher.sections_by_id:
                return

        raise PermissionDenied

    def get_school_data(self, requested_id, jwt):
        """
        Given a school id this method sets a school attribute on the object if the user has appropriate access
        :param requested_id: The ID of the school
        :param jwt: The JWT containing auth information.
        """
        if jwt.get('dpRole') == 'districtAdmin':
            # we first need to get a list of schools that this districtAdmin is allowed, fetch as list of tuples
            self.district = Organization.objects.get(org_id=jwt.get('districtId'))
            for school in self.district.get_child_organizations(staff_id=jwt.get('dpId')):
                if school.id == requested_id:
                    self.school = school
                    self.filter_record = school
                    self.filter_type = 'school'
                    return

        elif jwt.get('dpRole') == 'schoolAdmin' and jwt.get('schoolId') == requested_id:
            # if they're logged in as a schoolAdmin, then the schoolId should be in the jwt. So we need to fetch
            # some more information about the school and then get the section list
            self.school = Organization.objects.get(org_id=requested_id)
            self.filter_record = self.school
            self.filter_type = 'school'
            return

        raise PermissionDenied

    def get_district_data(self, requested_id, jwt):
        """
        Given a districtId this method sets a district attribute on the object if the user has appropriate access
        and also sets the allowed_schools based on dpId
        :param requested_id: The ID of the district
        :param jwt: The JWT containing auth information.
        """
        if jwt.get('dpRole') == 'districtAdmin' and jwt.get('districtId') == requested_id:
            # get information about the district. This might be better done at login
            self.district = Organization.objects.get(org_id=requested_id)
            self.filter_record = self.district
            self.filter_type = 'district'
            self.district.schools = self.district.get_child_organizations(jwt.get('dpId'))
            return
        raise PermissionDenied

    def get_data(self):
        """
        Subclasses of the ReportView should implement a get_data method which coordinates the retrieval of data.
        """
        raise NotImplementedError("Method does not implement get_data.")

    def get_query_parameter(self, query_params):
        """
        Return the name and the value of the query parameter that we will be querying with
        """
        for param in self.required_params:
            if param in query_params:
                return param, query_params[param]

    def _valid_query_params(self, query_params):
        """
        Check to make sure that we've passed in only one of the necessary query parameters.
        (staffId, schoolId, sectionId, studentId)
        """
        # check for the existence of the required parameters
        has_param = []
        for param in self.required_params:
            has_param.append(param in query_params.keys())

        # make sure that we only have one of these
        return sum(has_param) == 1

    # Dictionaries that maps each phonological skill to a readable name
    skill_labels_map = {
        "comprehension": {
            "concept": "Concept of Word",
            "sight": "Sight Vocabulary",
            "text": "Recall with Text",
            "recallPictureText": "Recall with Pictures",
            "sequencingPictures": "Sequencing Using Pictures",
            "sequencingText": "Sequencing Using Text"
        },
        "phonological": {
            "auditory": "Auditory Recognition",
            "alphabet": "Alphabet Knowledge",
            "correspondence": "Letter-Sound Correspondence",
            "consonants": "Identify Consonants",
            "vowels": "Identify Vowels",
            "syllables": "Identify Syllables",
            "blending": "Blending"
        }
    }


class ElasticSearchReportView(ReportView):

    filter_type_subsection_name_name = {
        'district': 'school',
        'school': 'section',
        'teacher': 'section',
        'section': 'student'
    }

    def columns_info(self):
        raise NotImplementedError()

    def student_ids(self):
        """
        Given either a District Org, School Org, Teacher, or Section, returns a list of dp_ids for all the students within.
        :return: dict with keys: id, name, student_ids: list of integers
        """
        student_ids = []
        if self.filter_type == 'district':
            for school in self.district.schools:
                student_ids.extend([s.id for s in school.students])
            return {'id': self.district.id, 'name': self.district.name, 'student_ids': student_ids}

        elif self.filter_type == 'school':
            for section in self.school.sections:
                student_ids.extend([s.id for s in section.students])
            return {'id': self.school.id, 'name': self.school.name, 'student_ids': student_ids}

        elif self.filter_type == 'teacher':
            for section in self.teacher.sections:
                student_ids.extend([s.id for s in section.students])
            return {'id': self.teacher.id, 'name': self.teacher.name, 'student_ids': student_ids}

        elif self.filter_type == 'section':
            # Sections always group by their students
            student_ids = [s.id for s in self.section.students]
            return {'id': self.section.id, 'name': self.section.name, 'student_ids': student_ids}

        elif self.filter_type == 'student':
            student_ids = [s.id for s in self.student.section.students]
            return {'id': self.student.id, 'name': self.student.name, 'student_ids': student_ids}

    def student_ids_groups(self):
        """
        Similar to the above,
        Given either a District Org, School Org, Teacher, or Section, returns a list of dicts corresponding to:
        1. The top level record (with id, name, students ids list
        :return: list of dicts
        """
        student_ids_groups = []

        if self.filter_type == 'district':
            # Districts always group by their schools
            student_ids_groups = [
                {'id': self.district.id, 'name': self.district.name, 'student_ids': []}
            ]
            for school in self.district.schools:
                students = [s.id for s in school.students]
                student_ids_groups[0]['student_ids'].extend(students)
                student_ids_groups.append({'id': school.id, 'name': school.name, 'student_ids': students})

        elif self.filter_type == 'school':
            # Schools always group by their sections
            student_ids_groups = [
                {'id': self.school.id, 'name': self.school.name, 'student_ids': []}
            ]
            for section in self.school.sections:
                students = [s.id for s in section.students]
                student_ids_groups[0]['student_ids'].extend(students)
                student_ids_groups.append({'id': section.id, 'name': section.name, 'student_ids': students})

        elif self.filter_type == 'teacher':
            # Teachers always group by their sections
            student_ids_groups = [
                {'id': self.teacher.id, 'name': self.teacher.name, 'student_ids': []}
            ]
            for section in self.teacher.sections:
                students = [s.id for s in section.students]
                student_ids_groups[0]['student_ids'].extend(students)
                student_ids_groups.append({'id': section.id, 'name': section.name, 'student_ids': students})

        elif self.filter_type == 'section':
            # Sections always group by their students
            student_ids_groups = [
                {'id': self.section.id, 'name': self.section.name, 'student_ids': []}
            ]
            for student in self.section.students:
                student_ids_groups[0]['student_ids'].append(student.id)
                student_ids_groups.append({'id': student.id, 'name': student.name, 'student_ids': [student.id]})

        else:
            raise NotImplementedError(
                "ElasticSearchReportView.student_ids_groups: No match on for filter_type %s" % self.filter_type
            )

        return student_ids_groups

    def student_ids_grades_groups(self, top_level_group=False):
        """
        Similar to the above,
        Given either a District Org, School Org, Teacher, or Section, returns a list of dicts corresponding to:
        1. The top level record (with id, name, students ids list
        :return: list of dicts: grade, name, student_ids (dp ids)
        """
        student_grades_map = {}
        student_ids_grades_groups = []
        all_students = []

        if top_level_group:
            student_ids_grades_groups = [
                {'grade': 'overall', 'name': 'All Grades', 'student_ids': []}
            ]

        # Merge conflict artifact - probably not needed here
        # group_name_by_query = {
        #     "districtId": "Schools",
        #     "schoolId": "Sections",
        #     "sectionId": "Students",
        #     "studentId": "Student",
        # }

        if self.filter_type == 'district':
            for school in self.district.schools:
                for grade, students in school.student_grades_map().items():
                    if grade not in student_grades_map:
                        student_grades_map[grade] = []
                    student_grades_map[grade].extend(students)

        elif self.filter_type == 'school':
            student_grades_map = self.school.student_grades_map().items()

        elif self.filter_type == 'teacher':
            student_grades_map = self.teacher.student_grades_map()

        elif self.filter_type == 'section':
            student_grades_map = self.section.student_grades_map()

        for grade, students in student_grades_map.items():
            all_students.extend(students)
            student_ids_grades_groups.append({
                'grade': grade,
                'name': self.grade_name_mapping.get(grade.lower(), 'Grade %s' % grade),
                'student_ids': [s.id for s in students]
            })

        if top_level_group:
            student_ids_grades_groups[0]['student_ids'] = [s.id for s in all_students]

        return student_ids_grades_groups

    @staticmethod
    def es_base_query():
        # Made this a method to avoid changing this when using it
        return {
            # "size": 0,
            "query": {
                "bool": {
                    "must": [],
                    "must_not": []
                }
            },
            "aggs": {}
        }

    @staticmethod
    def es_query_students_bucket_filters_aggregation(query, student_ids_groups):
        """
        Creates the basic Elastic Search query body for searching by filter aggregation by dp_id
        :param student_ids_groups: list of dicts corresponding to id+name values plus a list of student IDs to filter by
        :return: query dict
        """
        # Using anonymous filters here since a higher level item's id could collide with the student group's id
        query["aggs"]["students"] = {
            "filters": {
                "filters": []
            }
        }

        for group in student_ids_groups:
            query["aggs"]["students"]["filters"]["filters"].append(
                {
                    "terms": {
                        "dp_id": group["student_ids"]
                    }
                }
            )

        query["aggs"]["students"]["aggs"] = {
            "distinct_students": {
                "cardinality": {
                    "field": "dp_id"
                }
            }
        }
        return query

    @staticmethod
    def es_query_group_by_dp_id(query):
        query["aggs"]["students"]["aggs"]["by_student"] = {
            "terms": {
                "field": "dp_id"
            }
        }
        return query

    @staticmethod
    def es_query_correct_total(query):
        query["aggs"]["students"]["aggs"]["correct_total"] = {
            "sum": {
                "field": "score"
            }
        }
        return query

    @staticmethod
    def es_score_filter_date_bounds(query, start, end):
        query["query"]["bool"]["must"].append(
            {
                "range": {
                    "created": {
                        "gte": int(start.timestamp()),
                        "lte": int(end.timestamp()),
                        "format": "epoch_second"
                    }
                }
            }
        )
        return query

    @staticmethod
    def es_book_progress_request(query):
        results = es.search(index=es_index_name("book_progress"), doc_type="default", body=query, request_timeout=20)
        return results

    @staticmethod
    def es_score_request(query):
        results = es.search(index='%s*' % es_index_name("score"), doc_type="default", body=query, request_timeout=30)
        return results


class BaseElasticSearchReportView(ElasticSearchReportView):
    labels_info = []
    filters_info = []

    def get_data(self):
        return {
            'cohortType': self.cohort_type_mapping[self.query_param],
            'cohortTitle': self.filter_record.name,
            'columns': self.labels_info,
            'cohorts': [],
            'filters': self.filters_info,
            'page': 1,
            'pages': 1,
            'version': 'sdfAGqihgAG3954tanBfbgabfdb',  # @TODO tie this to Git commit or some other environment version
        }


class BaseTableNavElasticSearchReportView(ElasticSearchReportView):

    def get_data(self):
        return {
            'table': {
                'cohortType': self.cohort_type_mapping[self.query_param],
                'cohortTitle': self.filter_record.name,
                'columns': self.columns_info(),
                'rows': [],
                'page': 1,
                'pages': 1,
                'sortType': 'alphabetical',
                'sortOrder': 'asc',
                'version': 'sdfAGqihgAG3954tanBfbgabfdb',  # @TODO tie this to Git commit or some other environment version
            }
        }


class ReportNavMetricsAPI(BaseElasticSearchReportView):

    def get_score_averages(self, student_ids):
        """
        Gets the phonological, comprehension and combined averages for all students in student_ids
        """
        query = self.es_base_query()
        query['query']['bool']['must'].append({
            "terms": {
                "dp_id": student_ids['student_ids']
            }
        })
        query['query']['bool']['must_not'].append({
            "term": {
                "skill_label": ""
            }
        })
        # group into phonological and comprehension averages
        query['aggs'] = {
            "by_type": {
                "terms": {
                    "field": "skill_type"
                },
                "aggs": {
                    "type_avg": {
                        "avg": {
                            "field": "score"
                        }
                    }
                }
            }
        }

        comprehension = 0.
        phonological = 0.

        results = self.es_score_request(query)
        for average in results['aggregations']['by_type']['buckets']:
            if average['key'] == 'comprehension':
                comprehension = average['type_avg']['value']
            elif average['key'] == 'phonological':
                phonological = average['type_avg']['value']

        return phonological, comprehension, (phonological+comprehension)/2

    def get_time_played(self, student_ids):
        """
        Gets the total amount of time played by the all students in student_ids
        """
        query = self.es_base_query()
        query['query']['bool']['must'].append({
            "terms": {
                "dp_id": student_ids['student_ids']
            }
        })
        query['aggs']['by_session'] = {
            "terms": {
                "field": "session_key",
                "size": 500 * 1000 * 1000  # 500 million records, good for 50,000 users finishing the game
            },
            "aggs": {
                "session_ended": {
                    "max": {
                        "field": "created",
                        "format": "epoch_second"
                    }
                },
                "session_started": {
                    "min": {
                        "field": "created",
                        "format": "epoch_second"
                    }
                },
                "session_time": {
                    "bucket_script": {
                        "buckets_path": {
                            "start": "session_started",
                            "end": "session_ended"
                        },
                        "script": "params.end - params.start"
                    }
                }
            }
        }

        query["aggs"]["sessions_total"] = {
            "sum_bucket": {
                "buckets_path": "by_session>session_time"
            }
        }

        sessions_total = 0.
        results = self.es_score_request(query)
        if 'sessions_total' in results['aggregations']:
            sessions_total = results['aggregations']['sessions_total']['value']
        return sessions_total

    def format_time_played(self, time_played):
        time_played_minutes = time_played / 1000 / 60

        if time_played_minutes >= 1000:
            return "%dK" % int(time_played_minutes/1000)
        else:
            return int(round(time_played_minutes))

    def get_data(self):
        data = super(ReportNavMetricsAPI, self).get_data()
        student_ids = self.student_ids()

        # get the scores section of the report
        phonological, comprehension, overall = self.get_score_averages(student_ids)

        # get the time played section of the report
        time_played = self.format_time_played(self.get_time_played(student_ids))


        data['cohortSummary'] = {
            "time_played": str(time_played),  # make sure it's always a string
            "overallAvg": int(overall*100),
            "phonological": int(phonological*100),
            "comprehension": int(comprehension*100)
        }

        return data


class TimePlayedGradeUsageTableAPI(ReportView):
    """
    Time Played API for Table Nav
    https://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/getOverviewTableUsageGrade
    """
    columns_info = [
       {'prop': 'grade', 'name': 'Grade Level', 'order': 1},
       {'prop': 'time', 'name': 'Total Minutes Spent', 'order': 2},
       {'prop': 'avgTimePerStudent', 'name': 'Avg Minutes Per Student', 'order': 3},
       {'prop': 'avgSessionsPerWeek', 'name': 'Avg Sessions Per Week', 'order': 4},
       {'prop': 'avgTimePerSession', 'name': 'Avg Minutes Per Session', 'order': 5}
    ]

    def _get_time_played(self, start, end, filter_id, filter_by, group_by_grade):
        """
        :param start: datetime period start
        :param end: datetime period end
        :param filter_id: integer to filter by, or a list of objects
        :param filter_by: record type to filter by, see: self.query_type_mapping
        :param group_by_grade: boolean
        :return:
        """

        # @TODO filter by time bounds
        query_duration = end - start
        weeks = int(query_duration.days / 7)
        query_field = self.query_type_mapping[filter_by]
        query_dict = dict(size=0)
        if type(filter_id) is int:
            query_dict['query'] = {"term": {query_field: filter_id}}
        else:
            query_dict['query'] = {"terms": {query_field: [r.id for r in filter_id]}}
        query_dict['aggs'] = {
            filter_by: {
                "aggs": {
                    "total_seconds": {
                        "sum": {"field": "time_played_seconds"}
                    },
                    "unique_sessions": {
                        "value_count": {"field": query_field}
                    },
                    "unique_students": {
                        "value_count": {"field": "dp_id"}
                    },
                }
            }
        }
        if group_by_grade:
            query_dict['aggs'][filter_by]['terms'] = {"field": "scholastic_grade_code"}
        else:
            query_dict['aggs'][filter_by]['terms'] = {"field": query_field}

        results = es.search(index=es_index_name("unity-session"), doc_type="default", body=query_dict)

        cohorts = []
        for agg in results['aggregations'][filter_by]['buckets']:
            agg_data = {
                "grade": self.grade_name_mapping.get(agg["key"].lower(), 'Grade %s' % agg["key"]) if group_by_grade else "Full %s" % filter_by.capitalize(),
                "time": agg['total_seconds']['value'] / 60,
                "avgTimePerStudent": (agg['total_seconds']['value'] / agg['unique_students']['value']) / 60,
                "avgSessionsPerWeek": agg['unique_sessions']['value'] / weeks,
                "avgTimePerSession": (agg['total_seconds']['value'] / agg['unique_sessions']['value']) / 60
            }
            cohorts.append(agg_data)

        if not group_by_grade:
            return cohorts[0] if len(cohorts) > 0 else None
        return cohorts

    def get_data(self):
        # @TODO Tie this start/end date to the record's school year?
        start = datetime.datetime(year=2017, month=9, day=1)
        end = datetime.datetime.now()

        data = dict(table=dict(
            cohortType=self.cohort_type_mapping[query_param],
            usageTitle='Usage by Grade Level',
            columns=self.columns_info,
            rows=[],
            page=1,
            pages=1,
            sortType='alphabetical',
            sortOrder='asc',
            version='sdfAGqihgAG3954tanBfbgabfdb',  # @TODO tie this to Git commit or some other environment version
        ))
        rows = []
        if query_param == 'districtId':
            rows.append(self._get_time_played(start, end, self.district.id, filter_by="district", group_by_grade=False))
            rows.extend(self._get_time_played(start, end, self.district.id, filter_by='district', group_by_grade=True))
        elif query_param == "schoolId":
            rows.append(self._get_time_played(start, end, self.school.id, filter_by="school", group_by_grade=False))
            rows.extend(self._get_time_played(start, end, self.school.id, filter_by="school", group_by_grade=True))
        elif query_param == "teacherId":
            rows.append(self._get_time_played(start, end, self.teacher.sections, filter_by="section", group_by_grade=False))
            rows.extend(self._get_time_played(start, end, self.teacher.sections, filter_by="section", group_by_grade=True))
        elif query_param == "sectionId":
            rows.append(self._get_time_played(start, end, self.section.id, filter_by="section", group_by_grade=False))
        elif query_param == "studentId":
            rows.append(self._get_time_played(start, end, self.student.id, filter_by="student", group_by_grade=False))
        data['table']['rows'] = rows
        return data


class TimePlayedByLocationByPeriodAPI(ReportView):
    """
    Time Played API for Table Nav
    https://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/getTableTimePlayedPeriodGrouping
    """
    query_type_mapping = {
        "student": "dp_id", "section": "section_id", "school": "school_id", "district": "district_id", "teacher": "teacher_id"
    }
    filters_info = [
        {'prop': 'last7Days', 'name': 'Last 7 Days', 'order': 0},
        {'prop': 'SYTD', 'name': 'School Year to Date', 'order': 1},
        # {'prop': 'byMonth', 'name': 'By Month', 'order': 2}
    ]
    labels_info = [
        {'key': 'in', 'name': 'In School', 'order': 0},
        {'key': 'out', 'name': 'Out of School', 'order': 1}
    ]

    def _get_time_played(self, start, end, filter_id, filter_by, period_grouping):
        # @TODO filter by time bounds
        query_field = self.query_type_mapping[filter_by]
        query_dict = dict(size=0)
        if type(filter_id) is int:
            query_dict['query'] = {"term": {query_field: filter_id}}
        else:
            query_dict['query'] = {"terms": {query_field: filter_id}}

        if period_grouping == 'last7days':
            query_dict['aggs'] = {
                'last7days': {
                    "date_histogram": {
                        "field": "started",
                        "interval": "day",
                        "format": "Y-M-d",  # 2018-4-1
                        # "format": "EE MMM d"  # Sun Apr 1
                    },
                    "aggs": {
                        "total_seconds": {
                            "terms": {"field": "gameplay_location"},
                            "aggs": {
                                "total_seconds": {
                                    "sum": {"field": "time_played_seconds"},
                                }
                            }
                        }
                    }
                }
            }
        elif period_grouping == 'SYTD':
            query_dict['aggs'] = {
                'SYTD': {
                    "date_histogram": {
                        "field": "started",
                        "interval": "month",
                        "format": "MMM"  # Apr
                    },
                    "aggs": {
                        "total_seconds": {
                            "terms": {"field": "gameplay_location"},
                            "aggs": {
                                "total_seconds": {
                                    "sum": {"field": "time_played_seconds"},
                                }
                            }
                        }
                    }
                }
            }

        results = es.search(index=es_index_name("unity-session"), doc_type="default", body=query_dict)

        periods = {}
        for agg in results['aggregations'][period_grouping]['buckets']:
            periods[agg['key_as_string']] = dict()
            for period_bucket in agg['total_seconds']['buckets']:
                if period_bucket['key'] == 'home':
                    periods[agg['key_as_string']]['out'] = period_bucket['total_seconds']['value'] / 60
                else:
                    # Since it's likely untagged gameplay would exist, default to having it be in "In School"
                    periods[agg['key_as_string']]['in'] = period_bucket['total_seconds']['value'] / 60
        return periods

    def get_data(self):
        # @TODO Tie this start/end date to the record's school year?

        start_school_year = datetime.datetime(year=2017, month=9, day=1)
        end_school_year = datetime.datetime.now()
        end_last_7 = datetime.datetime.now()
        start_last_7 = end_last_7 - datetime.timedelta(days=8)

        data = dict(
            filters=self.filters_info,
            columns=self.labels_info,
            cohorts=[],
            page=1,
            pages=1,
            version='sdfAGqihgAG3954tanBfbgabfdb',  # @TODO tie this to Git commit or some other environment version
        )
        cohort = dict(
            cohortId=value,
            cohortType = self.cohort_type_mapping[query_param],
            timePlayed={}
        )
        if query_param == 'districtId':
            data['cohortTitle'] = self.district.name
            cohort['name'] = self.district.name
            cohort['timePlayed']['last7days'] = self._get_time_played(start_last_7, end_last_7, int(value), "district", 'last7days')
            cohort['timePlayed']['SYTD'] = self._get_time_played(start_school_year, end_school_year, int(value), 'district', 'SYTD')
        elif query_param == "schoolId":
            school = self.allowed_schools[0]
            data['cohortTitle'] = school[1]
            cohort['name'] = school[1]
            cohort['timePlayed']['last7days'] = self._get_time_played(start_last_7, end_last_7, int(value), 'school', 'last7days')
            cohort['timePlayed']['SYTD'] = self._get_time_played(start_school_year, end_school_year, int(value), 'school', 'SYTD')
        # @TODO Figure out if this is even necessary -rp
        # elif query_param == "teacherId":
        #     cohort['cohortType'] = 'sections'
        #     cohort['timePlayed']['last7days'] = self._get_time_played(start_last_7, end_last_7, int(value), 'school', 'last7days')
        #     cohort['timePlayed']['SYTD'] = self._get_time_played(start_school_year, end_school_year, int(value), 'school', 'SYTD')
        elif query_param == "sectionId":
            section = self.allowed_sections[0]
            data['cohortTitle'] = section[1]
            cohort['name'] = section[1]
            cohort['timePlayed']['last7days'] = self._get_time_played(start_last_7, end_last_7, int(value), 'section', 'last7days')
            cohort['timePlayed']['SYTD'] = self._get_time_played(start_school_year, end_school_year, int(value), 'section', 'SYTD')
        elif query_param == "studentId":
            student = self.allowed_students[0]
            data['cohortTitle'] = student[1]
            cohort['name'] = student[1]
            cohort['timePlayed']['last7days'] = self._get_time_played(start_last_7, end_last_7, int(value), 'student', 'last7days')
            cohort['timePlayed']['SYTD'] = self._get_time_played(start_school_year, end_school_year, int(value), 'student', 'SYTD')
        data['cohorts'] = [cohort]
        return data


class SnapshotInfographicAPI(ReportView):
    """
    Time Played API for Table Nav
    https://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/getInfographicSnapshot
    """
    query_type_mapping = {
        "student": "dp_id", "section": "section_id", "school": "school_id", "district": "district_id", "teacher": "teacher_id"
    }
    columns_info_district_school_teacher = [
       {'name': 'Schools', 'prop': 'schools', 'order': 1},
       {'name': 'Teachers', 'prop': 'teachers', 'order': 2},
       {'name': 'Classes', 'prop': 'classes', 'order': 3},
       {'name': 'Students', 'prop': 'students', 'order': 4}
    ]

    columns_info_section_student = [
        {'name': 'Hours on Ooka Island', 'prop': 'time', 'order': 1},
        {'name': 'Avg Sessions Per Week', 'prop': 'avgSessionsPerWeek', 'order': 2},
        {'name': 'Avg Sessions Length', 'prop': 'avgSessionsLength', 'order': 3},
        {'name': 'Phonological Average', 'prop': 'phonological', 'order': 4},
        {'name': 'Comprehension Average', 'prop': 'comprehension', 'order': 5}
    ]

    def _get_schools_count(self):
        schools = self.district.schools
        return len(schools) if schools else 0

    def _get_teachers_count(self, entity):
        return len(entity.teachers)

    def _get_sections_count(self, entity):
        return len(entity.sections)

    def _get_students_count(self, entity):
        return len(entity.students)

    def _get_reading_averages(self, filter_id, filter_by):
        # TODO: Refactor all elastic search related things to make sure we are consistent
        score_service_mapping = {'section': 'sections', 'student': 'gameusers'}

        ss = ScoreService()
        score_data = ss.get_aggregate(filter_id, score_service_mapping[filter_by])

        # calculate the phonological averages
        phonological_correct = 0.
        phonological_attempts = 0.
        comprehension_correct = 0.
        comprehension_attempts = 0.

        for agg in score_data[score_service_mapping[filter_by]]:
            for grade in self.grade_name_mapping:
                if grade in agg:
                    for al in agg[grade]['activityLevels']:
                        # phonological activities are split up into scores on parts
                        for part in al['parts']:
                            # based on the activitylevel, determine whether this contributes to comprehension or phonological
                            if al['id'] in phonological_als:
                                phonological_correct += part['correct']
                                phonological_attempts += part['attempts']
                            else:
                                comprehension_correct += part['correct']
                                comprehension_attempts += part['attempts']

        phonological_average = phonological_correct / phonological_attempts if phonological_attempts != 0. else 0.
        comprehension_average = comprehension_correct / comprehension_attempts if comprehension_attempts != 0. else 0.

        return phonological_average, comprehension_average

    def _get_performance_data(self, start, end, filter_id, filter_by):
        # @TODO filter by time bounds
        query_duration = end - start
        weeks = int(query_duration.days / 7)
        query_field = self.query_type_mapping[filter_by]
        query_dict = dict(size=0)
        if type(filter_id) is int:
            query_dict['query'] = {"term": {query_field: filter_id}}
        else:
            query_dict['query'] = {"terms": {query_field: filter_id}}
        query_dict['aggs'] = {
            filter_by: {
                "aggs": {
                    "total_seconds": {
                        "sum": {"field": "time_played_seconds"}
                    },
                    "unique_sessions": {
                        "value_count": {"field": query_field}
                    },
                    "unique_students": {
                        "value_count": {"field": "dp_id"}
                    },
                }
            }
        }
        query_dict['aggs'][filter_by]['terms'] = {"field": query_field}

        results = es.search(index=es_index_name("unity-session"), doc_type="default", body=query_dict)

        phonological_average, comprehension_average = self._get_reading_averages(filter_id, filter_by)

        cohorts = []
        for agg in results['aggregations'][filter_by]['buckets']:
            agg_data = {
                "time": agg['total_seconds']['value'] / 60,
                "avgSessionsPerWeek": agg['unique_sessions']['value'] / weeks,
                "avgSessionsLength": (agg['total_seconds']['value'] / agg['unique_sessions']['value']) / 60,
                # @TODO Replace with dynamic values
                'phonological': phonological_average,
                'comprehension': comprehension_average
            }
            cohorts.append(agg_data)
        # @TODO just one? or the list
        return cohorts

    def get_data(self):
        # @TODO Tie this start/end date to the record's school year?
        start = datetime.datetime(year=2017, month=9, day=1)
        end = datetime.datetime.now()

        data = dict(table=dict(
            rows=[],
            cohortType=self.cohort_type_mapping[self.query_param],
            page=1,
            pages=1,
            sortType='alphabetical',
            sortOrder='asc',
            version='sdfAGqihgAG3954tanBfbgabfdb',  # @TODO tie this to Git commit or some other environment version
        ))
        if query_param == 'districtId':
            # Counts of Schools, Teachers, Classes, and Students
            district = self.district
            data['table']['cohort'] = district.name
            data['table']['cohortTitle'] = district.name
            data['table']['columns'] = self.columns_info_district_school_teacher
            data['table']['rows'] = [
                {
                    'schools': self._get_schools_count(),
                    'teachers': self._get_teachers_count(self.district),
                    'classes': len(self.district.get_sections_by_staff_id(self.dp_id)),
                    'students': len(self.district.get_students())
                }
            ]

            data['table']['pie'] = self.district.student_grades_map_counts()
        elif query_param == "schoolId":
            # Counts of Teachers, Classes, and Students
            data['table']['cohort'] = self.school.name
            data['table']['cohortTitle'] = self.school.name
            data['table']['columns'] = self.columns_info_district_school_teacher[1:]
            data['table']['rows'] = [
                {
                    'teachers': self._get_teachers_count(self.school),
                    'classes': self._get_sections_count(self.school),
                    'students': self._get_students_count(self.school)
                }
            ]
            data['table']['pie'] = self.school.student_grades_map_counts()
        elif query_param == "teacherId":
            # Counts of Teachers, Classes, and Students
            data['table']['cohort'] = self.teacher.name
            data['table']['cohortTitle'] = self.teacher.name
            data['table']['columns'] = self.columns_info_district_school_teacher[2:]
            data['table']['rows'] = [
                {
                    'classes': self._get_sections_count(self.teacher),
                    'students': self._get_students_count(self.teacher)
                }
            ]
            data['table']['pie'] = self.teacher.student_grades_map_counts()
        elif query_param == "sectionId":
            data['table']['cohort'] = self.section.name
            data['table']['cohortTitle'] = self.section.name
            data['table']['columns'] = self.columns_info_section_student
            data['table']['rows'] = self._get_performance_data(start, end, self.section.id, filter_by="section")
        elif query_param == "studentId":
            data['table']['cohort'] = self.student.name
            data['table']['cohortTitle'] = self.student.name
            data['table']['columns'] = self.columns_info_section_student
            data['table']['rows'] = self._get_performance_data(start, end, self.student.id, filter_by="student")
        return data


class PerformanceOverviewAPI(ReportView):

    legend = [
        {'prop': 'learning', 'name': 'Learning', 'order': 0, 'color': '#2d2f8c'},
        {'prop': 'practicing', 'name': 'Practicing', 'order': 1, 'color': '#0069c7'},
        {'prop': 'proficient', 'name': 'Proficient', 'order': 2, 'color': '#00aae7'}
    ]

    headers = [
        {
            'prop': 'comprehensionSkills',
            'name': 'Comprehension Skills',
            'order': 0
        },
        {
            'prop': 'phonologicalSkills',
            'name': 'Phonological Skills',
            'order': 1
        }
    ]

    def _get_column_data(self):
        columns = []
        columns.append({
            'prop': 'name',
            'name': '',
            'set': '',
            'order': 0
        })

        for skill in self.ordered_skills['comprehension']:
            columns.append(skill)

        comprehension_len = len(columns)

        columns.append({
            'prop': 'id',
            'name': '',
            'set': '',
            'order': len(columns)
        })

        for skill in self.ordered_skills['phonological']:
            skill['order'] += comprehension_len
            columns.append(skill)

        return columns

    def get_data(self):

        columns = self._get_column_data()

        data = {
            "chartTitle":'',
            "legend": self.legend,
            "cohortType": self.cohort_type_mapping[query_param],
            "headers": self.headers,
            "columns": columns,
            "rows": []
        }

        if query_param == 'districtId':
            data['chartTitle'] = self.district.name
            data['rows'] += PerformanceOverviewAPI.get_performance_overview(self.district, agg_type='districts')
            data['rows'] += PerformanceOverviewAPI.get_performance_overview(self.district.get_child_organizations(staff_id=self.dp_id), agg_type='schools')
        elif query_param == 'schoolId':
            data['chartTitle'] = self.school.name
            data['rows'] += PerformanceOverviewAPI.get_performance_overview(self.school, agg_type='schools')
            data['rows'] += PerformanceOverviewAPI.get_performance_overview(self.school.sections, agg_type='sections')
        elif query_param == 'sectionId':
            data['chartTitle'] = self.section.name
            data['rows'] += PerformanceOverviewAPI.get_performance_overview(self.section, agg_type='sections')
            data['rows'] += PerformanceOverviewAPI.get_performance_overview(self.section.students, agg_type='gameusers')
        elif query_param == 'teacherId':
            data['chartTitle'] = self.teacher.name            
            rows += PerformanceOverviewAPI.get_performance_overview(self.teacher, agg_type="schools")
            rows += PerformanceOverviewAPI.get_performance_overview(self.teacher.sections, agg_type="sections")

        return data

    @staticmethod
    def get_performance_overview(records, agg_type):
        if type(records) != list:
            records = [records]
        cohort_names = {record.id: record.name for record in records}
        fetch_ids = [record.id for record in records]

        # for this report, on gameusers, we only want recent results for each skill
        users_recent_gameplay = None
        if agg_type == 'gameusers':
            users_recent_gameplay = PerformanceOverviewAPI.get_user_recent_gameplay(fetch_ids)

        # now we fetch the data from elasticsearch
        data = sses.get_aggregate(fetch_ids, agg_type)

        overview_skills = PerformanceOverviewAPI._generate_initial_skills()
        cohorts = []
        for agg in data[agg_type]:
            cohort_name = cohort_names[int(agg['id'])]

            for grade in PerformanceOverviewAPI.grade_name_mapping:
                if grade in agg:
                    for al in agg[grade]['activityLevels']:
                        al_id = str(al['id'])
                        if users_recent_gameplay is None:
                            for part in al['parts']:
                                # get the skill that this activitylevel maps to. Either phonological or comprehension
                                if al['id'] in comprehension_als:
                                    skill = al_comprehension_mappings[al_id]
                                elif al['id'] in phonological_als:
                                    skill = al_phonological_mappings[al_id][part['part']]

                                overview_skills[skill][grade]['correct'] += part['correct']
                                overview_skills[skill][grade]['attempts'] += part['attempts']
                                overview_skills[skill]['overall']['correct'] += part['correct']
                                overview_skills[skill]['overall']['attempts'] += part['attempts']
                        else:
                            # if we have a recent gameplay dictionary then we want to focus only on the activity levels
                            # inside that dictionary
                            if al['id'] in users_recent_gameplay[agg['id']]:
                                for part in al['parts']:
                                    # get the skill that this activitylevel maps to. Either phonological or comprehension
                                    if al['id'] in comprehension_als:
                                        skill = al_comprehension_mappings[al_id]
                                    elif al['id'] in phonological_als:
                                        skill = al_phonological_mappings[al_id][part['part']]

                                    overview_skills[skill][grade]['correct'] += part['correct']
                                    overview_skills[skill][grade]['attempts'] += part['attempts']
                                    overview_skills[skill]['overall']['correct'] += part['correct']
                                    overview_skills[skill]['overall']['attempts'] += part['attempts']

            # I need to make a separate structure for each grade to conform to the front end expectations
            # TODO: We could probably just produce the intermediate structure in this format initially
            grade_structure = defaultdict(dict)

            for skill in overview_skills:
                for grade in overview_skills[skill]:
                    grade_structure[grade][skill] = {
                        "correct": overview_skills[skill][grade]['correct'],
                        "attempts": overview_skills[skill][grade]['attempts']
                    }

            for grade in grade_structure:
                agg_data = {
                    "id": agg["id"],
                    "name": cohort_name,
                    "cohortType": ReportView.cohort_type_agg_mapping[agg_type],
                    # This is what was requested by front-end spec
                    "grade": "Full District" if grade == "overall" else PerformanceOverviewAPI.grade_name_mapping[grade]
                }
                for skill in grade_structure[grade]:
                    correct = grade_structure[grade][skill]["correct"]
                    attempts = grade_structure[grade][skill]["attempts"]
                    agg_data[skill] = correct / attempts if attempts != 0 else 0

                cohorts.append(agg_data)

        return cohorts

    @staticmethod
    def get_user_recent_gameplay(ids):
        """
        Given a list of users, for each phonological and comprehension skill we want to be able to get the most recent
        score data for those skills. For phonological skills we want to return the activity levels that make up the two
        most recent levels for activities that comprise that phonological skill. Similarly we want to do this for
        comprehension, but using the last 5 books.
        :param ids: dp_ids of users for which we want to return this data.
        :return: A dictionary that, for each user, contains a key for each phonological skill which maps to a list of
                activity levels comprising the two most recent levels for relevent activities
        """

        # Query all activity progress and book progress for all ids passed in. This should be the only time
        # that we hit the database for efficiency
        activity_level_progress = UserActivityLevelProgress.objects.filter(game_user__dp_id__in=ids)
        user_book_progress = UserBookProgress.objects.filter(game_user__dp_id__in=ids)

        # evaluate the queryset
        len(activity_level_progress)
        len(user_book_progress)

        # Split this large queryset into smaller querysets for each phonological skill
        skill_querysets = PerformanceOverviewAPI._get_skill_querysets(activity_level_progress)

        # for each user, now we get a dictionary of the levels that they have completed for each
        # phonological skill and the activitylevels that make up those levels
        user_skill_levels = PerformanceOverviewAPI._get_user_skill_levels(ids, skill_querysets)

        # this structure is a bit more complicated than we need it to be. We only want to return the two most recent
        # levels played for each user, and the activitylevels that make up those two most recent levels
        users_recent_skill_als = PerformanceOverviewAPI._get_recent_skill_als(user_skill_levels)

        # nothing done so far will populate this dictionary with the most recent comprehension skills. For this we want
        # the activitylevels that correspond to the 5 most recently read books
        users_recent_book_als = PerformanceOverviewAPI._get_most_recent_book_als(ids, user_book_progress)

        # now append the activitylevels for each book to the proper skill in our dictionary
        for user in users_recent_book_als:
            for al in users_recent_book_als[user]:
                users_recent_skill_als[user][al_comprehension_mappings[al]].append(al)

        # TODO: I might have wasted some time above, the get_performance_overview method will figure out the mapping
        # TODO: between activitylevel and skill
        users_al_list = defaultdict(list)
        for user in users_recent_skill_als:
            for skill in users_recent_skill_als[user]:
                users_al_list[user] += users_recent_skill_als[user][skill]

        return users_al_list

    @staticmethod
    def _get_most_recent_book_als(user_ids, all_queryset):
        user_recent_book_als = {}
        for user_id in user_ids:
            uid = str(user_id)
            user_recent_book_als[uid] = []
            user_recent_books = [ubp.book_id for ubp in all_queryset.filter(game_user__dp_id=user_id).order_by('-pk')[:5]]
            for book_id in user_recent_books:
                user_recent_book_als[uid] += book_mapping[book_id]

        return user_recent_book_als

    @staticmethod
    def _get_skill_querysets(all_queryset):
        """
        Break the huge queryset containing all skills into individual querysets for each skill
        :param all_queryset:  A queryset containing level progress for all skills
        :return: A dictionary of querysets that is indexed by skill
        """
        skill_queryset = {}
        labels = {**PerformanceOverviewAPI._get_phonological_labels,
                  **PerformanceOverviewAPI._get_comprehension_labels}
        # we'll just use the skill labels as keys
        for skill in labels:
            # skill_reverse_mapping is keyed on each skill. It is a mapping to all activitylevels that possibly
            # contribute to that skill
            skill_queryset[skill] = all_queryset.filter(activity_level_id__in=skill_reverse_mapping[skill])

        return skill_queryset

    @staticmethod
    def _get_user_skill_levels(user_ids, skill_querysets):
        """
        For each user we will create a structure which contains all of the levels that a user has played within a
        particular skill. For each of these skill levels we will include the activity levels that comprise each of the
        skill levels
        :param user_ids: A list of user ids to aggregate this information into
        :param skill_querysets: A dictionary containing querysets for each skill
        :return:
        """
        user_skill_levels = {}
        for user_id in user_ids:
            uid = str(user_id)
            user_skill_levels[uid] = {}
            for skill in skill_querysets:
                # filter the skill queryset to only have the progress for the current user
                user_skill_queryset = skill_querysets[skill].filter(game_user__dp_id=user_id)
                # now using this queryset get a list of all levels(and activitylevels) that the user has done for this
                # skill
                user_skill_levels[uid][skill] = PerformanceOverviewAPI.get_level_skills(user_skill_queryset)

        return user_skill_levels

    @staticmethod
    def _get_recent_skill_als(user_skill_levels):
        """
        This function will transform what is a dictionary that is a full record of the levels a user has completed
        and a mapping to the relevant activity levels and transform it to a simpler structure that is only the two
        most recent levels that a user has completed
        :param user_skill_levels:
        :return:
        """
        user_skill_als = {}
        for user in user_skill_levels:
            user_skill_als[user] = {}
            for skill in user_skill_levels[user]:
                user_skill_als[user][skill] = []
                # user_skill_levels contains ALL levels played, we just want the two most recent, that means the
                # two highest keys (hopefully)
                recent_levels = sorted(user_skill_levels[user][skill].keys())[-2:]

                # add the acitivity levels associated with these two recent levels to the
                for level in recent_levels:
                    user_skill_als[user][skill] += user_skill_levels[user][skill][level]

        return user_skill_als

    @staticmethod
    def get_level_skills(user_level_progress):
        """
        This takes in the level progress for a user and changes it to a mapping between game levels and activity level
        ids
        :param user_level_progress:
        :return:
        """
        level_mapping = defaultdict(list)
        for ulp in user_level_progress:
            al_id = str(ulp.activity_level_id)
            level = int(al_progress_mapping[al_id]['level'])
            level_mapping[level].append(ulp.activity_level_id)
        return level_mapping

    @staticmethod
    def _generate_initial_skills():

        init_entry = {k: {"correct": 0, "attempts": 0} for k in PerformanceOverviewAPI.grade_name_mapping}
        init_entry["overall"] = {"correct": 0, "attempts": 0}

        return {
            "auditory": copy.deepcopy(init_entry),
            "alphabet": copy.deepcopy(init_entry),
            "correspondence": copy.deepcopy(init_entry),
            "consonants": copy.deepcopy(init_entry),
            "vowels": copy.deepcopy(init_entry),
            "syllables": copy.deepcopy(init_entry),
            "blending": copy.deepcopy(init_entry),
            "concept": copy.deepcopy(init_entry),
            "sight": copy.deepcopy(init_entry),
            "text": copy.deepcopy(init_entry),
            "recallPictureText": copy.deepcopy(init_entry),
            "sequencingPictures": copy.deepcopy(init_entry),
            "sequencingText": copy.deepcopy(init_entry)
        }
    