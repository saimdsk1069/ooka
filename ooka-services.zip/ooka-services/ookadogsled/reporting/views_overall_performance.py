from collections import defaultdict
from .views import BaseElasticSearchReportView

class OverallPerformanceAPI(BaseElasticSearchReportView):

    skills = [
        "auditory", "alphabet", "correspondence", "consonants", "vowels", "syllables", "blending",
        "concept", "sight", "text", "recallPictureText", "sequencingPictures", "sequencingText"
    ]
    skills_type = None

    def es_query_by_ids_group(self, query, student_ids_group):
        student_ids = []
        for group in student_ids_group:
            student_ids += group['student_ids']

        query['query']['bool']['must'].append({
            "terms": {
                "dp_id": student_ids
            }
        })

        return query

    def es_query_bucket_by_student_skill(self, query):
        query["aggs"]["students"] = {
            "terms": {
                "field": "dp_id"
            },
            "aggs": {
                "by_label": {
                    "terms": {
                        "field": "skill_label"
                    },
                    "aggs": {
                        "skill_avg": {
                            "avg": {
                                "field": "score"
                            }
                        }
                    }
                }
            }
        }
        return query

    def get_student_skill_averages(self, query):
        """
        Takes in an ES query that buckets in students which subbucket into skills. And returns this data as
        a dictionary keyed by the student_id with skill properties containing average scores
        :param query:
        :return:
        """
        results = self.es_score_request(query)
        student_skill_averages = defaultdict(dict)
        for student in results['aggregations']['students']['buckets']:
            for skill in student['by_label']['buckets']:
                student_skill_averages[student['key']][skill['key']] = skill['skill_avg']['value']

        return student_skill_averages


    def get_data(self):
        data = super(OverallPerformanceAPI, self).get_data()

        data['legend'] = self.add_legend()
        data['headers'] = self.add_headers()
        data['columns'] = self.add_columns()

        # get students list grouped by cohort
        student_ids_group = self.student_ids_groups()

        # build the query:
        # we want all student ids across all groups, and ultimately we want things groups by student and subgrouped
        # by the skills
        query = self.es_base_query()
        query = self.es_query_by_ids_group(query, student_ids_group)
        query['query']['bool']['must_not'].append({
            "term": {
                "skill_label": ""
            }
        })
        query = self.es_query_bucket_by_student_skill(query)

        # get the averages by skill for each user
        student_skill_averages = self.get_student_skill_averages(query)

        # now for each group, we want to average the student averages
        for group in student_ids_group:
            cohort_data = {"name": group['name'], "id": group['id']}
            group_skills = {skill: [] for skill in self.skills}
            for student_id in group['student_ids']:
                if student_id in student_skill_averages:
                    for skill in student_skill_averages[student_id]:
                        group_skills[skill].append(student_skill_averages[student_id][skill])

            for skill in group_skills:
                cohort_data[skill] = sum(group_skills[skill]) / len(group_skills[skill]) if len(group_skills[skill]) != 0 else 0.

            data['cohorts'].append(cohort_data)

        return data

    def add_legend(self):
        """
        Creates the legend for the overall performance table. This is static for now.
        """
        return [
            {
                "prop": "learning",
                "name": "Learning",
                "order": 0,
                "color": "#2d2f8c"
            },
            {
                "prop": "practicing",
                "name": "Practicing",
                "order": 1,
                "color": "#0069c7"
            },
            {
                "prop": "proficient",
                "name": "Proficient",
                "order": 2,
                "color": "#00aae7"
            }
        ]

    def add_headers(self):
        """
        Creates the comprehension/phonological headers for the overall performance table. This is static for now.
        """
        return [
            {
                "prop": "comprehensionSkills",
                "name": "Comprehension Skills",
                "order": 0
            },
            {
                "prop": "phonologicalSkills",
                "name": "Phonological Skills",
                "order": 1
            }
        ]

    def add_columns(self):
        """
        Creates the columns for the overall performance table. This is static for now.
        """
        return [
            {
                "prop": "name",
                "name": "",
                "set": "",
                "order": 0
            },
            {
                "prop": "currentBook",
                "name": "Current Book",
                "set": "",
                "order": 1
            },
            {
                "prop": "concept",
                "name": "Concept of Word",
                "set": "comprehensionSkills",
                "order": 2
            },
            {
                "prop": "sight",
                "name": "Sight Vocabulary",
                "set": "comprehensionSkills",
                "order": 3
            },
            {
                "prop": "recallPictureText",
                "name": "Recall: Pictures & Text",
                "set": "comprehensionSkills",
                "order": 4
            },
            {
                "prop": "text",
                "name": "Recall: Text Only",
                "set": "comprehensionSkills",
                "order": 5
            },
            {
                "prop": "sequencingPictures",
                "name": "Sequencing: Pictures & Text",
                "set": "comprehensionSkills",
                "order": 6
            },
            {
                "prop": "sequencingText",
                "name": "Sequencing: Text Only",
                "set": "comprehensionSkills",
                "order": 7
            },
            {
                "prop": "id",
                "name": "",
                "set": "",
                "order": 8
            },
            {
                "prop": "currentLevel",
                "name": "Current Level",
                "set": "",
                "order": 9
            },
            {
                "prop": "auditory",
                "name": "Auditory Recognition",
                "set": "phonologicalSkills",
                "order": 10
            },
            {
                "prop": "alphabet",
                "name": "Alphabet Knowledge",
                "set": "phonologicalSkills",
                "order": 11
            },
            {
                "prop": "correspondence",
                "name": "Letter Sound Corr.",
                "set": "phonologicalSkills",
                "order": 12
            },
            {
                "prop": "consonants",
                "name": "Identify Consonants",
                "set": "phonologicalSkills",
                "order": 13
            },
            {
                "prop": "vowels",
                "name": "Identify Vowels",
                "set": "phonologicalSkills",
                "order": 14
            },
            {
                "prop": "syllables",
                "name": "Identify Syllables",
                "set": "phonologicalSkills",
                "order": 15
            },
            {
                "prop": "blending",
                "name": "Blending",
                "set": "phonologicalSkills",
                "order": 16
            }
        ]