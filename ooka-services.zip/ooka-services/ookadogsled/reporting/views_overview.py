import datetime
from .views import BaseTableNavElasticSearchReportView


class OverviewScoreTimeTableNavView(BaseTableNavElasticSearchReportView):
    """
    # O1 - Left table nav Overview API view
    # Returns name average score, average time
    https://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/
    """

    def columns_info(self):
        header_label = self.table_header_label_map[self.query_param]
        return [
            {'prop': 'overview', 'name': header_label, 'smName': header_label, 'units': ''},
            {'prop': 'score', 'name': 'Score', 'smName': 'Score', 'units': ''},
            {'prop': 'time', 'name': 'Avg Time', 'dir': 'desc', 'smName': 'Time', 'units': '%'},
            {'prop': 'id', 'name': 'Id', 'smName': 'Id', 'units': ''}
        ]

    def es_query(self, student_ids_groups):
        """
        Take the basic Students Filters Aggregation query and add the things we
        wish to return in each Students bucket
        :param student_ids_groups:
        :return:
        """
        # @TODO Pull the school year from the organization record?
        start = datetime.datetime(year=2017, month=9, day=1)
        end = datetime.datetime(year=2018, month=6, day=30)

        query = self.es_base_query()
        query = self.es_query_students_bucket_filters_aggregation(query, student_ids_groups)
        query = self.es_score_filter_date_bounds(query, start, end)

        query["aggs"]["students"]["aggs"]["by_session"] = {
            "terms": {
                "field": "session_key",
                "size": 500 * 1000 * 1000  # 1 billion records, good for 50,000 users finishing the game
            },
            "aggs": {
                "session_ended": {
                    "max": {
                        "field": "created",
                        "format": "epoch_second"
                    }
                },
                "session_started": {
                    "min": {
                        "field": "created",
                        "format": "epoch_second"
                    }
                },
                "session_time": {
                    "bucket_script": {
                        "buckets_path": {
                            "start": "session_started",
                            "end": "session_ended"
                        },
                        "script": "params.end - params.start"
                    }
                }
            }
        }
        query["aggs"]["students"]["aggs"]["sessions_total"] = {
            "sum_bucket": {
                "buckets_path": "by_session>session_time"
            }
        }
        query["aggs"]["students"]["aggs"]["correct_total"] = {
            "sum": {
                "field": "score"
            }
        }
        return query

    def get_data(self):
        student_ids_groups = self.student_ids_groups()
        data = super(OverviewScoreTimeTableNavView, self).get_data()
        data['table']['metricTitle'] = 'Overview'
        data['table']['tableTitle'] = '%ss' % self.table_header_label_map[self.query_param]

        query = self.es_query(self.student_ids_groups())
        results = self.es_score_request(query)

        rows = []
        for k, cohort in enumerate(student_ids_groups):
            total_time = results['aggregations']['students']['buckets'][k]['sessions_total']['value'] / 1000 / 60
            distinct_students = results['aggregations']['students']['buckets'][k]['distinct_students']['value']
            total_attempts = results['aggregations']['students']['buckets'][k]['doc_count']
            correct_total = results['aggregations']['students']['buckets'][k]['correct_total']['value']
            if distinct_students > 0:
                time_per_student = round(total_time / distinct_students)
                score_avg = correct_total / total_attempts
            else:
                time_per_student = 0
                score_avg = 0

            rows.append(
                {
                    'id': cohort['id'],
                    'name': cohort['name'],
                    'time': time_per_student,
                    'score': score_avg
                }
            )
        data['table']['rows'] = rows
        return data
