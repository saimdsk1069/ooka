import datetime
from .views import BaseElasticSearchReportView, BaseTableNavElasticSearchReportView


class ComprehensionTableView(BaseTableNavElasticSearchReportView):
    """
    # C1 - Left table nav Phonological API view
    # Returns name, average level, and average score
    https://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/getPhonologicalTable
    """

    def columns_info(self):
        return [
            {'prop': 'name', 'name': self.table_header_label_map[self.query_param], 'order': 1},
            {'prop': 'book', 'name': 'Level', 'order': 2},
            {'prop': 'score', 'name': 'Score', 'order': 3},
        ]

    def es_book_progress_query(self, student_ids_groups):
        """
        Take the basic Students Filters Aggregation query and add the things we
        wish to return in each Students bucket for Book progress
        :param student_ids_groups:
        :return: query dict
        """
        # @TODO Pull the school year from the organization record?
        start = datetime.datetime(year=2017, month=9, day=1)
        end = datetime.datetime(year=2018, month=6, day=30)

        query = self.es_base_query()
        query = self.es_query_students_bucket_filters_aggregation(query, student_ids_groups)
        query = self.es_score_filter_date_bounds(query, start, end)
        query = self.es_query_group_by_dp_id(query)

        # Get the max level number
        query["aggs"]["students"]["aggs"]["by_student"]["aggs"] = {
            "max_book": {
                "max": {
                    "field": "book_id"
                }
            },
        }
        query["aggs"]["students"]["aggs"]["average_max_book"] = {
            "avg_bucket": {
                "buckets_path": "by_student>max_book"
            }
        }
        return query

    def es_score_query(self, student_ids_groups):
        """
        Take the basic Students Filters Aggregation query and add the things we
        wish to return in each Students bucket
        :param student_ids_groups:
        :return: query dict
        """
        # @TODO Pull the school year from the organization record?
        start = datetime.datetime(year=2017, month=9, day=1)
        end = datetime.datetime(year=2018, month=6, day=30)

        query = self.es_base_query()
        query = self.es_query_students_bucket_filters_aggregation(query, student_ids_groups)
        query = self.es_score_filter_date_bounds(query, start, end)
        query = self.es_query_group_by_dp_id(query)
        query = self.es_query_correct_total(query)

        # Get the max level number
        query["aggs"]["students"]["aggs"]["by_student"]["aggs"] = {
            "max_level": {
                "max": {
                    "field": "activity_level_level_number"
                }
            },
        }
        query["aggs"]["students"]["aggs"]["average_level"] = {
            "avg_bucket": {
                "buckets_path": "by_student>max_level"
            }
        }
        return query

    def get_data(self):
        student_ids_groups = self.student_ids_groups()
        data = super(ComprehensionTableView, self).get_data()
        data['table']['metricTitle'] = 'Overview'
        data['table']['tableTitle'] = '%ss' % self.table_header_label_map[self.query_param]

        score_query = self.es_score_query(student_ids_groups)
        score_results = self.es_score_request(score_query)

        book_query = self.es_book_progress_query(student_ids_groups)
        book_results = self.es_book_progress_request(book_query)

        rows = []
        for k, cohort in enumerate(student_ids_groups):
            total_attempts = score_results['aggregations']['students']['buckets'][k]['doc_count']
            correct_total = score_results['aggregations']['students']['buckets'][k]['correct_total']['value']
            average_recent_level = book_results['aggregations']['students']['buckets'][k]['average_max_book']['value']

            if average_recent_level:
                book_level = round(average_recent_level) if average_recent_level > 1 else 0
                score = correct_total / total_attempts if total_attempts > 0 else 0
            else:
                book_level = 0
                score = 0
            rows.append(
                {
                    'id': cohort['id'],
                    'name': cohort['name'],
                    'score': score,
                    'book': '%d/85' % book_level
                }
            )
        data['table']['rows'] = rows
        return data


class PhonologicalTableView(BaseTableNavElasticSearchReportView):
    """
    # P1 - Left table nav Phonological API view
    # Returns name, average level, and average score
    https://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/getPhonologicalTable
    """
    def columns_info(self):
        return [
            {'prop': 'name', 'name': self.table_header_label_map[self.query_param], 'order': 1},
            {'prop': 'book', 'name': 'Level', 'order': 2},
            {'prop': 'score', 'name': 'Score', 'order': 3},
        ]

    def es_query(self, student_ids_groups):
        """
        Take the basic Students Filters Aggregation query and add the things we
        wish to return in each Students bucket
        :param student_ids_groups:
        :return:
        """
        # @TODO Pull the school year from the organization record?
        start = datetime.datetime(year=2017, month=9, day=1)
        end = datetime.datetime(year=2018, month=6, day=30)

        query = self.es_base_query()
        query = self.es_query_students_bucket_filters_aggregation(query, student_ids_groups)
        query = self.es_score_filter_date_bounds(query, start, end)
        query = self.es_query_group_by_dp_id(query)
        query = self.es_query_correct_total(query)

        # Grouping by dp_id, get the max level number
        query["aggs"]["students"]["aggs"]["by_student"]["aggs"] = {
            "max_level": {
                "max": {
                    "field": "activity_level_level_number"
                }
            },
        }
        query["aggs"]["students"]["aggs"]["average_level"] = {
            "avg_bucket": {
                "buckets_path": "by_student>max_level"
            }
        }
        return query

    def get_data(self):
        student_ids_groups = self.student_ids_groups()
        data = super(PhonologicalTableView, self).get_data()
        data['table']['metricTitle'] = 'Overview'
        data['table']['tableTitle'] = '%ss' % self.table_header_label_map[self.query_param]

        query = self.es_query(self.student_ids_groups())
        results = self.es_score_request(query)
        rows = []
        for k, cohort in enumerate(student_ids_groups):
            total_attempts = results['aggregations']['students']['buckets'][k]['doc_count']
            correct_total = results['aggregations']['students']['buckets'][k]['correct_total']['value']
            average_recent_level = results['aggregations']['students']['buckets'][k]['average_level']['value']
            if average_recent_level:
                level = round(average_recent_level - 1) if average_recent_level > 1 else 0
                score = correct_total / total_attempts if total_attempts > 0 else 0
            else:
                level = 0
                score = 0
            rows.append(
                {
                    'id': cohort['id'],
                    'name': cohort['name'],
                    'score': score,
                    'level': '%d/24' % level
                }
            )
        data['table']['rows'] = rows
        return data


class BaseSkillGradesScoresView(BaseElasticSearchReportView):
    """
    For C2 and P2
    Base view class for creating Comprehension and Phonological skill performance distribution data
    """
    cohort_label = 'no-label'

    # Overriding this to add default
    grade_name_mapping = {
        'default': "All Grades",
        'k': "Kindergarten",
        '1': "First Grade",
        '2': "Second Grade",
        '3': "Third Grade",
    }
    skills_type = None
    skills = [
        "auditory", "alphabet", "correspondence", "consonants", "vowels", "syllables", "blending",
        "concept", "sight", "text", "recallPictureText", "sequencingPictures", "sequencingText"
    ]

    def es_query_aggregate(self, student_ids):
        """
        Aggregate for one list of student_ids
        :param student_ids: dict with key student_ids = list of integers
        :return: query dict
        """
        # @TODO Pull the school year from the organization record?
        start = datetime.datetime(year=2017, month=9, day=1)
        end = datetime.datetime(year=2018, month=6, day=30)

        query = self.es_base_query()
        query = self.es_query_students_bucket_filters_aggregation(query, student_ids)

        if self.skills_type:
            query["query"]["bool"]["must"].append({
                "term": {
                    "skill_type": self.skills_type
                }
            })
        else:
            query["query"]["bool"]["must_not"].append({
                "term": {
                    "skill_label": ""
                }
            })

        # filter by date range
        query = self.es_score_filter_date_bounds(query, start, end)

        query["aggs"]["students"]["aggs"] = {
            "by_label": {
                "terms": {
                    "field": "skill_label"
                },
                "aggs": {
                    "skill_avg": {
                        "avg": {
                            "field": "score"
                        }
                    }
                }
            }
        }
        return query

    def aggregate_scores_performance(self, student_ids):
        """
        Returns skill score performance for a group of students by student id
        :param student_ids: dict with a key student_ids = list of Student dp ids
        :return: Skill scores performance ES response for all students in the list
        """
        query = self.es_query_aggregate(student_ids)
        results = self.es_score_request(query)
        cohorts_by_grade_by_skill = {}

        for k, grade_group in enumerate(student_ids):
            cohorts_by_grade_by_skill[grade_group['grade']] = {}
            for skill in self.skills:
                cohorts_by_grade_by_skill[grade_group['grade']][skill] = 0
            for label_performance in results['aggregations']['students']['buckets'][k]['by_label']['buckets']:
                skill_key = label_performance['key']
                cohorts_by_grade_by_skill[grade_group['grade']][skill_key] = label_performance['skill_avg']['value']
        return cohorts_by_grade_by_skill

    def get_students_scores_data(self, student_ids):
        """
        Returns skill performance data for a group of students by student id
        :param dp_ids: list of Student dp ids
        :return: skill performance cohorts for all students in the list
        """
        results_by_grade_by_skill = self.aggregate_scores_performance(student_ids)
        data = {}
        grade_ct = 0
        grades_overall = {}
        for skill in self.skills:
            data[skill] = {}

            if skill not in grades_overall:
                grades_overall[skill] = 0

            grade_ct = 0
            for grade, value in results_by_grade_by_skill.items():
                performance = int(value[skill] * 100)
                data[skill][grade] = performance
                grades_overall[skill] += performance
                grade_ct += 1

        # Fold in summaries for all districts
        for skill, values in grades_overall.items():
            score = round(grades_overall[skill] / grade_ct) if grade_ct > 0 else 0
            data[skill]['default'] = score
        return data

    def get_data(self):
        """
        :param query_param: string of the record type considered to filter students
        :param value: id value of the record
        :return:
        """
        data = super(BaseSkillGradesScoresView, self).get_data()
        data['gradeLabels'] = self.grade_name_mapping
        data['labels'] = self.skill_labels_map.get(self.skills_type, {})
        data['cohorts'].append({
            self.cohort_label: {}
        })
        data['cohorts'][0]['cohortType'] = self.cohort_type_mapping[self.query_param]
        student_ids_grades_groups = self.student_ids_grades_groups()
        data['cohorts'][0]['cohortId'] = self.filter_record.id
        data['cohorts'][0]['name'] = self.filter_record.name
        data['cohorts'][0][self.cohort_label] = self.get_students_scores_data(student_ids_grades_groups)
        return data


class ComprehensionSkillGradesScoresView(BaseSkillGradesScoresView):
    """
    C2
    https://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/getComprehensionScores
    """
    cohort_label = 'comprehensionScores'
    skills_type = 'comprehension'
    skills = [
        "concept", "sight", "text", "recallPictureText", "sequencingPictures", "sequencingText"
    ]


class PhonologicalSkillScoresView(BaseSkillGradesScoresView):
    """
    P2
    https://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/getPhonologicalScores
    """
    cohort_label = 'phonologicalScores'
    skills_type = 'phonological'
    skills = [
        "auditory", "alphabet", "correspondence", "consonants", "vowels", "syllables", "blending"
    ]


class BaseSkillDistributionView(BaseElasticSearchReportView):
    """
    For C3 and P3
    Base view class for creating Comprehension and Phonological skill performance distribution data
    """
    cohort_label = 'no-label'
    # Overriding this to add default
    grade_name_mapping = {
        'default': "All Grades",
        'k': "Kindergarten",
        '1': "First Grade",
        '2': "Second Grade",
        '3': "Third Grade",
    }
    skills_type = None
    skills = [
        "auditory", "alphabet", "correspondence", "consonants", "vowels", "syllables", "blending",
        "concept", "sight", "text", "recallPictureText", "sequencingPictures", "sequencingText"
    ]

    def skills_averages_for_student(self, dp_id):
        """
        Returns skill performance averages for one student by student id
        :param dp_id: int, Student dp_id
        :return: Phonological skill performance averages by skill
        """
        query = self.es_base_query()

        # filter by all students, not a lists of students lists
        query["query"]["bool"]["must"].append({
            "term": {
                "dp_id": dp_id
            }
        })
        if self.skills_type:
            query["query"]["bool"]["must"].append({
                "term": {
                    "skill_type": self.skills_type
                }
            })

        # filter by date range
        # @TODO Pull the school year from the organization record?
        start = datetime.datetime(year=2017, month=9, day=1)
        end = datetime.datetime(year=2018, month=6, day=30)
        query = self.es_score_filter_date_bounds(query, start, end)

        query["aggs"] = {
            "by_label": {
                "terms": {
                    "field": "skill_label"
                },
                "aggs": {
                    "skill_avg": {
                        "avg": {
                            "field": "score"
                        }
                    }
                }
            }
        }

        skill_averages = {}
        for skill in self.skills:
            skill_averages[skill] = 0
        results = self.es_score_request(query)

        for skill in results['aggregations']['by_label']['buckets']:
            skill_label = skill['key']
            skill_averages[skill_label] = skill['skill_avg']['value']
        return skill_averages

    def es_query_aggregate(self, student_ids):
        """
        Aggregate for one list of student_ids
        :param student_ids: dict with key student_ids = list of integers
        :return: query dict
        """
        # @TODO Pull the school year from the organization record?
        start = datetime.datetime(year=2017, month=9, day=1)
        end = datetime.datetime(year=2018, month=6, day=30)

        query = self.es_base_query()

        # filter by all students, not a lists of students lists
        query["query"]["bool"]["must"].append({
            "terms": {
                "dp_id": student_ids['student_ids']
            }
        })
        if self.skills_type:
            query["query"]["bool"]["must"].append({
                "term": {
                    "skill_type": self.skills_type
                }
            })
        else:
            query["query"]["bool"]["must_not"].append({
                "term": {
                    "skill_label": ""
                }
            })

        # filter by date range
        query = self.es_score_filter_date_bounds(query, start, end)

        query["aggs"]["students"] = {
            "terms": {
                "field": "dp_id"
            },
            "aggs": {
                "by_label": {
                    "terms": {
                        "field": "skill_label"
                    },
                    "aggs": {
                        "skill_avg": {
                            "avg": {
                                "field": "score"
                            }
                        },
                        "skill_performance": {
                            "bucket_script": {
                                "buckets_path": {
                                    "skill_avg": "skill_avg.value"
                                },
                                # 0 == learning
                                # 1 == practicing
                                # 2 == proficient
                                "script": "if (params.skill_avg < 0.6) return 0;  if (params.skill_avg < 0.7) return 1; return 2;"
                            }
                        }
                    }
                }
            }
        }
        return query

    def aggregate_skills_performance(self, student_ids):
        """
        Returns phonological skill performance for a group of students by student id
        :param student_ids: dict with a key student_ids = list of Student dp ids
        :return: Phonological skill performance ES response for all students in the list
        """
        query = self.es_query_aggregate(student_ids)
        results = self.es_score_request(query)
        cohorts_by_skill = {}
        for skill in self.skills:
            cohorts_by_skill[skill] = {
                'learning': 0,
                'practicing': 0,
                'proficient': 0
            }
        performance_map = {
            0: 'learning',
            1: 'practicing',
            2: 'proficient'
        }
        for student in results['aggregations']['students']['buckets']:
            for label_agg in student['by_label']['buckets']:
                label_key = label_agg['key']
                label_performance = int(label_agg['skill_performance']['value'])
                performance_label = performance_map[label_performance]
                cohorts_by_skill[label_key][performance_label] += 1
        return cohorts_by_skill

    def get_students_skills_data(self, student_ids):
        """
        Returns skill performance data for a group of students by student id
        :param dp_ids: list of Student dp ids
        :return: skill performance cohorts for all students in the list
        """
        results_by_skill = self.aggregate_skills_performance(student_ids)
        data = {}
        for skill in results_by_skill:
            data[skill] = {}
            # default = all grades. Future consideration: filter the results,
            # or perform a nested aggregation, to get results by grade.
            data[skill] = {
                'default': {
                    'learning': results_by_skill[skill]['learning'],
                    'proficient': results_by_skill[skill]['proficient'],
                    'practicing': results_by_skill[skill]['practicing']
                }
            }
        return data

    def get_students_skills_data_one_student(self, student_ids, dp_id):
        """
        Returns phonological skill performance data for a group of students by student ids,
        overlaid with the averages of just one student
        :param dp_ids: list of Student dp id ints
        :param dp_id: int Student dp id
        :return: Phonological skill performance for all students in the list overlaid with the results for one student
        """
        results_by_skill = self.aggregate_skills_performance(student_ids)
        phonological_skills_for_student = self.skills_averages_for_student(dp_id)
        data = {}
        for skill in results_by_skill:
            data[skill] = {
                'learning': results_by_skill[skill]['learning'],
                'proficient': results_by_skill[skill]['proficient'],
                'practicing': results_by_skill[skill]['practicing'],
                'position': phonological_skills_for_student[skill]
            }
        return data

    def get_data(self):
        """
        :param query_param: string of the record type considered to filter students
        :param value: id value of the record
        :return:
        """
        data = super(BaseSkillDistributionView, self).get_data()
        data['gradeLabels'] = self.grade_name_mapping
        data['cohorts'].append({
            self.cohort_label: {}
        })
        data['cohorts'][0]['cohortType'] = self.cohort_type_mapping[self.query_param]
        data['labels'] = self.skill_labels_map[self.skills_type]

        student_ids = self.student_ids()
        if self.query_param == 'studentId':
            data['cohorts'][0]['cohortId'] = self.student.id
            data['cohorts'][0]['name'] = self.student.name
            data['cohorts'][0][self.cohort_label] =\
                self.get_students_skills_data_one_student(student_ids, self.student.id)
        else:
            data['cohorts'][0]['cohortId'] = student_ids['id']
            data['cohorts'][0]['name'] = student_ids['name']
            data['cohorts'][0][self.cohort_label] = self.get_students_skills_data(student_ids)
        return data


class ComprehensionSkillDistributionView(BaseSkillDistributionView):
    """
    C3
    https://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/getComprehensionSkillDistribution
    """
    cohort_label = 'comprehensionDistribution'
    skills_type = 'comprehension'
    skills = [
        "concept", "sight", "text", "recallPictureText", "sequencingPictures", "sequencingText"
    ]


class PhonologicalSkillDistributionView(BaseSkillDistributionView):
    """
    P3
    https://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/getPhonologicalSkillDistribution
    """
    cohort_label = 'phonologicalDistribution'
    skills_type = 'phonological'
    skills = [
        "auditory", "alphabet", "correspondence", "consonants", "vowels", "syllables", "blending"
    ]


class BaseSkillProgressView(BaseElasticSearchReportView):
    skills_type = None

    def es_query(self, student_ids):
        """
        Common requirements between both skill progress views.
        :param student_ids: dict with key student_ids: list of ints
        :return:
        """
        query = self.es_base_query()

        # One group of students
        query["query"]["bool"]["must"].append({
            "terms": {
                "dp_id": student_ids['student_ids']
            }
        })

        # One Skills type, or at least not blank
        if self.skills_type:
            query["query"]["bool"]["must"].append({
                "term": {
                    "skill_type": self.skills_type
                }
            })
        else:
            query["query"]["bool"]["must_not"].append({
                "term": {
                    "skill_label": ""
                }
            })
        return query

    def get_data(self):
        data = super(BaseSkillProgressView, self).get_data()
        data['labels'] = self.skill_labels_map[self.skills_type]
        return data


class PhonologicalProgressView(BaseSkillProgressView):
    """
    https://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/getPhonologicalProgress
    """
    skills_type = 'phonological'
    skills = [
        "auditory", "alphabet", "correspondence", "consonants", "vowels", "syllables", "blending"
    ]

    def es_query(self, student_ids):
        query = super(PhonologicalProgressView, self).es_query(student_ids)
        # Group by level
        query['aggs']['by_skill'] = {
            'terms': {
                'field': 'skill_label'
            },
            'aggs': {
                'by_level': {
                    'terms': {
                        'field': 'activity_level_level_number'
                    },
                    'aggs': {
                        'score_avg': {
                            'avg': {
                                'field': 'score'
                            }
                        },
                        "distinct_students": {
                            "cardinality": {
                                "field": "dp_id"
                            }
                        }
                    }
                }
            }
        }
        return query

    def get_aggregate(self, student_ids):
        """
        Queries Elastic Search and returns a map of activity levels and the corresponding percentage average
        :param student_ids:
        :return: dict of skills, thier levels average, and the distinct count of students
        """
        query = self.es_query(student_ids)
        results = self.es_score_request(query)
        activity_level_map = {}

        for skill_agg in results['aggregations']['by_skill']['buckets']:
            skill_key = skill_agg['key']
            activity_level_map[skill_key] = {}
            for level_agg in skill_agg['by_level']['buckets']:
                activity_level_map[skill_key][level_agg['key']] = {
                    'average': level_agg['score_avg']['value'],
                    'students_ct': level_agg['distinct_students']['value']

                }
        return activity_level_map

    def get_data(self):
        """
        :return: data dict
        """
        data = super(PhonologicalProgressView, self).get_data()
        student_ids = self.student_ids()
        aggregate = self.get_aggregate(student_ids)

        data['metrics'] = {}
        cohort = {
            'cohortType': self.cohort_type_mapping[self.query_param],
            'phonologicalProgress': {}
        }
        for skill in self.skills:
            data['metrics'][skill] = 0
            cohort['phonologicalProgress'][skill] = {
                'default': []
            }
            level_ct = 0
            for level in aggregate.get(skill, {}):
                level_data = aggregate[skill].get(level, {'average': 0, 'students_ct': 0})
                level_value = round(level_data['average'] * 100)
                cohort['phonologicalProgress'][skill]['default'].append({
                    'level': level,
                    'value': level_value,
                    'callout': {
                        'completedBy': level_data['students_ct']
                    }
                })
                data['metrics'][skill] += level_value
                level_ct += 1
            data['metrics'][skill] = round(data['metrics'][skill] / level_ct) if level_ct > 0 else 0
        data['cohorts'].append(cohort)
        return data


