import datetime
from dateutil.rrule import rrule, MONTHLY, DAILY
from .views import BaseElasticSearchReportView, BaseTableNavElasticSearchReportView


class TimePlayedTableNavView(BaseTableNavElasticSearchReportView):
    """
    # T1 - Left table nav time played API view
    https://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/getTimePlayedTableNav
    """
    def columns_info(self):
        return [
            {'prop': 'name', 'name': self.table_header_label_map[self.query_param], 'order': 1},
            {'prop': 'time', 'name': 'Total', 'order': 2},
            {'prop': 'avgTimePerStudent', 'name': 'Avg Minutes Per Student', 'order': 3},
        ]

    def es_query(self, student_ids_groups):
        """
        Take the basic Students Filters Aggregation query and add the things we
        wish to return in each Students bucket
        :param student_ids_groups:
        :return:
        """
        # @TODO Pull the school year from the organization record?
        start = datetime.datetime(year=2017, month=9, day=1)
        end = datetime.datetime(year=2018, month=6, day=30)

        query = self.es_base_query()
        query = self.es_query_students_bucket_filters_aggregation(query, student_ids_groups)
        query = self.es_score_filter_date_bounds(query, start, end)

        query["aggs"]["students"]["aggs"]["by_session"] = {
            "terms": {
                "field": "session_key",
                "size": 500 * 1000 * 1000  # 500 million records, good for 50,000 users finishing the game
            },
            "aggs": {
                "session_ended": {
                    "max": {
                        "field": "created",
                        "format": "epoch_second"
                    }
                },
                "session_started": {
                    "min": {
                        "field": "created",
                        "format": "epoch_second"
                    }
                },
                "session_time": {
                    "bucket_script": {
                        "buckets_path": {
                            "start": "session_started",
                            "end": "session_ended"
                        },
                        "script": "params.end - params.start"
                    }
                }
            }
        }
        query["aggs"]["students"]["aggs"]["sessions_total"] = {
            "sum_bucket": {
                "buckets_path": "by_session>session_time"
            }
        }
        return query

    def get_data(self, *args, **kwargs):
        student_ids_groups = self.student_ids_groups()
        data = super(TimePlayedTableNavView, self).get_data()
        query = self.es_query(self.student_ids_groups())
        results = self.es_score_request(query)
        # @TODO data['table']['cohortSummary'] was a thing - not sure if needed anymore?
        rows = []

        for k, cohort in enumerate(student_ids_groups):
            if 'aggregations' in results:
                total_time = results['aggregations']['students']['buckets'][k]['sessions_total']['value'] / 1000 / 60  # minutes
                distinct_students = results['aggregations']['students']['buckets'][k]['distinct_students']['value']
                avg_time = round(total_time / distinct_students) if distinct_students > 0 else 0
            else:
                total_time = 0
                avg_time = 0
            rows.append(
                {
                    'id': cohort['id'],
                    'name': cohort['name'],
                    'time': round(total_time),
                    'avgTimePerStudent': avg_time
                }
            )
        data['table']['rows'] = rows
        return data


class BaseTimePlayedByLocationByPeriod(BaseElasticSearchReportView):
    """
    Shared attributes between TimePlayedByLocationByPeriod and TimePlayedByMonthByLocationView
    """
    filters_info = [
        {'prop': 'byMonth', 'name': 'By Month', 'order': 2}
    ]
    labels_info = [
        {'key': 'in', 'name': 'In School', 'order': 0},
        {'key': 'out', 'name': 'Out of School', 'order': 1}
    ]


class TimePlayedByLocationByPeriodView(BaseTimePlayedByLocationByPeriod):
    """
    # T2 - Total Time Spent - in school vs at home
    http://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/getTableTimePlayedPeriodGrouping
    """
    def es_query_sytd_monthly(self, student_ids):
        # @TODO Pull the school year from the organization record?
        start = datetime.datetime(year=2017, month=9, day=1)
        end = datetime.datetime(year=2018, month=6, day=30)

        query = self.es_base_query()

        # filter by all students, not a lists of students lists
        query["query"]["bool"]["must"].append({
            "terms": {
                "dp_id": student_ids['student_ids']
            }
        })

        # filter by date range
        query = self.es_score_filter_date_bounds(query, start, end)

        # date histogram by month
        query["aggs"]["sytd_by_month"] = {
            "date_histogram": {
                "field": "created",
                "interval": "month",
                "format": "MMM"
            },
            "aggs": {
                "by_location": {
                    "terms": {
                        "field": "gameplay_location"
                    },
                    "aggs": {
                        "by_session": {
                            "terms": {
                                "field": "session_key",
                                "size": 500 * 1000 * 1000  # 500 million records, good for 50,000 users finishing the game
                            },
                            "aggs": {
                                "session_ended": {
                                    "max": {
                                        "field": "created",
                                        "format": "epoch_second"
                                    }
                                },
                                "session_started": {
                                    "min": {
                                        "field": "created",
                                        "format": "epoch_second"
                                    }
                                },
                                "session_time": {
                                    "bucket_script": {
                                        "buckets_path": {
                                            "start": "session_started",
                                            "end": "session_ended"
                                        },
                                        "script": "params.end - params.start"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        query["aggs"]["sytd_by_month"]["aggs"]["by_location"]["aggs"]["sessions_total"] = {
            "sum_bucket": {
                "buckets_path": "by_session>session_time"
            }
        }
        return query

    def es_query_last_7_days(self, student_ids):
        query = self.es_base_query()
        # filter by date range
        end = datetime.datetime(year=2018, month=3, day=21)
        start = end - datetime.timedelta(days=6)
        query = self.es_score_filter_date_bounds(query, start, end)

        # filter by all students, not a lists of students lists
        query["query"]["bool"]["must"].append({
            "terms": {
                "dp_id": student_ids['student_ids']
            }
        })

        # date histogram by day
        query["aggs"]["last_7_days"] = {
            "date_histogram": {
                "field": "created",
                "interval": "day",
                "format": "Y-MM-d",  # 2018-4-1
                "min_doc_count": 0,
                "extended_bounds": {
                    "min": start.strftime('%Y-%m-%d'),
                    "max": end.strftime('%Y-%m-%d')
                }
            },
            "aggs": {
                "by_location": {
                    "terms": {
                        "field": "gameplay_location"
                    },
                    "aggs": {
                        "by_session": {
                            "terms": {
                                "field": "session_key",
                                "size": 500 * 1000 * 1000  # 500 million records, good for 50,000 users finishing the game
                            },
                            "aggs": {
                                "session_ended": {
                                    "max": {
                                        "field": "created",
                                        "format": "epoch_second"
                                    }
                                },
                                "session_started": {
                                    "min": {
                                        "field": "created",
                                        "format": "epoch_second"
                                    }
                                },
                                "session_time": {
                                    "bucket_script": {
                                        "buckets_path": {
                                            "start": "session_started",
                                            "end": "session_ended"
                                        },
                                        "script": "params.end - params.start"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        query["aggs"]["last_7_days"]["aggs"]["by_location"]["aggs"]["sessions_total"] = {
            "sum_bucket": {
                "buckets_path": "by_session>session_time"
            }
        }
        return query

    def get_data(self):
        data = super(TimePlayedByLocationByPeriodView, self).get_data()
        data['filters'] = [
            {
                "prop": "last7Days",
                "name": "Last 7 Days",
                "order": 0
            },
            {
                "prop": "SYTD",
                "name": "School Year to Date",
                "order": 1
            }
        ]
        data['last7DaysLabels'] = {}
        data['SYTDLabels'] = {}

        # @TODO Tie this start/end date to the record's school year?
        start_school_year = datetime.datetime(year=2017, month=9, day=1)
        end_school_year = datetime.datetime(year=2018, month=6, day=30)

        student_ids = self.student_ids()

        # Search for School year to date values
        sytd_query = self.es_query_sytd_monthly(student_ids)
        sytd_results = self.es_score_request(sytd_query)

        sytd_periods = {}
        for agg in sytd_results['aggregations']['sytd_by_month']['buckets']:
            month = agg['key_as_string']
            sytd_periods[month] = {'in': 0, 'out': 0}
            for session_location in agg['by_location']['buckets']:
                if session_location['key'] == 'out':
                    sytd_periods[month]['out'] += session_location['sessions_total']['value'] / 1000 / 60
                else:
                    # Blank value counts as "in"
                    sytd_periods[month]['in'] += session_location['sessions_total']['value'] / 1000 / 60

        # Search for last 7 days date values
        last_7_days_query = self.es_query_last_7_days(student_ids)
        last_7_days_results = self.es_score_request(last_7_days_query)
        last_7_days_periods = {}
        for agg in last_7_days_results['aggregations']['last_7_days']['buckets']:
            day = agg['key_as_string']
            last_7_days_periods[day] = {'in': 0, 'out': 0}
            for session_location in agg['by_location']['buckets']:
                if session_location['key'] == 'out':
                    last_7_days_periods[day]['out'] += session_location['sessions_total']['value'] / 1000 / 60
                else:
                    # Blank value counts as "in"
                    last_7_days_periods[day]['in'] += session_location['sessions_total']['value'] / 1000 / 60

        # Assemble the cohort
        cohort = {
            'timePlayed': {},
            'cohortId': student_ids['id'],
            'cohortType': data['cohortType'],
            'name': student_ids['name']
        }
        cohort['timePlayed']['last7days'] = {}
        cohort['timePlayed']['SYTD'] = {}

        # Create the monthly buckets
        for month_dt in [dt for dt in rrule(MONTHLY, dtstart=start_school_year, until=end_school_year)]:
            month = month_dt.strftime('%b')
            data['SYTDLabels'][month] = month
            cohort['timePlayed']['SYTD'][month] = {
                'in': sytd_periods.get(month, {'in': 0})['in'],
                'out': sytd_periods.get(month, {'out': 0})['out']
            }

        # Create the daily buckets
        last_7_days_end = datetime.datetime(year=2018, month=3, day=21)
        last_7_daysstart = last_7_days_end - datetime.timedelta(days=6)

        for day_dt in [dt for dt in rrule(DAILY, dtstart=last_7_daysstart, until=last_7_days_end)]:
            query_day = day_dt.strftime('%Y-%m-%d')
            output_day = day_dt.strftime('%m-%d-%Y')
            data['last7DaysLabels'][output_day] = output_day
            cohort['timePlayed']['last7days'][output_day] = {
                'in': round(last_7_days_periods.get(query_day, {'in': 0})['in']),
                'out': round(last_7_days_periods.get(query_day, {'out': 0})['out'])
            }

        data['cohorts'] = [cohort]
        return data


class TimePlayedByPeriodByGradeView(BaseElasticSearchReportView):
    """
    # T3 - Total Time Spent - monthly or last 7 days - by grade
    http://ookadogsled.dev.micro.scholastic.com/assets/swagger/#/web/@todo
    """
    def es_query_sytd_monthly(self, student_ids_grade_groups):
        """
        Create the Elastic Search query to get time played data grouped by grade and time period
        :param student_ids:
        :return: ES query dict
        """
        # @TODO Pull the school year from the organization record?
        start = datetime.datetime(year=2017, month=9, day=1)
        end = datetime.datetime(year=2018, month=6, day=30)

        query = self.es_base_query()
        query = self.es_query_students_bucket_filters_aggregation(query, student_ids_grade_groups)

        # filter by date range
        query = self.es_score_filter_date_bounds(query, start, end)

        # date histogram by month
        query["aggs"]["students"]["aggs"]["sytd_by_month"] = {
            "date_histogram": {
                "field": "created",
                "interval": "month",
                "format": "MMM"
            },
            "aggs": {
                "by_session": {
                    "terms": {
                        "field": "session_key",
                        "size": 500 * 1000 * 1000  # 500 million records, good for 50,000 users finishing the game
                    },
                    "aggs": {
                        "session_ended": {
                            "max": {
                                "field": "created",
                                "format": "epoch_second"
                            }
                        },
                        "session_started": {
                            "min": {
                                "field": "created",
                                "format": "epoch_second"
                            }
                        },
                        "session_time": {
                            "bucket_script": {
                                "buckets_path": {
                                    "start": "session_started",
                                    "end": "session_ended"
                                },
                                "script": "params.end - params.start"
                            }
                        }
                    }
                }
            }
        }
        query["aggs"]["students"]["aggs"]["sytd_by_month"]["aggs"]["sessions_total"] = {
            "sum_bucket": {
                "buckets_path": "by_session>session_time"
            }
        }
        return query

    def es_query_last_7_days(self, student_ids_grade_groups):
        # filter by date range
        end = datetime.datetime(year=2018, month=3, day=21)
        start = end - datetime.timedelta(days=6)

        # filter by all students, not a lists of students lists
        query = self.es_base_query()
        query = self.es_query_students_bucket_filters_aggregation(query, student_ids_grade_groups)

        # date histogram by day
        query["aggs"]["students"]["aggs"]["last_7_days"] = {
            "date_histogram": {
                "field": "created",
                "interval": "day",
                "format": "Y-MM-d",  # 2018-4-1
                "min_doc_count": 0,
                "extended_bounds": {
                    "min": start.strftime('%Y-%m-%d'),
                    "max": end.strftime('%Y-%m-%d')
                }
            },
            "aggs": {
                "by_session": {
                    "terms": {
                        "field": "session_key",
                        "size": 500 * 1000 * 1000  # 500 million records, good for 50,000 users finishing the game
                    },
                    "aggs": {
                        "session_ended": {
                            "max": {
                                "field": "created",
                                "format": "epoch_second"
                            }
                        },
                        "session_started": {
                            "min": {
                                "field": "created",
                                "format": "epoch_second"
                            }
                        },
                        "session_time": {
                            "bucket_script": {
                                "buckets_path": {
                                    "start": "session_started",
                                    "end": "session_ended"
                                },
                                "script": "params.end - params.start"
                            }
                        }
                    }
                }
            }
        }

        query["aggs"]["students"]["aggs"]["last_7_days"]["aggs"]["sessions_total"] = {
            "sum_bucket": {
                "buckets_path": "by_session>session_time"
            }
        }
        return query

    def get_data(self):
        data = super(TimePlayedByPeriodByGradeView, self).get_data()
        data['filters'] = [
            {
                "prop": "last7Days",
                "name": "Last 7 Days",
                "order": 0
            },
            {
                "prop": "SYTD",
                "name": "School Year to Date",
                "order": 1
            }
        ]
        data['last7DaysLabels'] = {}
        data['SYTDLabels'] = {}

        # @TODO Tie this start/end date to the record's school year?
        start_school_year = datetime.datetime(year=2017, month=9, day=1)
        end_school_year = datetime.datetime(year=2018, month=6, day=30)

        student_ids_grade_groups = self.student_ids_grades_groups(top_level_group=False)

        # Search for School year to date values
        sytd_query = self.es_query_sytd_monthly(student_ids_grade_groups)
        sytd_results = self.es_score_request(sytd_query)
        sytd_periods = {}
        for grade_k, agg in enumerate(sytd_results['aggregations']['students']['buckets']):
            grade = student_ids_grade_groups[grade_k]
            for month_bucket in agg['sytd_by_month']['buckets']:
                month = month_bucket['key_as_string']
                grade_key = grade['grade']
                if month not in sytd_periods:
                    sytd_periods[month] = {}
                time_played = round(month_bucket['sessions_total']['value'] / 1000 / 60)
                sytd_periods[month][self.grade_name_mapping.get(grade_key.lower())] = time_played

        # Search for last 7 days date values
        last_7_days_query = self.es_query_last_7_days(student_ids_grade_groups)
        last_7_days_results = self.es_score_request(last_7_days_query)
        last_7_days_periods = {}
        for grade_k, agg in enumerate(last_7_days_results['aggregations']['students']['buckets']):
            grade = student_ids_grade_groups[grade_k]
            for day_bucket in agg['last_7_days']['buckets']:
                day = day_bucket['key_as_string']
                grade_key = grade['grade']
                if day not in last_7_days_periods:
                    last_7_days_periods[day] = {}
                time_played = round(day_bucket['sessions_total']['value'] / 1000 / 60)
                last_7_days_periods[day][self.grade_name_mapping.get(grade_key.lower())] = time_played

        # Assemble the cohort
        cohort = {
            'timePlayed': {
                'last7days': {},
                'SYTD': {}
            }
        }

        # Creat the monthly buckets
        for month_dt in [dt for dt in rrule(MONTHLY, dtstart=start_school_year, until=end_school_year)]:
            month = month_dt.strftime('%b')
            data['SYTDLabels'][month] = month
            cohort['timePlayed']['SYTD'][month] = sytd_periods.get(month, {})

        # # Create the daily buckets
        last_7_days_end = datetime.datetime(year=2018, month=3, day=21)
        last_7_daysstart = last_7_days_end - datetime.timedelta(days=6)

        for day_dt in [dt for dt in rrule(DAILY, dtstart=last_7_daysstart, until=last_7_days_end)]:
            query_day = day_dt.strftime('%Y-%m-%d')
            output_day = day_dt.strftime('%m-%d-%Y')
            data['last7DaysLabels'][output_day] = output_day
            cohort['timePlayed']['last7days'][output_day] = last_7_days_periods.get(query_day, 0)

        data['cohorts'] = [cohort]
        return data
