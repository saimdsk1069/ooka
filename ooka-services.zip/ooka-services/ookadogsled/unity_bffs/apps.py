from django.apps import AppConfig


class UnityBffsConfig(AppConfig):
    name = 'unity_bffs'
