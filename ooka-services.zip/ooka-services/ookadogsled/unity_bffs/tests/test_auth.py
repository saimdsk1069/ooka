import json
import uuid
from django.conf import settings
from django.test import TestCase
from django.shortcuts import reverse
from sdm_authentication.models import LTILaunchRequest
from sdm_authentication.utils import jwt_decode
from gameplay.models import GameplayLocation, GameUser, GameUserUnitySession, Region

TOKEN_NO_GAMEUSER = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzb21lIjoib2JqZWN0In0.J-f_qC4KBLlVAabjCnE3_anASaObvZzQ9g8nFMA5FO8'
VALID_TOKEN = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzb21lIjoib2JqZWN0IiwiZ2FtZVVzZXJJZCI6MX0.' \
    '2p5aH8CsyuGWdx8D4MQJ6G21horG19xmnyZWOlVyJwU'

TEST_CUSTOM_DP_LAUNCH = {'orgContext': {'organization': {'id': 12, 'parent': 34, 'orgType': 'school'}, 'roles': 'student'}}
TEST_LTI = {'user_id': 12345, 'roles': 'test', 'custom_dp_launch': json.dumps(TEST_CUSTOM_DP_LAUNCH)}


class AuthTestCase(TestCase):
    """
    Test the Unity auth system
    """
    def setUp(self):
        self.game_user = GameUser.objects.create(dp_id=1, dp_role='student')
        if not LTILaunchRequest.exists():
            LTILaunchRequest.create_table(wait=True)

    def tearDown(self):
        # Delete stored request for GameUser 1
        try:
            gsa = LTILaunchRequest.get(self.game_user.id)
            gsa.delete()
        except LTILaunchRequest.DoesNotExist:
            pass

    def test_jwt_service_options_success(self):
        """
        Test that we can have preflight options
        """
        response = self.client.options(reverse("unity_bffs:auth-jwt"))
        self.assertEqual(response.status_code, 200)

    def test_jwt_service_bad_requests(self):
        """
        Test the success response of the service called to retrieve JWT
        """
        # Invalid JSON
        response = self.client.post(reverse('unity_bffs:auth-jwt'), 'nothing', content_type="application/json")
        self.assertEqual(response.status_code, 400)

        # Empty JSON
        response = self.client.post(reverse('unity_bffs:auth-jwt'), json.dumps({}), content_type="application/json")
        self.assertEqual(response.status_code, 400)

        # Unknown auth token
        data = json.dumps({"authToken": str(uuid.uuid4())})
        response = self.client.post(reverse('unity_bffs:auth-jwt'), data, content_type="application/json")
        self.assertEqual(response.status_code, 404)

        # Bad auth token
        data = json.dumps({"authToken": '3dd6aec-c6cf-4344-b625-aaf13afe1c0f'})
        response = self.client.post(reverse('unity_bffs:auth-jwt'), data, content_type="application/json")
        self.assertEqual(response.status_code, 400)

    def test_jwt_service_no_lti(self):
        """
        Test the success response of the service called to retrieve JWT
        """
        data = json.dumps({"authToken": str(self.game_user.auth_token)})
        response = self.client.post(reverse('unity_bffs:auth-jwt'), data, content_type="application/json")
        self.assertEqual(response.status_code, 404)

    def test_jwt_service_ok(self):
        """
        Test the success response of the service called to retrieve JWT
        """
        self.game_user.lti_launch_request_save(TEST_LTI)
        data = json.dumps({"authToken": str(self.game_user.auth_token)})
        response = self.client.post(reverse('unity_bffs:auth-jwt'), data, content_type="application/json")
        self.assertEqual(response.status_code, 200)
        response_data = json.loads(response.content)
        jwt_decoded = jwt_decode(response_data['jwt'])
        self.assertEqual(jwt_decoded['dpId'], self.game_user.dp_id)
        self.assertEqual(jwt_decoded['dpRole'], 'test')
        self.assertEqual(jwt_decoded['gameUserId'], self.game_user.id)
        self.assertEqual(jwt_decoded['servicesBaseUrl'], settings.SERVICES_BASE_URL)
        self.assertEqual(jwt_decoded['servicesEnv'], settings.ENV_NAME)
        self.assertEqual(int(response_data['lti_launch_request']['user_id']), 12345)

    def test_jwt_region(self):
        """
        Test the default and override region value
        """
        self.game_user.lti_launch_request_save(TEST_LTI)
        data = json.dumps({"authToken": str(self.game_user.auth_token)})

        response = self.client.post(reverse('unity_bffs:auth-jwt'), data, content_type="application/json")
        self.assertEqual(response.status_code, 200)
        response_data = json.loads(response.content)
        jwt_decoded = jwt_decode(response_data['jwt'])
        self.assertEqual(jwt_decoded['region'], 'us_canada')

        region = Region.objects.create(name='test', code='other-region')
        self.game_user.region = region
        self.game_user.save()

        response = self.client.post(reverse('unity_bffs:auth-jwt'), data, content_type="application/json")
        self.assertEqual(response.status_code, 200)
        response_data = json.loads(response.content)
        jwt_decoded = jwt_decode(response_data['jwt'])
        self.assertEqual(jwt_decoded['region'], 'other-region')

    def test_jwt_service_unique_session_key(self):
        # Given subsequent requests for a new JWT, service should return unique session keys
        self.game_user.lti_launch_request_save(TEST_LTI)
        data = json.dumps({"authToken": str(self.game_user.auth_token)})

        # 1st request
        response = self.client.post(reverse('unity_bffs:auth-jwt'), data, content_type="application/json")
        self.assertEqual(response.status_code, 200)
        response_data = json.loads(response.content)
        jwt_decoded = jwt_decode(response_data['jwt'])
        self.assertTrue('sessionKey' in jwt_decoded)
        old_token = jwt_decoded['sessionKey']

        # 2nd request
        response = self.client.post(reverse('unity_bffs:auth-jwt'), data, content_type="application/json")
        self.assertEqual(response.status_code, 200)
        response_data = json.loads(response.content)
        jwt_decoded = jwt_decode(response_data['jwt'])
        self.assertNotEqual(old_token, jwt_decoded['sessionKey'])

    def test_jwt_service_notify_new_session(self):
        # Given a request to the JWT endpoint, a new session event should be emitted to Kafka topic unity_session_started
        self.game_user.lti_launch_request_save(TEST_LTI)
        data = json.dumps({"authToken": str(self.game_user.auth_token)})
        response = self.client.post(reverse('unity_bffs:auth-jwt'), data, content_type="application/json")
        self.assertEqual(response.status_code, 200)
        response_data = json.loads(response.content)
        jwt_decoded = jwt_decode(response_data['jwt'])

        # Confirm new unity session record written
        self.assertEqual(len(GameUserUnitySession.objects.all()), 1)
        unity_session = GameUserUnitySession.objects.latest()
        self.assertEqual(unity_session.session_key, jwt_decoded['sessionKey'])

    def test_jwt_service_gameplay_location(self):
        # New session w/ new location - no existing record
        self.assertEqual(GameplayLocation.objects.count(), 0)
        data = json.dumps({"authToken": str(self.game_user.auth_token)})
        self.game_user.lti_launch_request_save(TEST_LTI)
        response = self.client.post(reverse('unity_bffs:auth-jwt'), data, content_type="application/json")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(GameUserUnitySession.objects.all()), 1)
        self.assertEqual(GameplayLocation.objects.count(), 1)
        gpl = GameplayLocation.objects.all()[0]
        self.assertEqual(gpl.ip_address, '127.0.0.1')
        self.assertEqual(gpl.location, '')

        # New session w/ existing location
        gpl.location = 'school'
        gpl.save()

        # Test we have queried ES
        response = self.client.post(reverse('unity_bffs:auth-jwt'), data, content_type="application/json")
        self.assertEqual(response.status_code, 200)

        # Asserting that the gameplay location was persisted in the Unity Session record
        self.assertEqual(len(GameUserUnitySession.objects.all()), 2)
        unity_session = GameUserUnitySession.objects.latest()
        self.assertEqual(unity_session.gameplay_location.location, 'school')
