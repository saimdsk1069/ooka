import json
from django.test import TestCase
from django.urls import reverse
from ookadogsled.elasticsearch_client import es, es_index_name
from gameplay.models import Book, GameUser, UserBookProgress

VALID_JWT = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJnYW1lVXNlcklkIjoxMiwiZHBJZCI6MTIzNDUsImRwUm9sZSI6InN0dWRlbnQiLCJzY2hvb2xJZCI6MTIsInNjaG9sYXN0aWNHcmFkZUNvZGUiOiIxIiwic2Vzc2lvbktleSI6ImRzZ25zb2lmcG9zam9mIn0.19Oh2eBzyrtAZnK881WRM-ur7kcIWTIX_KveYCmWP50'


class GameStateChangeBehaviourTestCase(TestCase):

    def setUp(self):
        es.indices.put_template(UserBookProgress.es_template_name, UserBookProgress.es_template)
        self.client.defaults['HTTP_AUTHORIZATION'] = 'Bearer ' + VALID_JWT
        self.game_user = GameUser.objects.create(id=12, dp_id=12345)
        for bid in [1, 2, 3, 5]:
            Book.objects.create(id=bid, active=True, book_level=bid)

    def tearDown(self):
        es.indices.delete(index=es_index_name("book_progress"), ignore=404)
        self.game_user.get_state(tag='books-progress').delete()

    def test_books_progress(self):
        books_progress1 = {
          'version': '0',
          'content': {
            'progress': {
              '1': {
                'times_read': '1',
                'comprehension_state': '1'
              },
              '2': {
                'times_read': '3',
                'comprehension_state': '1'
              }
            },
            'interventions': {
            }
          }
        }

        self.assertEqual(len(UserBookProgress.objects.all()), 0)
        response = self.client.post(reverse("unity_bffs:game-state", args=('books-progress',)),
                                    data=json.dumps(books_progress1), content_type="application/json")
        self.assertEqual(response.status_code, 201)
        self.assertEqual(len(UserBookProgress.objects.all()), 2)
        bp1 = UserBookProgress.objects.get(book_id=1)
        self.assertEqual(bp1.book_id, 1)
        self.assertEqual(bp1.times_read, 1)
        self.assertEqual(bp1.comprehension_state, 1)

        # Update the state with a new item, updating the existing, not deleting the old
        books_progress2 = {
            'version': '0',
            'content': {
                'progress': {
                    '1': {
                        'times_read': '5',
                        'comprehension_state': '0'
                    },
                    '5': {
                        'times_read': '3',
                        'comprehension_state': '1'
                    },
                    '3': {
                        'times_read': '2',
                        'comprehension_state': '1 '
                    }
                },
                'interventions': {
                }
            }
        }

        response = self.client.post(reverse("unity_bffs:game-state", args=('books-progress',)),
                                    data=json.dumps(books_progress2), content_type="application/json")
        self.assertEqual(response.status_code, 200)

        self.assertEqual(len(UserBookProgress.objects.all()), 4)
        bp1 = UserBookProgress.objects.get(book_id=1)
        self.assertEqual(bp1.times_read, 5)
        self.assertEqual(bp1.comprehension_state, 0)
