import json
from django.http import JsonResponse
from django.test import mock, TestCase
from django.urls import reverse

from gameplay.models import GameState, GameUser, Activity, ActivityLevel, UnlockType, Text, TextType, Region, Score, \
    Book, AppliedIntervention

VALID_JWT = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJnYW1lVXNlcklkIjoxMiwiZHBJZCI6MTIzNDUsImRwUm9sZSI6InN0dWRlbnQiLCJzY2hvb2xJZCI6MTIsInNjaG9sYXN0aWNHcmFkZUNvZGUiOiIxIiwic2Vzc2lvbktleSI6ImRzZ25zb2lmcG9zam9mIn0.19Oh2eBzyrtAZnK881WRM-ur7kcIWTIX_KveYCmWP50'


class TestGameplayStateUnityAPI(TestCase):

    def setUp(self):
        # Bootstrap the table - there must be a better way
        if not GameState.exists():
            GameState.create_table(wait=True)

        self.game_user = GameUser.objects.create(id=12, dp_id=12345, dp_role='student')
        self.tag = "some-tag"
        self.data = {"something": "awesome"}
        gs_item = GameState(self.game_user.id, self.tag, data=self.data)
        gs_item.save()
        self.gs_item = gs_item
        self.client.defaults['HTTP_AUTHORIZATION'] = 'Bearer ' + VALID_JWT

    def tearDown(self):
        self.gs_item.delete()

    def test_options_success(self):
        """
        Test that we can have preflight options
        """
        response = self.client.options(reverse("unity_bffs:game-state", args=(self.tag,)))
        self.assertEqual(response.status_code, 200)

    def test_get_success(self):
        """
        Test that we can retrive a record
        """
        response = self.client.get(reverse("unity_bffs:game-state", args=(self.tag,)))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(json.dumps(self.data), response.content.decode("utf-8", "strict"))

    def test_get_not_found(self):
        response = self.client.get(reverse("unity_bffs:game-state", args=("student",)))
        self.assertEqual(response.status_code, 404)

    def test_create_success(self):
        """
        Test that we can set a record
        """
        self.gs_item.delete()
        to_create = json.dumps(self.data)
        response = self.client.post(reverse("unity_bffs:game-state", args=(self.tag,)), data=to_create,
                                    content_type="application/json")
        self.assertEqual(response.status_code, 201)

        GameState.get(self.game_user.id, self.tag)
        response = self.client.post(reverse("unity_bffs:game-state", args=(self.tag,)), data=to_create,
                                    content_type="application/json")
        self.assertEqual(response.status_code, 200)
        saved_game_state = GameState.get(self.game_user.id, self.tag)
        self.assertEqual(json.dumps(saved_game_state.data), to_create)

    def test_create_invalid(self):
        """
        Test that invalid json is rejected
        """
        self.gs_item.delete()
        to_create = {"data": "{{improper json'"}
        response = self.client.post(reverse("unity_bffs:game-state", args=(self.tag,)), data=to_create,
                                    content_type="application/json")
        self.assertEqual(response.status_code, 400)


class TelemetryEndpointTestCase(TestCase):

    def setUp(self):
        self.client.defaults['HTTP_AUTHORIZATION'] = "Bearer %s" % VALID_JWT

        # TODO: Probably create a fixture for this stuff instead
        ut = UnlockType.objects.create(type="Quantity Entries", threshold=100,
                                       description="User needs to attain a certain number of scores 'Threshold' to advance.")
        tt = TextType.objects.create(name="noun", active=True)
        Region.objects.create(name='CA', code='CA')

        self.game_user = GameUser.objects.create(id=12, dp_id=12, dp_role="student")

        self.text = Text.objects.create(text_type=tt, text="A", sound_file_path="/dev/null/",
                                        active=True, sound1="blah", sound2="bluh", sound3="bleh")

        self.a = Activity.objects.create(name="Cave of Sounds", scene_name="CaveOfSounds", is_score_based=True, active=True,
                                         max_level=49, report_display="Cave of Sounds")

        self.al = ActivityLevel.objects.create(label="Cave Discover the Sounds 8-1: TH/o_e", activity=self.a, level_number=10,
                                               order=1, unlock_type=ut, active=True, unlock_value=0., question_type=1)

    def test_post_telemetry_success(self):
        """
        Test that sending a telemetry event to the endpoint will create a score record
        """
        telemetry_json = {
            "activityId": self.a.pk,
            "activityLevelId": self.al.pk,
            "activityPart": "A",
            "timing": 100.1,
            "isCorrect": 1,
            "submittedTextId": self.text.pk,
            "correctTextId": self.text.pk,
            "timestamp": "2018-03-19 12:12:12 +0100"
        }

        self.assertEqual(len(Score.objects.all()), 0)  # no scores to start
        response = self.client.post(reverse('unity_bffs:telemetry'), json.dumps(telemetry_json),
                                    content_type="application/json")
        self.assertEqual(response.status_code, 201)
        self.assertEqual(type(response), JsonResponse)
        self.assertEqual(len(Score.objects.all()), 1)  # now we should have 1 score
        s = Score.objects.all()[0]
        # Verify the created datetime hasn't been messed with by an auto_now_add
        self.assertEqual(str(s.created), '2018-03-19 11:12:12+00:00')
        self.assertEqual(s.session_key, 'dsgnsoifposjof')

    def test_post_telemetry_strings_success(self):
        """
        Test that sending a telemetry event to the endpoint will create a score record
        """
        telemetry_json = {
            "activityId": str(self.a.pk),
            "activityLevelId": str(self.al.pk),
            "activityPart": "A",
            "timing": '100.1',
            "isCorrect": '1',
            "submittedTextId": str(self.text.pk),
            "correctTextId": str(self.text.pk),
            "timestamp": "2018-03-19 12:12:12 +0100",
            "platform": "IPhonePlayer"
        }

        self.assertEqual(len(Score.objects.all()), 0)  # no scores to start
        response = self.client.post(reverse('unity_bffs:telemetry'), json.dumps(telemetry_json),
                                    content_type="application/json")
        self.assertEqual(response.status_code, 201)
        self.assertEqual(type(response), JsonResponse)
        self.assertEqual(len(Score.objects.all()), 1)  # now we should have 1 score
        s = Score.objects.all()[0]
        # Verify the created datetime hasn't been messed with by an auto_now_add
        self.assertEqual(str(s.created), '2018-03-19 11:12:12+00:00')
        self.assertEqual(s.activity_id, self.a.pk)
        self.assertEqual(s.activity_level_id, self.al.pk)
        self.assertEqual(s.timing, 100.1)
        self.assertTrue(s.score)
        self.assertEqual(s.submitted_text_id, self.text.pk)
        self.assertEqual(s.correct_text_id, self.text.pk)
        self.assertEqual(s.platform, 'IPhonePlayer')

    def test_post_missing_telemetry_data(self, *args):
        """
        Test that the endpoint will return an error if missing any part of telemetry event
        """
        telemetry_json = {
            "activityId": self.a.pk,
            "activityLevelId": self.al.pk,
            "timing": 100.1,
            "isCorrect": 1,
            "correctTextId": self.text.pk,
            "timestamp": "2018-03-19 12:12:12 -0900"
        }

        self.assertEqual(len(Score.objects.all()), 0)  # no scores to start
        response = self.client.post(reverse('unity_bffs:telemetry'), json.dumps(telemetry_json),
                                    content_type="application/json")
        self.assertEqual(400, response.status_code)
        self.assertEqual(type(response), JsonResponse)
        self.assertEqual(len(Score.objects.all()), 0)

    def test_malformed_timestamp(self, *args):
        telemetry_json = {
            "activityId": self.a.pk,
            "activityLevelId": self.al.pk,
            "timing": 100.1,
            "isCorrect": 1,
            "submittedTextId": self.text.pk,
            "correctTextId": self.text.pk,
            "timestamp": "2018-03-19 1E:12:12 -0400"
        }

        self.assertEqual(len(Score.objects.all()), 0)  # no scores to start
        response = self.client.post(reverse('unity_bffs:telemetry'), json.dumps(telemetry_json),
                                    content_type="application/json")
        self.assertEqual(400, response.status_code)
        self.assertEqual(type(response), JsonResponse)
        self.assertEqual(len(Score.objects.all()), 0)

    def test_unknown_game_user(self, *args):
        telemetry_json = {
            "activityId": self.a.pk,
            "activityLevelId": self.al.pk,
            "timing": 100.1,
            "isCorrect": 1,
            "submittedTextId": self.text.pk,
            "correctTextId": self.text.pk,
            "timestamp": "2018-03-19 12:12:12 +0400"
        }
        self.game_user.delete()

        response = self.client.post(reverse('unity_bffs:telemetry'), json.dumps(telemetry_json),
                                    content_type="application/json")
        self.assertEqual(400, response.status_code)
        self.assertEqual(type(response), JsonResponse)

    def test_get_recent_telemetry(self):
        """
        Test that sending a telemetry event to the endpoint will create a score record
        """
        telemetry_json = {
            "activityId": self.a.pk,
            "activityLevelId": self.al.pk,
            "activityPart": "A",
            "timing": 100.1,
            "isCorrect": 1,
            "submittedTextId": self.text.pk,
            "correctTextId": self.text.pk,
            "timestamp": "2018-03-19 12:12:12 +0100"
        }

        response = self.client.post(reverse('unity_bffs:telemetry'), json.dumps(telemetry_json),
                                    content_type="application/json")
        self.assertEqual(response.status_code, 201)

        response = self.client.get(reverse('unity_bffs:telemetry'))
        response_dict = json.loads(response.content)

        self.assertIn('scores', response_dict)
        self.assertEqual(response_dict['scores'][0]['gameUserId'], 12)
        self.assertEqual(response_dict['scores'][0]['isCorrect'], 1)


class InterventionEndpointTestCase(TestCase):
    """
    name = models.CharField(max_length=50)
    active = models.BooleanField()
    sound_path = models.CharField(max_length=80)
    book_level = models.IntegerField()
    next_book = models.ForeignKey('Book', null=True, blank=True)  # Hint: it's just PK + 1 -rp
    readable_name = models.CharField(max_length=50)
    regions = models.ManyToManyField("Region")
    """

    def setUp(self):
        self.client.defaults['HTTP_AUTHORIZATION'] = "Bearer %s" % VALID_JWT
        self.game_user = GameUser.objects.create(id=12, dp_id=12, dp_role="student")

        self.book1 = Book.objects.create(name="Book 12", active=True, sound_path="/dev/null/", book_level=12,
                                         readable_name="Harry Patter")
        self.book2 = Book.objects.create(name="Book 23", active=True, sound_path="/dev/null/", book_level=23,
                                         readable_name="Harry Pitter")

    def test_successful_intervention_post(self):
        intervention_json = {
            "pre_book": self.book1.id,
            "post_book": self.book2.id,
            "timestamp": "2018-03-19 12:12:12 +0100",
            "intervention_type": "some_type"
        }

        self.assertEqual(0, len(AppliedIntervention.objects.all()))

        response = self.client.post(reverse('unity_bffs:intervention'), json.dumps(intervention_json),
                                    content_type="application/json")

        self.assertEqual(response.status_code, 201)
        self.assertEqual(1, len(AppliedIntervention.objects.all()))

        new_intervention = AppliedIntervention.objects.all()[0]
        self.assertEqual(new_intervention.game_user_id, 12)
        self.assertEqual(new_intervention.pre_book.id, self.book1.id)
        self.assertEqual(new_intervention.post_book.id, self.book2.id)
        self.assertEqual(new_intervention.intervention_type, "some_type")

    def test_post_missing_intervention_info(self):
        """
        Test that the endpoint will return an error if missing any part of telemetry event
        """
        intervention_json = {
            "pre_book": self.book1.id,
            "post_book": self.book2.id,
        }

        self.assertEqual(0, len(AppliedIntervention.objects.all()))
        response = self.client.post(reverse('unity_bffs:intervention'), json.dumps(intervention_json),
                                    content_type="application/json")

        self.assertEqual(400, response.status_code)
        self.assertEqual(type(response), JsonResponse)
        self.assertEqual(0, len(AppliedIntervention.objects.all()))

    def test_post_malformed_timestamp(self):
        intervention_json = {
            "pre_book": self.book1.id,
            "post_book": self.book2.id,
            "timestamp": "2018-03-19 1E:12:12 -0400"
        }

        self.assertEqual(0, len(AppliedIntervention.objects.all()))
        response = self.client.post(reverse('unity_bffs:intervention'), json.dumps(intervention_json),
                                    content_type="application/json")

        self.assertEqual(400, response.status_code)
        self.assertEqual(type(response), JsonResponse)
        self.assertEqual(0, len(AppliedIntervention.objects.all()))

    def test_unknown_gameuser(self):
        intervention_json = {
            "pre_book": self.book1.id,
            "post_book": self.book2.id,
            "timestamp": "2018-03-19 1E:12:12 -0400"
        }
        self.game_user.delete()
        self.assertEqual(0, len(AppliedIntervention.objects.all()))
        response = self.client.post(reverse('unity_bffs:intervention'), json.dumps(intervention_json),
                                    content_type="application/json")

        self.assertEqual(400, response.status_code)
        self.assertEqual(type(response), JsonResponse)
        self.assertEqual(0, len(AppliedIntervention.objects.all()))
