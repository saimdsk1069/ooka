from django.conf.urls import url
from . import views

# @TODO Remove unnecessary duplicates
urlpatterns = [
    url(r'^auth/jwt$', views.JWTAPI.as_view(), name='auth-jwt'),
    url(r'^v1/auth/jwt$', views.JWTAPI.as_view(), name='auth-jwt'),
    url(r'^telemetry/$', views.TelemetryAPI.as_view(), name='telemetry'),
    url(r'^v1/telemetry/$', views.TelemetryAPI.as_view(), name='telemetry'),
    url(r'^intervention/$', views.InterventionAPI.as_view(), name='intervention'),
    url(r'^v1/intervention/$', views.InterventionAPI.as_view(), name='intervention'),
    url(r'^game_state/(?P<tag>[\w-]+)$', views.GameStateAPI.as_view(), name='game-state'),
    url(r'^v1/game_state/(?P<tag>[\w-]+)$', views.GameStateAPI.as_view(), name='game-state'),
]
