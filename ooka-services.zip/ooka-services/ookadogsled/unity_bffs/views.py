import datetime
import json
import logging
import uuid
from django.db.utils import IntegrityError
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import View
from ookadogsled.utils import get_client_ip
from gameplay.models import AppliedIntervention, GameplayLocation, GameState, GameUser, GameUserUnitySession, Score
from sdm_authentication.utils import jwt_encode, require_valid_jwt

logger = logging.getLogger(__name__)


class UnityAPIView(View):
    http_method_names = ['options']

    @staticmethod
    def get_body_json(request):
        json_data = request.body.decode('utf-8')
        if not json_data:
            logger.error("get_body_json: Data missing from API request body.")
            return JsonResponse({"status": "error", "message": "data was missing"}, status=400)

        try:
            data = json.loads(json_data)
        except json.decoder.JSONDecodeError as e:
            logger.error("get_body_json some other issue: %s" % e)
            return JsonResponse({"status": "error", "message": "%s" % e}, status=400)

        return data


class JWTAPI(UnityAPIView):
    http_method_names = ['options', 'post']

    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super(JWTAPI, self).dispatch(request, *args, **kwargs)

    def post(self, request):
        """
        Accept a POST from Unity to authenticate and return a JWT
        """
        # decode the body into JSON, or return an error response if that can't be done
        data = self.get_body_json(request)
        if type(data) == JsonResponse:
            return data

        try:
            auth_token = data['authToken']
        except KeyError:
            return JsonResponse({"status": "error", "message": "Missing authToken."}, status=400)

        try:
            auth_token = uuid.UUID(auth_token)
        except ValueError:
            return JsonResponse({"status": "error", "message": "Bad authToken."}, status=400)

        try:
            game_user = GameUser.objects.get(auth_token=auth_token)
        except GameUser.DoesNotExist:
            return JsonResponse({"status": "error", "message": "Could not find a Game User for that authToken."}, status=404)

        lti_launch_request = game_user.lti_launch_request_get()
        if not lti_launch_request and lti_launch_request != {}:
            return JsonResponse({"status": "error", "message": "Could not find a launch packet for that Game User."},
                                status=404)

        # @TODO Check the validity of the session?
        payload = game_user.jwt_payload(lti_launch_request)

        # Save a Unity Session record
        self._create_unity_session(request.META.get('REMOTE_ADDR'), payload)

        # Prepare the response
        response_data = {"jwt": jwt_encode(payload), "lti_launch_request": lti_launch_request}
        response = JsonResponse(response_data, status=200)
        return response

    @staticmethod
    def _create_unity_session(ip_address, payload):
        try:
            gameplay_location = GameplayLocation.objects.get(ip_address=ip_address)
        except GameplayLocation.DoesNotExist:
            gameplay_location = GameplayLocation.objects.create(ip_address=ip_address)

        GameUserUnitySession.objects.create(
            game_user_id=payload['gameUserId'], session_key=payload['sessionKey'], ip_address=ip_address,
            dp_role=payload['dpRole'], district_id=payload.get('districtId', None), school_id=payload.get('schoolId', None),
            section_id=payload.get('sectionId', None), scholastic_grade_code=payload.get('scholasticGradeCode', ''),
            grade_system_code=payload.get('gradeSystemCode', ''), gameplay_location=gameplay_location,
            created=datetime.datetime.now()
        )


class GameStateAPI(UnityAPIView):
    """
    Game State API view, accepts GET/POST from Dashboard Persistence Service
    Persists game state data.
    """
    http_method_names = ['get', 'options', 'post']

    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        """
        Disable CSRF protection on this view.
        """
        return super(GameStateAPI, self).dispatch(request, *args, **kwargs)

    @method_decorator(require_valid_jwt)
    @staticmethod
    def post(request, game_user_id, tag, jwt_payload):
        """
        Accept a POST from Dashboard SDM as a application/json.
        """
        try:
            game_user_id = int(game_user_id)
            try:
                game_user = GameUser.objects.get(id=game_user_id)
            except GameUser.DoesNotExist:
                return JsonResponse({"status": "error",
                                     "message": "Could not find a Game User for that game_user_id %d" % game_user_id},
                                    status=400)
        except ValueError:
            logger.error("student_id was not an integer")
            return JsonResponse({"status": "error", "message": "game_user_id was not an integer"}, status=400)

        json_data = request.body.decode('utf-8')
        if not json_data:
            logger.error("data missing")
            return JsonResponse({"status": "error", "message": "data was missing"}, status=400)

        try:
            data = json.loads(json_data)
        except json.decoder.JSONDecodeError as e:
            logger.error("something else: %s" % e)
            return JsonResponse({"status": "error", "message": "%s" % e}, status=400)

        # @TODO Make sure not to overwrite new state with old values

        response_data = {"status": "success"}
        updated = game_user.update_state(tag=tag, data=data)
        status_code = 200 if updated else 201
        response = JsonResponse(response_data, status=status_code)
        return response

    @method_decorator(require_valid_jwt)
    @staticmethod
    def get(request, game_user_id, tag, jwt_payload):
        if not tag:
            logger.error("student_id and tag are required parameters")
            return JsonResponse({"status": "error", "message": "game_user_id and tag are required parameters"}, status=400)

        try:
            game_user_id = int(game_user_id)
            try:
                game_user = GameUser.objects.get(id=game_user_id)
            except GameUser.DoesNotExist:
                return JsonResponse({"status": "error",
                                     "message": "Could not find a Game User for that game_user_id: %d" % game_user_id},
                                    status=400)
        except ValueError:
            logger.error("student_id was not an integer")
            return JsonResponse({"status": "error", "message": "game_user_id was not an integer"}, status=400)

        try:
            gsa = game_user.get_state(tag=tag)
        except GameState.DoesNotExist:
            return JsonResponse({"status": "error", "message": "not found"}, status=404)
        return JsonResponse(gsa.data)


class TelemetryAPI(UnityAPIView):
    http_method_names = ['options', 'post', 'get']

    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super(TelemetryAPI, self).dispatch(request, *args, **kwargs)

    @method_decorator(require_valid_jwt)
    def get(self, request, game_user_id, jwt_payload):
        """
        Get the most recent score telemetry events for the current game user
        """
        user_scores = Score.objects.filter(game_user_id=game_user_id).order_by('-id')[:40]

        results = {'scores': []}

        for score in user_scores:
            results['scores'].append(score.as_dict())

        return JsonResponse(results, status=200)

    @method_decorator(require_valid_jwt)
    def post(self, request, game_user_id, jwt_payload):
        # decode the body into JSON, or return an error response if that can't be done
        data = self.get_body_json(request)
        if type(data) == JsonResponse:
            return data
        try:
            data = self._sanitize_telementry_payload(data)
        except KeyError:
            logger.error("Missing telemetry event from client: %s" % json.dumps(data))
            return JsonResponse({"error": "Missing key in payload."}, status=400)
        data['game_user_id'] = game_user_id
        data['session_key'] = jwt_payload['sessionKey']
        data['dp_id'] = jwt_payload['dpId']
        data['district_id'] = jwt_payload.get('districtId', None)
        data['school_id'] = jwt_payload.get('schoolId')
        data['scholastic_grade_code'] = jwt_payload.get('scholasticGradeCode')
        data['ip_address'] = get_client_ip(request)

        # now we want to validate that we've passed in everything needed for a valid telemetry event
        if not self._valid_telemetry_payload(data):
            logger.error("invalid telemetry event from client: %s" % json.dumps(data))
            return JsonResponse({"status": "error", "message": "invalid telemetry event sent"}, status=400)
        try:
            Score.create_from_telemetry_event(data)
        except ValueError as e:
            logger.error("Could not transform telemetry event to score record: %s" % e)
            return JsonResponse({"status": "error", "message": "Error transforming this telemetry event: %s" % e}, status=400)
        except IntegrityError as e:
            logger.error("Error inserting this telemetry record: %s" % e)
            return JsonResponse({"status": "error", "message": "Error inserting this telemetry record: %s" % e}, status=400)

        return JsonResponse({"status": "success"}, status=201)

    @staticmethod
    def _valid_telemetry_payload(telemetry_data):
        required_fields = ["activityId", "activityLevelId", "activityPart", "timing", "isCorrect", "submittedTextId",
                           "correctTextId", "timestamp"]

        for field in required_fields:
            if field not in telemetry_data:
                return False

        return True

    @staticmethod
    def _sanitize_telementry_payload(telemetry_data):
        int_fields = ["activityId", "activityLevelId", "isCorrect", "submittedTextId", "correctTextId"]
        for field in int_fields:
            telemetry_data[field] = int(telemetry_data[field])
        telemetry_data['timing'] = float(telemetry_data['timing'])
        return telemetry_data


class InterventionAPI(UnityAPIView):
    http_method_names = ['options', 'post', 'get']

    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super(InterventionAPI, self).dispatch(request, *args, **kwargs)

    @method_decorator(require_valid_jwt)
    def post(self, request, game_user_id, jwt_payload):
        data = self.get_body_json(request)
        data['game_user_id'] = game_user_id

        # now we want to validate that we've passed in everything needed for a valid telemetry event
        if not self._valid_intervention_payload(data):
            logger.error("invalid intervention event from client: %s" % json.dumps(data))
            return JsonResponse({"status": "error", "message": "invalid intervention event sent"}, status=400)

        try:
            AppliedIntervention.create_from_intervention_event(data)
        except ValueError as e:
            logger.error("Could not transform intervention event to score record: %s" % e)
            return JsonResponse({"status": "error", "message": "Error transforming this intervention event: %s" % e},
                                status=400)
        except IntegrityError as e:
            logger.error("Error inserting this intervention record: %s" % e)
            return JsonResponse({"status": "error", "message": "Error inserting this intervention record: %s" % e}, status=400)

        response = JsonResponse({"status": "success"}, status=201)
        response['Access-Control-Allow-Origin'] = '*'
        return response

    @staticmethod
    def _valid_intervention_payload(intervention_data):
        required_fields = ["pre_book", "post_book", "timestamp", "game_user_id"]

        for field in required_fields:
            if field not in intervention_data:
                return False
        return True
