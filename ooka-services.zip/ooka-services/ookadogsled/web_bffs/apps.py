from django.apps import AppConfig


class WebBffsConfig(AppConfig):
    name = 'web_bffs'
