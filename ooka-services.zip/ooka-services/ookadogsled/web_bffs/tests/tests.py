import json
import requests_mock
from django.conf import settings
from django.test import TestCase
from django.shortcuts import reverse


VALID_TOKEN = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJnYW1lVXNlcklkIjo1NX0.bmek28mO9XP4S66LGSfOgvR-oFc_TXpFlBO3SrcmCq0'


@requests_mock.Mocker()
class TestWebBFFs(TestCase):

    def setUp(self):
        self.client.defaults['HTTP_AUTHORIZATION'] = 'Bearer ' + VALID_TOKEN

    def test_mocked_student_api_200(self, mocked_requests):
        """
        Tests the round-trip: response with JSON content comes back from DP API, and gets converted into JSON and back
        to a string for the response.
        """
        response_text = '{"id":"98766","active":true,"organizationId":"12345","staff":{"primaryTeacherId":"12345"},' \
                        '"nickname":"Remedial Reading","grades":["first","second"],"studentAuthenticationMethod":' \
                        '{"type":"easyLogin","enabled":true,"requirePassword":false}}'
        mocked_requests.get('%s/roster/students/98766' % settings.DP_API_URL, status_code=200, text=response_text)
        response = self.client.get(reverse('web_bffs:dp-student', args=('98766',)))
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        # Not an int - ok?
        self.assertEqual(int(content['id']), 98766)
        self.assertEqual(content['active'], True)

    def test_mocked_student_api_403(self, mocked_requests):
        """
        Tests the round-trip: response comes back from DP API, 403 status code is handled appropriately. Mostly a test
        of the web_bff_json_response view decorator.
        """

        mocked_requests.get('%s/roster/students/12345' % settings.DP_API_URL, status_code=403)
        response = self.client.get(reverse('web_bffs:dp-student', args=('12345',)))
        self.assertEqual(response.status_code, 403)

    def test_mocked_user_api_404(self, mocked_requests):
        """
        Tests the round-trip: response comes back from DP API, 404 status code is handled appropriately. Mostly a test
        of the web_bff_json_response view decorator.
        """

        mocked_requests.get('%s/roster/students/22222' % settings.DP_API_URL, status_code=404)
        response = self.client.get(reverse('web_bffs:dp-student', args=('22222',)))
        self.assertEqual(response.status_code, 404)

    def test_sections_api_params(self, mocked_requests):
        """
        Tests the Sections search API - with one required parameter
        """
        # No params - error
        response = self.client.get(reverse('web_bffs:dp-sections'))
        self.assertEqual(response.status_code, 400)

        # Mocked response
        response_text = '[{"id":"98765","active":true,"organizationId":"12345","staff":{"primaryTeacherId":"12345"},' \
                        '"nickname":"English 101","grades":["first","second"],"studentAuthenticationMethod":' \
                        '{"type":"easyLogin","enabled":true,"requirePassword":false}},{"id":"98766","active":true,' \
                        '"organizationId":"12345","staff":{"primaryTeacherId":"12345"},"nickname":"Remedial Reading",'\
                        '"grades":["first","second"],"studentAuthenticationMethod":{"type":"easyLogin",' \
                        '"enabled":true, "requirePassword":false}}]'

        # staffId works
        mocked_requests.get('%s/roster/sections?staffId=9876' % settings.DP_API_URL, status_code=200, text=response_text)
        response = self.client.get("%s?staffId=9876" % reverse('web_bffs:dp-sections'))
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(int(content[0]['id']), 98765)

        # studentId also ok
        mocked_requests.get('%s/roster/sections?studentId=9876' % settings.DP_API_URL, status_code=200, text=response_text)
        response = self.client.get("%s?studentId=9876" % reverse('web_bffs:dp-sections'))
        self.assertEqual(response.status_code, 200)

        # organizationId ok too
        mocked_requests.get('%s/roster/sections?organizationId=9876' % settings.DP_API_URL, status_code=200, text=response_text)
        response = self.client.get("%s?organizationId=9876" % reverse('web_bffs:dp-sections'))
        self.assertEqual(response.status_code, 200)

    def test_section_api(self, mocked_requests):
        """
        Tests the Section API
        """
        response_text = '{"id":"98765","active":true,"organizationId":"12345","staff":{"primaryTeacherId":"12345"},' \
                        '"nickname":"English 101","grades":["first","second"],"studentAuthenticationMethod":' \
                        '{"type":"easyLogin","enabled":true,"requirePassword":false}}'
        mocked_requests.get('%s/roster/sections/765' % settings.DP_API_URL, status_code=200, text=response_text)
        response = self.client.get(reverse('web_bffs:dp-section', args=('765',)))
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(int(content['organizationId']), 12345)

    def test_section_students_api(self, mocked_requests):
        """
        Tests the Section Students API
        """
        response_text = '[{"id":"98766","active":true,"organizationId":"12345","staff":{"primaryTeacherId":"12345"},' \
                        '"nickname":"Remedial Reading","grades":["first","second"],"studentAuthenticationMethod":' \
                        '{"type":"easyLogin","enabled":true,"requirePassword":false}}]'
        mocked_requests.get('%s/roster/sections/765/students' % settings.DP_API_URL, status_code=200, text=response_text)
        response = self.client.get(reverse('web_bffs:dp-section-students', args=('765',)))
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(int(content[0]['id']), 98766)
        self.assertEqual(int(content[0]['organizationId']), 12345)
