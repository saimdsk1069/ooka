from django.conf.urls import url, include
from . import views


urlpatterns = [
    url(r'^reports/', include('reporting.urls', namespace='reporting')),
    url(r'^roster/sections$', views.dp_roster_sections, name="dp-sections"),
    url(r'^roster/sections/(?P<section_id>\d+)$', views.dp_roster_section, name="dp-section"),
    url(r'^roster/sections/(?P<section_id>\d+)/students$', views.dp_roster_section_students, name="dp-section-students"),
    url(r'^roster/students/(?P<student_id>\d+)$', views.dp_roster_student, name="dp-student")
]
