import logging
import requests
from django.http import JsonResponse
from django.views.decorators.http import require_GET
from django.utils.decorators import available_attrs
from functools import wraps
import digitalplatform.requests as dp_requests
from sdm_authentication.utils import require_valid_jwt

logger = logging.getLogger(__name__)

logger.info("Starting up...")

# Digital Platform API documentation:
# Swagger: http://dp-api-dev1.scholastic-labs.io/swagger-ui.html
# Users:     https://jira.sts.scholastic.com/confluence/display/DP/Composite+User+APIs
# Rostering: https://jira.sts.scholastic.com/confluence/display/DP/Roster+APIs#RosterAPIs-API:Retrieveaclasssection


def web_bff_json_response(view_func):
    """
    Decorator to return something appropriate depending on the status code of the Response Usage::

        @web_bff_json_response
        def my_view(request):
            # I can assume now that an appropriate response will be returned.
    """
    @wraps(view_func, assigned=available_attrs(view_func))
    def _wrapped_view_func(request, *args, **kwargs):
        response = view_func(request, *args, **kwargs)
        if response.status_code == 400:
            return JsonResponse(status=400, data={"status": "Bad request."})
        if response.status_code == 403:
            return JsonResponse(status=403, data={"status": "Forbidden."})
        if response.status_code == 404:
            logger.error("Hi 404 from DP")
            return JsonResponse(status=404, data={"status": "Not found."})
        # 200, 201
        return JsonResponse(response.json(), safe=False)
    return _wrapped_view_func


@require_GET
@require_valid_jwt
@web_bff_json_response
def dp_roster_student(request, student_id, game_user_id, jwt_payload):
    """
    Proxy API view for DP Students
    :param request
    :param user_id: DP userId
    :return: Http response
    """
    # /users/{id}
    uri = 'roster/students/%d' % int(student_id)
    r = dp_requests.get(uri)
    return r


@require_GET
@require_valid_jwt
@web_bff_json_response
def dp_roster_sections(request, game_user_id, jwt_payload):
    uri = "roster/sections"
    params = {}
    for p in ['staffId', 'studentId', 'organizationId']:
        if request.GET.get(p, None):
            params[p] = request.GET.get(p)

    if len(params) == 0:
        resp = requests.Response()
        resp.status_code = 400
        # One of these parameters is required: staffId, studentId, organizationId
        return resp
    r = dp_requests.get(uri, params=params)
    return r


@require_GET
@require_valid_jwt
@web_bff_json_response
def dp_roster_section(request, section_id, game_user_id, jwt_payload):
    uri = "roster/sections/%s" % int(section_id)
    r = dp_requests.get(uri)
    return r


@require_GET
@require_valid_jwt
@web_bff_json_response
def dp_roster_section_students(request, section_id, game_user_id, jwt_payload):
    uri = "roster/sections/%s/students" % int(section_id)
    r = dp_requests.get(uri)
    return r
